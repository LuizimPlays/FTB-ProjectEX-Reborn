# ProjectEX Alpha 0.8.18 — Tier-aware Links UI

## Implemented
- Personal, Refined and Compressed Refined Links now all open the same tier-aware inventory screen.
- Personal Link layout: 18 input slots + 1 extraction-only output.
- Refined Link layout: 1 input + 9 extraction-only outputs.
- Compressed Refined Link layout: 1 input + 54 extraction-only outputs.
- Empty slots now have explicit backgrounds and borders; this addresses the empty black area seen in the Personal Link screenshot.
- Player inventory and hotbar are laid out below each tier's machine area; compressed variant uses a taller screen to fit all 54 output slots.
- Shift-click from player inventory can enter input slots only; machine slots shift-click back to player inventory.
- Block titles are tier-specific and Portuguese labels are provided.
- Removed the status-chat fallback for Refined and Compressed Refined Links.

## Still pending
- No automatic item-to-EMC processing, knowledge learning, or EMC-funded output crafting is added in this iteration. Those mechanics need a separate server-authoritative processing design and must not be implied by the UI.
- The legacy reference included with this project labels Personal Link as WIP and does not contain a working item-processing implementation. This release therefore corrects the tier layouts and interaction surfaces first.

## Validation
- Source changes and ZIP integrity checked.
- Full Gradle build not verified in this environment because Gradle 8.12.1 distribution download is blocked by DNS/network restrictions. Run `gradlew.bat build` locally with JDK 21 before installing.

## Alpha 0.8.19 follow-up
- All three tiers now open the shared LinkMenu; the chat fallback was removed.
