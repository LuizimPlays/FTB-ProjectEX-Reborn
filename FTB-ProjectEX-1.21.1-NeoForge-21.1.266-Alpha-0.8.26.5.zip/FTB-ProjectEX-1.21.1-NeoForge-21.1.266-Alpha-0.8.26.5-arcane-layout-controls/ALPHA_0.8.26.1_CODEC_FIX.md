# ProjectEX Alpha 0.8.26.1 — AlchemyTableBlock codec fix

## Fixed compile error
- Implemented the protected `MapCodec<? extends BaseEntityBlock> codec()` override required by Minecraft 1.21.1.
- Added a properties-taking constructor and used `BlockBehaviour.simpleCodec(AlchemyTableBlock::new)` so decoded block settings are preserved.
- Kept the no-argument constructor used by the existing deferred block registration, delegating to the same default Alchemy Table properties.

## Preserved
- Block entity registration and ticker.
- Alchemy Table menu, recipes, EMC costs, progress and item handling.
- Link, Stone Table, HUD and Energy Link code.

## Validation status
- Source-level checks confirm the required method and codec constructor are present.
- Full Gradle compilation must still be run locally. The earlier build output identifies this missing override as the only Java error in that compile; deprecation messages for `EventBusSubscriber.Bus.MOD` are warnings, not compile blockers.
