# ProjectEX 1.12.2 → 1.21.1 migration status

| Module | Current status | Notes |
|---|---|---|
| ProjectEX registries/assets | Partial port | Existing assets and item/block registrations retained. |
| EMC HUD | Existing implementation | Carried forward from Alpha 0.8.25.1. |
| Energy Link | Partial port | Existing implementation; runtime validation remains necessary. |
| Personal/Refined/Compressed Links | Partial port | Menus, filters and EMC behavior evolved across previous alphas; full parity and automation tests pending. |
| Collectors/Relays/Power Flowers | Partial port | Existing EMC generation/transfer behavior retained; full classic parity pending. |
| Stone Table | Initial port | Catalog and EMC actions present; whitelist/JEI parity pending. |
| Alchemy Table | Initial functional port in 0.8.26 | Original recipe chains, 2-slot machine, cost/progress/buffer rules, GUI and capabilities added; JEI category and runtime tests pending. |
| Arcane Tablet | Partial port | Uses ProjectE TransmutationContainer plus 3x3 crafting attachment; full parity and hardened packet validation pending. |
| JEI integration | Not ported completely | Individual categories/recipe transfer still pending. |
| Magnum/Colossal/Final Stars and knowledge book | Partial/unverified | Full original behavior pending. |

This status distinguishes source implementation from build/runtime verification. No module should be treated as release-certified until it compiles and passes in-game tests on the target NeoForge and ProjectE versions.
