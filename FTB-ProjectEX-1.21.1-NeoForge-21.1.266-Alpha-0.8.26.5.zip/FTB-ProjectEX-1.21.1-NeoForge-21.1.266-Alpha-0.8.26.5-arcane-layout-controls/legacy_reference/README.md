# Referência legada

Este diretório contém o código Java original do ZIP enviado, identificado no projeto como Minecraft 1.18.1 / Forge 39.0.64. Ele fica fora de `src/main/java` para não ser compilado no ambiente NeoForge 1.21.1. Use-o como referência durante a migração.

Os JARs 1.12.2 e 1.16.5 enviados são binários; não foram incluídos aqui.
