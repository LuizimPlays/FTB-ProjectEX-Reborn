/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraftforge.client.settings.IKeyConflictContext
 *  net.minecraftforge.client.settings.KeyConflictContext
 *  net.minecraftforge.fml.client.registry.ClientRegistry
 */
package com.latmod.mods.projectex;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.IKeyConflictContext;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;

public final class ProjectEXKeyBindings {
    public static final KeyBinding FOCUS_SEARCH_BAR = new KeyBinding("key.projectex.focusSearchBar", (IKeyConflictContext)KeyConflictContext.GUI, 15, "Project EX");

    public static void init() {
        ClientRegistry.registerKeyBinding((KeyBinding)FOCUS_SEARCH_BAR);
    }
}

