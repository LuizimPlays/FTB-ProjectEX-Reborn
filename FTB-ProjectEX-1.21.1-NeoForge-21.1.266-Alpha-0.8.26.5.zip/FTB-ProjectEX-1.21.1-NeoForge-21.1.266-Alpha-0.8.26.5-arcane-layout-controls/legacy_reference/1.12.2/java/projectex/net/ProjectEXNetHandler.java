/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper
 *  net.minecraftforge.fml.relauncher.Side
 */
package com.latmod.mods.projectex.net;

import com.latmod.mods.projectex.net.MessageArcaneTableRecipeTransfer;
import com.latmod.mods.projectex.net.MessageCreateItemButton;
import com.latmod.mods.projectex.net.MessageSendLinkStack;
import com.latmod.mods.projectex.net.MessageSyncEMC;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class ProjectEXNetHandler {
    public static SimpleNetworkWrapper NET;

    public static void init() {
        NET = new SimpleNetworkWrapper("projectex");
        NET.registerMessage((IMessageHandler)new MessageSyncEMC.Handler(), MessageSyncEMC.class, 0, Side.CLIENT);
        NET.registerMessage((IMessageHandler)new MessageSendLinkStack.Handler(), MessageSendLinkStack.class, 1, Side.SERVER);
        NET.registerMessage((IMessageHandler)new MessageCreateItemButton.Handler(), MessageCreateItemButton.class, 2, Side.SERVER);
        NET.registerMessage((IMessageHandler)new MessageArcaneTableRecipeTransfer.Handler(), MessageArcaneTableRecipeTransfer.class, 3, Side.SERVER);
    }
}

