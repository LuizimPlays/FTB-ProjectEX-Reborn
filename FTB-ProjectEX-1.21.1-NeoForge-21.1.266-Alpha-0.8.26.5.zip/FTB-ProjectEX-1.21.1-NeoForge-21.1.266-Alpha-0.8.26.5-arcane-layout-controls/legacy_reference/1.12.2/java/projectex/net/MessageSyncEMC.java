/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  javax.annotation.Nullable
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraftforge.fml.common.FMLCommonHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 */
package com.latmod.mods.projectex.net;

import com.latmod.mods.projectex.ProjectEX;
import com.latmod.mods.projectex.net.ProjectEXNetHandler;
import io.netty.buffer.ByteBuf;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageSyncEMC
implements IMessage {
    public long emc;

    public static void sync(@Nullable EntityPlayer player, long emc) {
        if (player instanceof EntityPlayerMP) {
            MessageSyncEMC message = new MessageSyncEMC();
            message.emc = emc;
            ProjectEXNetHandler.NET.sendTo((IMessage)message, (EntityPlayerMP)player);
        }
    }

    public void fromBytes(ByteBuf buf) {
        this.emc = buf.readLong();
    }

    public void toBytes(ByteBuf buf) {
        buf.writeLong(this.emc);
    }

    public static class Handler
    implements IMessageHandler<MessageSyncEMC, IMessage> {
        public IMessage onMessage(MessageSyncEMC message, MessageContext ctx) {
            FMLCommonHandler.instance().getWorldThread(ctx.netHandler).func_152344_a(() -> ProjectEX.PROXY.updateEMC(message.emc));
            return null;
        }
    }
}

