/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  mezz.jei.api.gui.IGuiIngredient
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.FMLCommonHandler
 *  net.minecraftforge.fml.common.network.ByteBufUtils
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 */
package com.latmod.mods.projectex.net;

import com.latmod.mods.projectex.gui.ContainerArcaneTablet;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import mezz.jei.api.gui.IGuiIngredient;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageArcaneTableRecipeTransfer
implements IMessage {
    private Map<Integer, ? extends IGuiIngredient<ItemStack>> inputs;
    private List<Slot> slots;
    private ItemStack[][] recipe = new ItemStack[9][];
    private boolean transferAll;

    public MessageArcaneTableRecipeTransfer() {
    }

    public MessageArcaneTableRecipeTransfer(Map<Integer, ? extends IGuiIngredient<ItemStack>> inputs, List<Slot> slots, boolean ta) {
        this.inputs = inputs;
        this.slots = slots;
        this.transferAll = ta;
    }

    public void fromBytes(ByteBuf buf) {
        int slots = buf.readInt();
        for (int i = 0; i < slots; ++i) {
            int ingredients = buf.readInt();
            this.recipe[i] = new ItemStack[ingredients];
            for (int j = 0; j < ingredients; ++j) {
                this.recipe[i][j] = ByteBufUtils.readItemStack((ByteBuf)buf);
            }
        }
        this.transferAll = buf.readBoolean();
    }

    public void toBytes(ByteBuf buf) {
        buf.writeInt(this.slots.size());
        for (Slot slot : this.slots) {
            IGuiIngredient<ItemStack> ingredient = this.inputs.get(slot.getSlotIndex() + 1);
            ArrayList<ItemStack> ingredients = new ArrayList<ItemStack>();
            if (ingredient != null) {
                for (ItemStack possibleStack : ingredient.getAllIngredients()) {
                    if (possibleStack == null) continue;
                    ingredients.add(possibleStack);
                }
            }
            buf.writeInt(ingredients.size());
            for (ItemStack possibleStack : ingredients) {
                ByteBufUtils.writeItemStack((ByteBuf)buf, (ItemStack)possibleStack);
            }
        }
        buf.writeBoolean(this.transferAll);
    }

    public static class Handler
    implements IMessageHandler<MessageArcaneTableRecipeTransfer, IMessage> {
        public IMessage onMessage(MessageArcaneTableRecipeTransfer message, MessageContext ctx) {
            EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
            FMLCommonHandler.instance().getWorldThread(ctx.netHandler).func_152344_a(() -> {
                if (player.field_71070_bA instanceof ContainerArcaneTablet) {
                    ((ContainerArcaneTablet)player.field_71070_bA).onRecipeTransfer(message.recipe, message.transferAll);
                }
            });
            return null;
        }
    }
}

