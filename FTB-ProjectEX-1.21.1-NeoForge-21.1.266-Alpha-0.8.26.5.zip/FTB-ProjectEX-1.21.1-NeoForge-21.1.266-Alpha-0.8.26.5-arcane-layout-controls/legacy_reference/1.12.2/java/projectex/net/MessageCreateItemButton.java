/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.FMLCommonHandler
 *  net.minecraftforge.fml.common.network.ByteBufUtils
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler
 *  net.minecraftforge.fml.common.network.simpleimpl.MessageContext
 */
package com.latmod.mods.projectex.net;

import com.latmod.mods.projectex.gui.ContainerTableBase;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageCreateItemButton
implements IMessage {
    public ItemStack stack;
    public int mode;

    public MessageCreateItemButton() {
    }

    public MessageCreateItemButton(ItemStack is, int m) {
        this.stack = is;
        this.mode = m;
    }

    public void fromBytes(ByteBuf buf) {
        this.stack = ByteBufUtils.readItemStack((ByteBuf)buf);
        this.mode = buf.readUnsignedByte();
    }

    public void toBytes(ByteBuf buf) {
        ByteBufUtils.writeItemStack((ByteBuf)buf, (ItemStack)this.stack);
        buf.writeByte(this.mode);
    }

    public static class Handler
    implements IMessageHandler<MessageCreateItemButton, IMessage> {
        public IMessage onMessage(MessageCreateItemButton message, MessageContext ctx) {
            FMLCommonHandler.instance().getWorldThread(ctx.netHandler).func_152344_a(() -> {
                EntityPlayerMP player = ctx.getServerHandler().field_147369_b;
                if (player.field_71070_bA instanceof ContainerTableBase && ((ContainerTableBase)player.field_71070_bA).clickGuiSlot(message.stack, message.mode)) {
                    player.field_71070_bA.func_75142_b();
                }
            });
            return null;
        }
    }
}

