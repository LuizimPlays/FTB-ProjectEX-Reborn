/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.gameObjs.items.KleinStar$EnumKleinTier
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.item.ItemMagnumStar;
import moze_intel.projecte.gameObjs.items.KleinStar;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemStack;

public class ItemColossalStar
extends ItemMagnumStar {
    public ItemColossalStar(KleinStar.EnumKleinTier t) {
        super(t);
    }

    public boolean func_77636_d(ItemStack stack) {
        return true;
    }

    @Override
    public long getMaximumEmc(ItemStack stack) {
        return STAR_EMC[this.tier.ordinal() + 6];
    }

    @Override
    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }
}

