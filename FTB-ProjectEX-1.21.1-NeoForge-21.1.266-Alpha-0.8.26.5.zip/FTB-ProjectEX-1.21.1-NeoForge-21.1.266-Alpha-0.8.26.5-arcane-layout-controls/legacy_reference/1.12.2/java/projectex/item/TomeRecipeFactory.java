/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraftforge.common.crafting.IConditionFactory
 *  net.minecraftforge.common.crafting.JsonContext
 */
package com.latmod.mods.projectex.item;

import com.google.gson.JsonObject;
import com.latmod.mods.projectex.ProjectEXConfig;
import java.util.function.BooleanSupplier;
import net.minecraftforge.common.crafting.IConditionFactory;
import net.minecraftforge.common.crafting.JsonContext;

public class TomeRecipeFactory
implements IConditionFactory {
    public BooleanSupplier parse(JsonContext context, JsonObject json) {
        return () -> ProjectEXConfig.items.tome;
    }
}

