/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.block.EnumTier;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class ItemBlockTier
extends ItemBlock {
    public ItemBlockTier(Block block) {
        super(block);
        this.func_77627_a(true);
    }

    public int func_77647_b(int meta) {
        return meta;
    }

    public String func_77667_c(ItemStack stack) {
        return this.func_77658_a() + "." + EnumTier.byMeta(stack.func_77960_j()).func_176610_l();
    }
}

