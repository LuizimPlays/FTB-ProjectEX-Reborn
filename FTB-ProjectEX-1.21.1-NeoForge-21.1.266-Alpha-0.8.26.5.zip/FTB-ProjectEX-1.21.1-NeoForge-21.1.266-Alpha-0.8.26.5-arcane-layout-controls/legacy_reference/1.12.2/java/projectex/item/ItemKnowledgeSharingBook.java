/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.util.UUIDTypeAdapter
 *  javax.annotation.Nullable
 *  moze_intel.projecte.api.capabilities.IKnowledgeProvider
 *  net.minecraft.client.util.ITooltipFlag
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTBase
 *  net.minecraft.nbt.NBTTagString
 *  net.minecraft.util.ActionResult
 *  net.minecraft.util.EnumActionResult
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.SoundCategory
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.ProjectEXUtils;
import com.latmod.mods.projectex.integration.PersonalEMC;
import com.mojang.util.UUIDTypeAdapter;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemKnowledgeSharingBook
extends Item {
    public ItemKnowledgeSharingBook() {
        this.func_77625_d(1);
    }

    public ActionResult<ItemStack> func_77659_a(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.func_184586_b(hand);
        if (player.func_70093_af()) {
            if (!world.field_72995_K) {
                stack.func_77983_a("id", (NBTBase)new NBTTagString(UUIDTypeAdapter.fromUUID((UUID)player.func_110124_au())));
                stack.func_77983_a("name", (NBTBase)new NBTTagString(player.func_70005_c_()));
            }
            return new ActionResult(EnumActionResult.SUCCESS, (Object)stack);
        }
        if (!stack.func_77942_o() || !stack.func_77978_p().func_74764_b("id")) {
            return new ActionResult(EnumActionResult.FAIL, (Object)stack);
        }
        UUID id = UUIDTypeAdapter.fromString((String)stack.func_77978_p().func_74779_i("id"));
        if (id.equals(player.func_110124_au())) {
            return new ActionResult(EnumActionResult.FAIL, (Object)stack);
        }
        if (!world.field_72995_K) {
            IKnowledgeProvider playerKnowledge = PersonalEMC.get(player);
            IKnowledgeProvider otherKnowledge = PersonalEMC.get(world, id);
            if (otherKnowledge == null) {
                return new ActionResult(EnumActionResult.FAIL, (Object)stack);
            }
            for (ItemStack stack1 : otherKnowledge.getKnowledge()) {
                ProjectEXUtils.addKnowledge(player, playerKnowledge, stack1);
            }
            playerKnowledge.sync((EntityPlayerMP)player);
            world.func_184148_a(null, player.field_70165_t, player.field_70163_u, player.field_70161_v, SoundEvents.field_187635_cQ, SoundCategory.PLAYERS, 0.8f, 0.8f + world.field_73012_v.nextFloat() * 0.4f);
        } else {
            for (int i = 0; i < 5; ++i) {
                Vec3d vec3d = new Vec3d(((double)world.field_73012_v.nextFloat() - 0.5) * 0.1, Math.random() * 0.1 + 0.1, 0.0);
                vec3d = vec3d.func_178789_a(-player.field_70125_A * ((float)Math.PI / 180));
                vec3d = vec3d.func_178785_b(-player.field_70177_z * ((float)Math.PI / 180));
                double d0 = (double)(-world.field_73012_v.nextFloat()) * 0.6 - 0.3;
                Vec3d vec3d1 = new Vec3d(((double)world.field_73012_v.nextFloat() - 0.5) * 0.3, d0, 0.6);
                vec3d1 = vec3d1.func_178789_a(-player.field_70125_A * ((float)Math.PI / 180));
                vec3d1 = vec3d1.func_178785_b(-player.field_70177_z * ((float)Math.PI / 180));
                vec3d1 = vec3d1.func_72441_c(player.field_70165_t, player.field_70163_u + (double)player.func_70047_e(), player.field_70161_v);
                world.func_175688_a(EnumParticleTypes.ITEM_CRACK, vec3d1.field_72450_a, vec3d1.field_72448_b, vec3d1.field_72449_c, vec3d.field_72450_a, vec3d.field_72448_b + 0.05, vec3d.field_72449_c, new int[]{Item.func_150891_b((Item)this), 0});
            }
        }
        stack.func_190918_g(1);
        return new ActionResult(EnumActionResult.SUCCESS, (Object)stack);
    }

    public boolean func_77636_d(ItemStack stack) {
        return stack.func_77942_o() && stack.func_77978_p().func_74764_b("id");
    }

    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.RARE;
    }

    @SideOnly(value=Side.CLIENT)
    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        if (stack.func_77942_o() && stack.func_77978_p().func_74764_b("name")) {
            tooltip.add(stack.func_77978_p().func_74779_i("name"));
        }
    }
}

