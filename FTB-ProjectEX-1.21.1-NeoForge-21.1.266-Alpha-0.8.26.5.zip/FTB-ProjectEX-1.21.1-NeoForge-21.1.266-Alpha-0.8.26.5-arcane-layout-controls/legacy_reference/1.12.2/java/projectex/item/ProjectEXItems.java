/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 */
package com.latmod.mods.projectex.item;

import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

@GameRegistry.ObjectHolder(value="projectex")
public class ProjectEXItems {
    public static final Item ENERGY_LINK = Items.field_190931_a;
    public static final Item PERSONAL_LINK = Items.field_190931_a;
    public static final Item REFINED_LINK = Items.field_190931_a;
    public static final Item COMPRESSED_REFINED_LINK = Items.field_190931_a;
    public static final Item COLLECTOR = Items.field_190931_a;
    public static final Item RELAY = Items.field_190931_a;
    public static final Item POWER_FLOWER = Items.field_190931_a;
    public static final Item STONE_TABLE = Items.field_190931_a;
    public static final Item ALCHEMY_TABLE = Items.field_190931_a;
    public static final Item MAGNUM_STAR_EIN = Items.field_190931_a;
    public static final Item MAGNUM_STAR_ZWEI = Items.field_190931_a;
    public static final Item MAGNUM_STAR_DREI = Items.field_190931_a;
    public static final Item MAGNUM_STAR_VIER = Items.field_190931_a;
    public static final Item MAGNUM_STAR_SPHERE = Items.field_190931_a;
    public static final Item MAGNUM_STAR_OMEGA = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_EIN = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_ZWEI = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_DREI = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_VIER = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_SPHERE = Items.field_190931_a;
    public static final Item COLOSSAL_STAR_OMEGA = Items.field_190931_a;
    public static final Item MATTER = Items.field_190931_a;
    public static final Item CLAY_MATTER = Items.field_190931_a;
    public static final Item FINAL_STAR_SHARD = Items.field_190931_a;
    public static final Item FINAL_STAR = Items.field_190931_a;
    public static final Item KNOWLEDGE_SHARING_BOOK = Items.field_190931_a;
    public static final Item ARCANE_TABLET = Items.field_190931_a;
    public static final Item COMPRESSED_COLLECTOR = Items.field_190931_a;
}

