/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.item.IItemEmc
 *  moze_intel.projecte.gameObjs.items.ItemPE
 *  moze_intel.projecte.gameObjs.items.KleinStar$EnumKleinTier
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.math.MathHelper
 */
package com.latmod.mods.projectex.item;

import moze_intel.projecte.api.item.IItemEmc;
import moze_intel.projecte.gameObjs.items.ItemPE;
import moze_intel.projecte.gameObjs.items.KleinStar;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

public class ItemMagnumStar
extends Item
implements IItemEmc {
    public static final long[] STAR_EMC = new long[12];
    public final KleinStar.EnumKleinTier tier;

    public ItemMagnumStar(KleinStar.EnumKleinTier t) {
        this.tier = t;
        this.func_77625_d(1);
    }

    public boolean showDurabilityBar(ItemStack stack) {
        return (double)this.getStoredEmc(stack) > 0.0;
    }

    public double getDurabilityForDisplay(ItemStack stack) {
        long emc = this.getStoredEmc(stack);
        return (double)emc == 0.0 ? 1.0 : MathHelper.func_151237_a((double)(1.0 - (double)emc / (double)this.getMaximumEmc(stack)), (double)0.0, (double)1.0);
    }

    public long addEmc(ItemStack stack, long toAdd) {
        long add = Math.min(this.getMaximumEmc(stack) - this.getStoredEmc(stack), toAdd);
        ItemPE.addEmcToStack((ItemStack)stack, (long)add);
        return add;
    }

    public long extractEmc(ItemStack stack, long toRemove) {
        long sub = Math.min(this.getStoredEmc(stack), toRemove);
        ItemPE.removeEmc((ItemStack)stack, (long)sub);
        return sub;
    }

    public long getStoredEmc(ItemStack stack) {
        return ItemPE.getEmc((ItemStack)stack);
    }

    public long getMaximumEmc(ItemStack stack) {
        return STAR_EMC[this.tier.ordinal()];
    }

    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.UNCOMMON;
    }

    static {
        long emc = 204800000L;
        for (int i = 0; i < STAR_EMC.length; ++i) {
            ItemMagnumStar.STAR_EMC[i] = emc;
            emc *= 4L;
        }
    }
}

