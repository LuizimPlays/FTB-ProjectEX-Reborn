/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.client.util.ITooltipFlag
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.NonNullList
 *  net.minecraft.world.World
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.item.ProjectEXItems;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;

public class ItemCompressedCollector
extends Item {
    public ItemCompressedCollector() {
        this.func_77627_a(true);
    }

    public boolean func_77636_d(ItemStack stack) {
        return true;
    }

    public String func_77667_c(ItemStack stack) {
        return ProjectEXItems.COLLECTOR.func_77667_c(stack);
    }

    public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (EnumTier tier : EnumTier.VALUES) {
                items.add((Object)new ItemStack((Item)this, 1, tier.ordinal()));
            }
        }
    }

    public void func_77624_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.func_135052_a((String)"tile.projectex.collector.compressed", (Object[])new Object[0]));
    }
}

