/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.NonNullList
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.block.EnumMatter;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class ItemMatter
extends Item {
    public ItemMatter() {
        this.func_77627_a(true);
    }

    public String func_77667_c(ItemStack stack) {
        return this.func_77658_a() + "." + EnumMatter.byMeta(stack.func_77960_j()).func_176610_l();
    }

    public void func_150895_a(CreativeTabs tab, NonNullList<ItemStack> items) {
        if (this.func_194125_a(tab)) {
            for (EnumMatter matter : EnumMatter.VALUES) {
                items.add((Object)new ItemStack((Item)this, 1, matter.ordinal()));
            }
        }
    }
}

