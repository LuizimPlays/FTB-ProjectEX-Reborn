/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  moze_intel.projecte.api.item.IItemEmc
 *  moze_intel.projecte.api.item.IPedestalItem
 *  moze_intel.projecte.utils.NBTWhitelist
 *  net.minecraft.block.Block
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.item.EnumRarity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  net.minecraftforge.items.CapabilityItemHandler
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.latmod.mods.projectex.item;

import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.tile.TileRelay;
import java.util.Collections;
import java.util.List;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.item.IItemEmc;
import moze_intel.projecte.api.item.IPedestalItem;
import moze_intel.projecte.utils.NBTWhitelist;
import net.minecraft.block.Block;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

public class ItemFinalStar
extends Item
implements IItemEmc,
IPedestalItem {
    public ItemFinalStar() {
        this.func_77625_d(1);
    }

    public long addEmc(ItemStack stack, long toAdd) {
        return 0L;
    }

    public long extractEmc(ItemStack stack, long toRemove) {
        return toRemove;
    }

    public long getStoredEmc(ItemStack stack) {
        return 1000000000000000L;
    }

    public long getMaximumEmc(ItemStack stack) {
        return Long.MAX_VALUE;
    }

    public EnumRarity func_77613_e(ItemStack stack) {
        return EnumRarity.EPIC;
    }

    public void updateInPedestal(World world, BlockPos pos) {
        List items;
        if (ProjectEXConfig.general.final_star_update_interval <= 0) {
            return;
        }
        if (!world.field_72995_K && world.func_82737_E() % (long)ProjectEXConfig.general.final_star_update_interval == (long)TileRelay.mod(pos.hashCode(), ProjectEXConfig.general.final_star_update_interval) && !(items = world.func_72872_a(EntityItem.class, Block.field_185505_j.func_186670_a(pos).func_72321_a(0.0, 1.0, 0.0))).isEmpty()) {
            for (EnumFacing facing : EnumFacing.field_82609_l) {
                IItemHandler handler;
                if (facing == EnumFacing.UP) continue;
                TileEntity tileEntity = world.func_175625_s(pos.func_177972_a(facing));
                IItemHandler iItemHandler = handler = tileEntity == null ? null : (IItemHandler)tileEntity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, facing.func_176734_d());
                if (handler == null) continue;
                ItemStack stack = ((EntityItem)items.get(world.field_73012_v.nextInt(items.size()))).func_92059_d().func_77946_l();
                if (!ProjectEXConfig.general.final_star_copy_any_item && !ProjectEAPI.getEMCProxy().hasValue(stack)) continue;
                stack.func_190920_e(stack.func_77976_d());
                if (!stack.func_77981_g() && stack.func_77984_f()) {
                    stack.func_77964_b(0);
                }
                if (!ProjectEXConfig.general.final_star_copy_nbt && stack.func_77942_o() && !NBTWhitelist.shouldDupeWithNBT((ItemStack)stack)) {
                    stack.func_77982_d(new NBTTagCompound());
                }
                ItemHandlerHelper.insertItem((IItemHandler)handler, (ItemStack)stack, (boolean)false);
                return;
            }
        }
    }

    @SideOnly(value=Side.CLIENT)
    public List<String> getPedestalDescription() {
        return Collections.singletonList(I18n.func_135052_a((String)"item.projectex.final_star.tooltip", (Object[])new Object[0]));
    }
}

