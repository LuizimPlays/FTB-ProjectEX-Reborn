/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.tile.IEmcAcceptor
 *  moze_intel.projecte.api.tile.IEmcProvider
 *  moze_intel.projecte.gameObjs.tiles.RelayMK1Tile
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.ITickable
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.block.EnumTier;
import moze_intel.projecte.api.tile.IEmcAcceptor;
import moze_intel.projecte.api.tile.IEmcProvider;
import moze_intel.projecte.gameObjs.tiles.RelayMK1Tile;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;

public class TileRelay
extends TileEntity
implements ITickable,
IEmcAcceptor,
IEmcProvider {
    public static final IEmcAcceptor[] TEMP = new IEmcAcceptor[6];
    public long stored = 0L;
    private boolean isDirty = false;

    public static int mod(int i, int n) {
        return (i %= n) < 0 ? i + n : i;
    }

    public NBTTagCompound func_189515_b(NBTTagCompound nbt) {
        nbt.func_74772_a("stored_emc", this.stored);
        return super.func_189515_b(nbt);
    }

    public void func_145839_a(NBTTagCompound nbt) {
        this.stored = nbt.func_74763_f("stored_emc");
        super.func_145839_a(nbt);
    }

    public void onLoad() {
        if (this.field_145850_b.field_72995_K) {
            this.field_145850_b.field_175730_i.remove((Object)this);
        }
        this.func_145829_t();
    }

    public void func_73660_a() {
        if (this.field_145850_b.field_72995_K || this.stored <= 0L || this.field_145850_b.func_82737_E() % 20L != (long)TileRelay.mod(((Object)((Object)this)).hashCode(), 20)) {
            return;
        }
        int tempSize = 0;
        for (int i = 0; i < 6; ++i) {
            TileRelay.TEMP[i] = null;
            TileEntity tileEntity = this.field_145850_b.func_175625_s(this.field_174879_c.func_177972_a(EnumFacing.field_82609_l[i]));
            if (!(tileEntity instanceof IEmcAcceptor) || tileEntity instanceof TileRelay || tileEntity instanceof RelayMK1Tile) continue;
            TileRelay.TEMP[i] = (IEmcAcceptor)tileEntity;
            ++tempSize;
        }
        if (tempSize > 0) {
            long s = (long)Math.min((double)(this.stored / (long)tempSize), Math.min(9.223372036854776E18, EnumTier.byMeta((int)this.func_145832_p()).properties.relay_transfer));
            for (int i = 0; i < 6; ++i) {
                long a;
                if (TEMP[i] == null || (a = TEMP[i].acceptEMC(EnumFacing.field_82609_l[i].func_176734_d(), s)) <= 0L) continue;
                this.stored -= a;
                this.func_70296_d();
            }
        }
        if (this.isDirty) {
            this.isDirty = false;
            this.field_145850_b.func_175646_b(this.field_174879_c, (TileEntity)this);
        }
    }

    public void func_70296_d() {
        this.isDirty = true;
    }

    public long acceptEMC(EnumFacing facing, long v) {
        long v1 = Math.min(this.getMaximumEmc() - this.stored, v);
        if (v1 > 0L) {
            this.stored += v1;
            this.func_70296_d();
        }
        return v1;
    }

    public long provideEMC(EnumFacing facing, long v) {
        long v1 = Math.min(this.stored, v);
        if (v1 > 0L) {
            this.stored -= v1;
            this.func_70296_d();
        }
        return v1;
    }

    public long getStoredEmc() {
        return this.stored;
    }

    public long getMaximumEmc() {
        return Long.MAX_VALUE;
    }

    public void addRelayBonus(EnumFacing facing) {
        this.acceptEMC(facing, (long)EnumTier.byMeta((int)this.func_145832_p()).properties.relay_bonus);
    }
}

