/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  moze_intel.projecte.gameObjs.ObjHandler
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.ProjectEXUtils;
import com.latmod.mods.projectex.tile.AlchemyTableRecipe;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import moze_intel.projecte.gameObjs.ObjHandler;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class AlchemyTableRecipes {
    public static final AlchemyTableRecipes INSTANCE = new AlchemyTableRecipes();
    public final List<AlchemyTableRecipe> LIST = new ArrayList<AlchemyTableRecipe>();

    public void add(ItemStack input, ItemStack output) {
        AlchemyTableRecipe recipe = new AlchemyTableRecipe();
        recipe.input = ProjectEXUtils.fixOutput(input);
        recipe.output = ProjectEXUtils.fixOutput(output);
        this.LIST.add(recipe);
    }

    public void addSteps(ItemStack ... stacks) {
        for (int i = 1; i < stacks.length; ++i) {
            this.add(stacks[i - 1], stacks[i]);
        }
    }

    public void addDefaultRecipes() {
        this.addSteps(new ItemStack(Items.field_151044_h, 1, 1), new ItemStack(Items.field_151044_h, 1, 0));
        this.addSteps(new ItemStack(Items.field_151137_ax), new ItemStack(Items.field_151016_H), new ItemStack(Items.field_151114_aO), new ItemStack(Items.field_151065_br), new ItemStack(Items.field_151072_bj));
        this.addSteps(new ItemStack(Items.field_151100_aR, 1, 4), new ItemStack(Items.field_179562_cC), new ItemStack(Items.field_179563_cD));
        this.addSteps(new ItemStack(ObjHandler.covalence, 1, 0), new ItemStack(ObjHandler.covalence, 1, 1), new ItemStack(ObjHandler.covalence, 1, 2));
        this.addSteps(new ItemStack(Items.field_151082_bd), new ItemStack(Items.field_151078_bh), new ItemStack(Items.field_151116_aA), new ItemStack(Items.field_151070_bp), new ItemStack(Items.field_151103_aS));
        this.addSteps(new ItemStack(Items.field_151014_N), new ItemStack(Items.field_151127_ba), new ItemStack(Items.field_151034_e), new ItemStack(Items.field_151172_bF), new ItemStack(Items.field_185164_cV), new ItemStack(Items.field_151174_bG), new ItemStack(Blocks.field_150423_aK));
        this.addSteps(new ItemStack(Items.field_151106_aX), new ItemStack(Items.field_151025_P), new ItemStack(Items.field_151105_aU));
        this.addSteps(new ItemStack(ObjHandler.fuels, 1, 0), new ItemStack(Blocks.field_150451_bX), new ItemStack(Items.field_151129_at), new ItemStack(Blocks.field_150343_Z));
        this.addSteps(new ItemStack((Block)Blocks.field_150362_t, 1), new ItemStack((Block)Blocks.field_150329_H, 1, 1), new ItemStack((Block)Blocks.field_150329_H, 1, 2), new ItemStack(Blocks.field_150395_bd), new ItemStack(Blocks.field_150392_bi));
        this.add(new ItemStack(Items.field_151061_bv), new ItemStack(Items.field_185161_cS));
        this.add(new ItemStack(Items.field_151007_F), new ItemStack(Items.field_151008_G));
        this.add(new ItemStack(Items.field_151055_y), new ItemStack((Block)Blocks.field_150329_H, 1, 0));
    }

    public boolean hasOutput(ItemStack input) {
        return this.getOutput(input) != null;
    }

    @Nullable
    public AlchemyTableRecipe getOutput(ItemStack input) {
        if (input.func_190926_b()) {
            return null;
        }
        Item item = input.func_77973_b();
        int meta = !input.func_77981_g() && input.func_77984_f() ? 0 : input.func_77960_j();
        for (AlchemyTableRecipe recipe : this.LIST) {
            if (item != recipe.input.func_77973_b() || meta != recipe.input.func_77960_j()) continue;
            return recipe;
        }
        return null;
    }
}

