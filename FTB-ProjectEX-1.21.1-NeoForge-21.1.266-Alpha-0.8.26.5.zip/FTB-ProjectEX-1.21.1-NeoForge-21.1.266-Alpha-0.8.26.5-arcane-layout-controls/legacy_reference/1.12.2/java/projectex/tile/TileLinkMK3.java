/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.tile.TileLink;

public class TileLinkMK3
extends TileLink {
    public TileLinkMK3() {
        super(1, 54);
    }

    @Override
    public boolean learnItems() {
        return true;
    }
}

