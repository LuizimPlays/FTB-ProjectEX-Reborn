/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.tile.TileLink;

public class TileLinkMK1
extends TileLink {
    public TileLinkMK1() {
        super(18, 1);
    }
}

