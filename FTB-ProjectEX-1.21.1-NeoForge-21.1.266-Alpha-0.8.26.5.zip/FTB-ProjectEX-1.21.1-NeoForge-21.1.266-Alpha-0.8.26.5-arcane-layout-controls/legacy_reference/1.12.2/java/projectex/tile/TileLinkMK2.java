/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.tile.TileLink;

public class TileLinkMK2
extends TileLink {
    public TileLinkMK2() {
        super(1, 9);
    }

    @Override
    public boolean learnItems() {
        return true;
    }
}

