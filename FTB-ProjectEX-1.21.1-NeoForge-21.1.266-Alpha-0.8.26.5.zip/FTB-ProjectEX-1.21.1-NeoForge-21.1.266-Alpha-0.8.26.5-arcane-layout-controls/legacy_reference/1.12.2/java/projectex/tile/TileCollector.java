/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.tile.IEmcAcceptor
 *  moze_intel.projecte.gameObjs.tiles.RelayMK1Tile
 *  moze_intel.projecte.gameObjs.tiles.RelayMK2Tile
 *  moze_intel.projecte.gameObjs.tiles.RelayMK3Tile
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.ITickable
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.tile.TileRelay;
import moze_intel.projecte.api.tile.IEmcAcceptor;
import moze_intel.projecte.gameObjs.tiles.RelayMK1Tile;
import moze_intel.projecte.gameObjs.tiles.RelayMK2Tile;
import moze_intel.projecte.gameObjs.tiles.RelayMK3Tile;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;

public class TileCollector
extends TileEntity
implements ITickable {
    public void onLoad() {
        if (this.field_145850_b.field_72995_K) {
            this.field_145850_b.field_175730_i.remove((Object)this);
        }
        this.func_145829_t();
    }

    public void func_73660_a() {
        if (this.field_145850_b.field_72995_K || this.field_145850_b.func_82737_E() % 20L != (long)TileRelay.mod(((Object)((Object)this)).hashCode(), 20)) {
            return;
        }
        int tempSize = 0;
        for (int i = 0; i < 6; ++i) {
            IEmcAcceptor emcAcceptor;
            TileRelay.TEMP[i] = null;
            TileEntity tileEntity = this.field_145850_b.func_175625_s(this.field_174879_c.func_177972_a(EnumFacing.field_82609_l[i]));
            if (!(tileEntity instanceof IEmcAcceptor)) continue;
            TileRelay.TEMP[i] = emcAcceptor = (IEmcAcceptor)tileEntity;
            ++tempSize;
            if (emcAcceptor instanceof TileRelay) {
                ((TileRelay)emcAcceptor).addRelayBonus(EnumFacing.field_82609_l[i].func_176734_d());
                continue;
            }
            if (emcAcceptor instanceof RelayMK3Tile) {
                emcAcceptor.acceptEMC(EnumFacing.field_82609_l[i].func_176734_d(), 10L);
                continue;
            }
            if (emcAcceptor instanceof RelayMK2Tile) {
                emcAcceptor.acceptEMC(EnumFacing.field_82609_l[i].func_176734_d(), 3L);
                continue;
            }
            if (!(emcAcceptor instanceof RelayMK1Tile)) continue;
            emcAcceptor.acceptEMC(EnumFacing.field_82609_l[i].func_176734_d(), 1L);
        }
        if (tempSize > 0) {
            long s = (long)(EnumTier.byMeta((int)this.func_145832_p()).properties.collector_output / (double)tempSize);
            for (int i = 0; i < 6; ++i) {
                IEmcAcceptor emcAcceptor = TileRelay.TEMP[i];
                if (emcAcceptor == null) continue;
                emcAcceptor.acceptEMC(EnumFacing.field_82609_l[i].func_176734_d(), s);
            }
        }
    }

    public void func_70296_d() {
    }
}

