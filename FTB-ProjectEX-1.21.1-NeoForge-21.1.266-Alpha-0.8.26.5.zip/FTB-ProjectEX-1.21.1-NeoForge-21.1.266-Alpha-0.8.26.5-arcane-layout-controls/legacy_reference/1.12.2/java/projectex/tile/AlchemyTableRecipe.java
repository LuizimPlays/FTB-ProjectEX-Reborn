/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.tile;

import moze_intel.projecte.api.ProjectEAPI;
import net.minecraft.item.ItemStack;

public class AlchemyTableRecipe {
    public ItemStack input = ItemStack.field_190927_a;
    public ItemStack output = ItemStack.field_190927_a;
    public long emcOverride = 0L;
    public int progressOverride = 0;

    public long getTotalCost() {
        if (this.emcOverride > 0L) {
            return this.emcOverride;
        }
        return Math.max(64L, (ProjectEAPI.getEMCProxy().getValue(this.input) + ProjectEAPI.getEMCProxy().getValue(this.output)) * 3L);
    }

    public int getTotalProgress() {
        return this.progressOverride > 0 ? this.progressOverride : 200;
    }
}

