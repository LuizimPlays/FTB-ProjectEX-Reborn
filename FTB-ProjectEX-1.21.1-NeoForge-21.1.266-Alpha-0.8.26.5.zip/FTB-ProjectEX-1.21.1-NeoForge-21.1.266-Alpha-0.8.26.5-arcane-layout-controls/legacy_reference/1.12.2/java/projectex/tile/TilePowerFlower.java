/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EntityPlayerMP
 *  net.minecraft.nbt.NBTTagCompound
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.ITickable
 */
package com.latmod.mods.projectex.tile;

import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.integration.PersonalEMC;
import com.latmod.mods.projectex.tile.TileRelay;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;

public class TilePowerFlower
extends TileEntity
implements ITickable {
    public UUID owner = new UUID(0L, 0L);
    public String name = "";
    public long storedEMC = 0L;

    public void func_145839_a(NBTTagCompound nbt) {
        this.owner = nbt.func_186857_a("owner");
        this.name = nbt.func_74779_i("name");
        double storedEMC1 = nbt.func_74769_h("emc");
        this.storedEMC = storedEMC1 > 9.223372036854776E18 ? Long.MAX_VALUE : (long)storedEMC1;
        super.func_145839_a(nbt);
    }

    public NBTTagCompound func_189515_b(NBTTagCompound nbt) {
        nbt.func_186854_a("owner", this.owner);
        nbt.func_74778_a("name", this.name);
        if (this.storedEMC > 0L) {
            nbt.func_74772_a("emc", this.storedEMC);
        }
        return super.func_189515_b(nbt);
    }

    public void onLoad() {
        if (this.field_145850_b.field_72995_K) {
            this.field_145850_b.field_175730_i.remove((Object)this);
        }
        this.func_145829_t();
    }

    public void func_73660_a() {
        if (this.field_145850_b.field_72995_K || this.field_145850_b.func_82737_E() % 20L != (long)TileRelay.mod(((Object)((Object)this)).hashCode(), 20)) {
            return;
        }
        this.storedEMC = (long)((double)this.storedEMC + EnumTier.byMeta((int)this.func_145832_p()).properties.powerFlowerOutput());
        EntityPlayerMP player = this.field_145850_b.func_73046_m().func_184103_al().func_177451_a(this.owner);
        if (player != null) {
            PersonalEMC.add(PersonalEMC.get((EntityPlayer)player), this.storedEMC);
            this.storedEMC = 0L;
        } else {
            this.field_145850_b.func_175646_b(this.field_174879_c, (TileEntity)this);
        }
    }
}

