/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.utils.Constants
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.FMLCommonHandler
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.Mod$Instance
 *  net.minecraftforge.fml.common.SidedProxy
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLInterModComms
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  net.minecraftforge.fml.common.network.IGuiHandler
 *  net.minecraftforge.fml.common.network.NetworkRegistry
 *  net.minecraftforge.fml.relauncher.Side
 */
package com.latmod.mods.projectex;

import com.latmod.mods.projectex.ProjectEXCommon;
import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.ProjectEXKeyBindings;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.gui.ProjectEXGuiHandler;
import com.latmod.mods.projectex.item.ProjectEXItems;
import com.latmod.mods.projectex.net.ProjectEXNetHandler;
import com.latmod.mods.projectex.tile.AlchemyTableRecipes;
import com.latmod.mods.projectex.tile.TilePowerFlower;
import java.lang.reflect.Field;
import moze_intel.projecte.utils.Constants;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInterModComms;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.IGuiHandler;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid="projectex", name="Project EX", version="1.2.0.40", dependencies="required-after:projecte", acceptedMinecraftVersions="[1.12.2]")
public class ProjectEX {
    public static final String MOD_ID = "projectex";
    public static final String MOD_NAME = "Project EX";
    public static final String VERSION = "1.2.0.40";
    public static final CreativeTabs TAB = new CreativeTabs("projectex"){

        public ItemStack func_78016_d() {
            return new ItemStack(ProjectEXItems.PERSONAL_LINK);
        }
    };
    @Mod.Instance(value="projectex")
    public static ProjectEX INSTANCE;
    @SidedProxy(serverSide="com.latmod.mods.projectex.ProjectEXCommon", clientSide="com.latmod.mods.projectex.client.ProjectEXClient")
    public static ProjectEXCommon PROXY;

    @Mod.EventHandler
    public void onPreInit(FMLPreInitializationEvent event) {
        ProjectEXNetHandler.init();
        NetworkRegistry.INSTANCE.registerGuiHandler((Object)this, (IGuiHandler)new ProjectEXGuiHandler());
    }

    @Mod.EventHandler
    public void onInit(FMLInitializationEvent event) {
        if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
            try {
                Field field = Constants.class.getDeclaredField("EMC_FORMATTER");
                field.setAccessible(true);
                Field modifiersField = Field.class.getDeclaredField("modifiers");
                modifiersField.setAccessible(true);
                modifiersField.setInt(field, field.getModifiers() & 0xFFFFFFEF);
                field.set(null, EMCFormat.INSTANCE);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            ProjectEXKeyBindings.init();
        }
        if (ProjectEXConfig.general.blacklist_power_flower_from_watch) {
            FMLInterModComms.sendMessage((String)"projecte", (String)"timewatchblacklist", (String)TilePowerFlower.class.getName());
        }
        AlchemyTableRecipes.INSTANCE.addDefaultRecipes();
    }
}

