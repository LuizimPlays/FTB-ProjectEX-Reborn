/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.entity.player.EntityPlayer
 */
package com.latmod.mods.projectex;

import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;

public class ProjectEXCommon {
    @Nullable
    public EntityPlayer getClientPlayer() {
        return null;
    }

    public void updateEMC(long emc) {
    }
}

