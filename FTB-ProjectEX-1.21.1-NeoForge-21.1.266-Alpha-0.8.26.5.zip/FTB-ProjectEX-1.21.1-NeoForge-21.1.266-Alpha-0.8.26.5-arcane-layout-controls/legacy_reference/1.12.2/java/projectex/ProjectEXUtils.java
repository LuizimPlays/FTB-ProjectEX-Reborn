/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.capabilities.IKnowledgeProvider
 *  moze_intel.projecte.api.event.PlayerAttemptLearnEvent
 *  moze_intel.projecte.utils.NBTWhitelist
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.latmod.mods.projectex;

import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.event.PlayerAttemptLearnEvent;
import moze_intel.projecte.utils.NBTWhitelist;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.items.ItemHandlerHelper;

public class ProjectEXUtils {
    public static ItemStack fixOutput(ItemStack stack) {
        if (stack.func_190926_b()) {
            return ItemStack.field_190927_a;
        }
        ItemStack stack1 = ItemHandlerHelper.copyStackWithSize((ItemStack)stack, (int)1);
        if (!stack1.func_77981_g() && stack1.func_77984_f()) {
            stack1.func_77964_b(0);
        }
        if (!NBTWhitelist.shouldDupeWithNBT((ItemStack)stack1)) {
            stack1.func_77982_d(null);
            try {
                stack1.func_77973_b().readNBTShareTag(stack1, null);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return stack1;
    }

    public static int addKnowledge(EntityPlayer player, IKnowledgeProvider knowledgeProvider, ItemStack stack) {
        if (stack.func_190926_b()) {
            return 0;
        }
        if (!knowledgeProvider.hasKnowledge(stack)) {
            if (MinecraftForge.EVENT_BUS.post((Event)new PlayerAttemptLearnEvent(player, stack))) {
                return 0;
            }
            knowledgeProvider.addKnowledge(stack);
            return 2;
        }
        return 1;
    }
}

