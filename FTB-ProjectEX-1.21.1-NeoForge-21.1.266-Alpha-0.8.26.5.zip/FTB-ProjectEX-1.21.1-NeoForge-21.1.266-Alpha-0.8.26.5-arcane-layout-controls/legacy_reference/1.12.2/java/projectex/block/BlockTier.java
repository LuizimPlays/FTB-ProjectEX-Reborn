/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.MapColor
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.properties.PropertyEnum
 *  net.minecraft.block.state.BlockStateContainer
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.NonNullList
 */
package com.latmod.mods.projectex.block;

import com.latmod.mods.projectex.block.EnumTier;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class BlockTier
extends Block {
    public static final PropertyEnum<EnumTier> TIER = PropertyEnum.func_177709_a((String)"tier", EnumTier.class);

    public BlockTier(Material m, MapColor c) {
        super(m, c);
    }

    protected BlockStateContainer func_180661_e() {
        return new BlockStateContainer((Block)this, new IProperty[]{TIER});
    }

    @Deprecated
    public IBlockState func_176203_a(int meta) {
        return this.func_176223_P().func_177226_a(TIER, (Comparable)((Object)EnumTier.byMeta(meta)));
    }

    public int func_176201_c(IBlockState state) {
        return ((EnumTier)((Object)state.func_177229_b(TIER))).ordinal();
    }

    public boolean hasTileEntity(IBlockState state) {
        return true;
    }

    public int func_180651_a(IBlockState state) {
        return ((EnumTier)((Object)state.func_177229_b(TIER))).ordinal();
    }

    public void func_149666_a(CreativeTabs itemIn, NonNullList<ItemStack> items) {
        for (EnumTier tier : EnumTier.VALUES) {
            items.add((Object)new ItemStack((Block)this, 1, tier.ordinal()));
        }
    }
}

