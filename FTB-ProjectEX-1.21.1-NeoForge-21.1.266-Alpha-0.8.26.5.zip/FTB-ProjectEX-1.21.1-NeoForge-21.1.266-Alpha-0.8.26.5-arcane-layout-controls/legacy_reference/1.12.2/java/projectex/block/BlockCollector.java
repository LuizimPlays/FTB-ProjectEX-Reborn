/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.material.MapColor
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.client.util.ITooltipFlag
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.text.TextFormatting
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.latmod.mods.projectex.block;

import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.block.BlockTier;
import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.tile.TileCollector;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockCollector
extends BlockTier {
    public BlockCollector() {
        super(Material.field_151592_s, MapColor.field_151673_t);
        this.func_149711_c(0.3f);
    }

    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TileCollector();
    }

    @SideOnly(value=Side.CLIENT)
    public void func_190948_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        ProjectEXConfig.BlockTier properties = EnumTier.byMeta((int)stack.func_77960_j()).properties;
        tooltip.add(I18n.func_135052_a((String)"tile.projectex.collector.tooltip", (Object[])new Object[0]));
        tooltip.add(I18n.func_135052_a((String)"tile.projectex.collector.emc_produced", (Object[])new Object[]{TextFormatting.GREEN + EMCFormat.INSTANCE.format(properties.collector_output)}));
    }
}

