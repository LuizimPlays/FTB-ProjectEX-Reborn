/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.world.World
 */
package com.latmod.mods.projectex.block;

import com.latmod.mods.projectex.block.BlockLink;
import com.latmod.mods.projectex.tile.TileLinkMK2;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

public class BlockLinkMK2
extends BlockLink {
    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TileLinkMK2();
    }
}

