/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.IStringSerializable
 */
package com.latmod.mods.projectex.block;

import com.latmod.mods.projectex.item.ProjectEXItems;
import java.util.function.Supplier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public enum EnumMatter implements IStringSerializable,
Supplier<ItemStack>
{
    MAGENTA("magenta"),
    PINK("pink"),
    PURPLE("purple"),
    VIOLET("violet"),
    BLUE("blue"),
    CYAN("cyan"),
    GREEN("green"),
    LIME("lime"),
    YELLOW("yellow"),
    ORANGE("orange"),
    WHITE("white"),
    FADING("fading");

    public static final EnumMatter[] VALUES;
    private final String name;

    public static EnumMatter byMeta(int meta) {
        return meta < 0 || meta >= VALUES.length ? MAGENTA : VALUES[meta];
    }

    private EnumMatter(String n2) {
        this.name = n2;
    }

    public String func_176610_l() {
        return this.name;
    }

    @Override
    public ItemStack get() {
        return new ItemStack(ProjectEXItems.MATTER, 1, this.ordinal());
    }

    static {
        VALUES = EnumMatter.values();
    }
}

