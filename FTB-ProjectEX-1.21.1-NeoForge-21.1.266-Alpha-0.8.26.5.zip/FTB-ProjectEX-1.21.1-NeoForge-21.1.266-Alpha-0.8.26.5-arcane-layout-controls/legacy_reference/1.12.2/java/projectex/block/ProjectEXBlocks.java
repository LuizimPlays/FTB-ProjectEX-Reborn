/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraftforge.fml.common.registry.GameRegistry$ObjectHolder
 */
package com.latmod.mods.projectex.block;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraftforge.fml.common.registry.GameRegistry;

@GameRegistry.ObjectHolder(value="projectex")
public class ProjectEXBlocks {
    public static final Block ENERGY_LINK = Blocks.field_150350_a;
    public static final Block PERSONAL_LINK = Blocks.field_150350_a;
    public static final Block REFINED_LINK = Blocks.field_150350_a;
    public static final Block COMPRESSED_REFINED_LINK = Blocks.field_150350_a;
    public static final Block COLLECTOR = Blocks.field_150350_a;
    public static final Block RELAY = Blocks.field_150350_a;
    public static final Block POWER_FLOWER = Blocks.field_150350_a;
    public static final Block STONE_TABLE = Blocks.field_150350_a;
    public static final Block ALCHEMY_TABLE = Blocks.field_150350_a;
}

