/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.block.material.MapColor
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.client.util.ITooltipFlag
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentString
 *  net.minecraft.util.text.TextFormatting
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 */
package com.latmod.mods.projectex.block;

import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.block.BlockTier;
import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.tile.TilePowerFlower;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockPowerFlower
extends BlockTier {
    public BlockPowerFlower() {
        super(Material.field_151592_s, MapColor.field_151673_t);
        this.func_149711_c(0.3f);
    }

    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TilePowerFlower();
    }

    public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (player.func_70093_af()) {
            TileEntity tileEntity;
            if (!world.field_72995_K && (tileEntity = world.func_175625_s(pos)) instanceof TilePowerFlower) {
                player.func_146105_b((ITextComponent)new TextComponentString(((TilePowerFlower)tileEntity).name), true);
            }
            return true;
        }
        return false;
    }

    public void func_180633_a(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
        TileEntity tileEntity = world.func_175625_s(pos);
        if (tileEntity instanceof TilePowerFlower) {
            ((TilePowerFlower)tileEntity).owner = placer.func_110124_au();
            ((TilePowerFlower)tileEntity).name = placer.func_70005_c_();
            tileEntity.func_70296_d();
        }
    }

    @Deprecated
    public boolean func_149662_c(IBlockState state) {
        return false;
    }

    @Deprecated
    public boolean func_149686_d(IBlockState state) {
        return false;
    }

    @Deprecated
    public boolean func_176225_a(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing side) {
        IBlockState state1;
        if (side != EnumFacing.DOWN && (state1 = world.func_180495_p(pos.func_177972_a(side))).func_177230_c() == this) {
            return false;
        }
        return super.func_176225_a(state, world, pos, side);
    }

    @SideOnly(value=Side.CLIENT)
    public void func_190948_a(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        ProjectEXConfig.BlockTier properties = EnumTier.byMeta((int)stack.func_77960_j()).properties;
        tooltip.add(I18n.func_135052_a((String)"tile.projectex.collector.tooltip", (Object[])new Object[0]));
        tooltip.add(I18n.func_135052_a((String)"tile.projectex.collector.emc_produced", (Object[])new Object[]{TextFormatting.GREEN + EMCFormat.INSTANCE.format(properties.powerFlowerOutput())}));
    }
}

