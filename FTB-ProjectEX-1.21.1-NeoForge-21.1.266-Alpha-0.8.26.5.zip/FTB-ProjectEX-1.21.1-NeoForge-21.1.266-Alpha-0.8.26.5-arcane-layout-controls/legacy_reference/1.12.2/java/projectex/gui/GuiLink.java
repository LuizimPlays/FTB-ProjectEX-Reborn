/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.audio.SoundHandler
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.inventory.Container
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.text.TextFormatting
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.client.ProjectEXClientEventHandler;
import com.latmod.mods.projectex.gui.ContainerLink;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.integration.PersonalEMC;
import com.latmod.mods.projectex.tile.TileLinkMK2;
import com.latmod.mods.projectex.tile.TileLinkMK3;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.Container;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class GuiLink
extends GuiContainer {
    private static final ResourceLocation TEXTURE_MK1 = new ResourceLocation("projectex", "textures/gui/personal_link.png");
    private static final ResourceLocation TEXTURE_MK2 = new ResourceLocation("projectex", "textures/gui/refined_link.png");
    private static final ResourceLocation TEXTURE_MK3 = new ResourceLocation("projectex", "textures/gui/compressed_refined_link.png");
    public final ContainerLink container;

    public GuiLink(ContainerLink c) {
        super((Container)c);
        this.container = c;
        if (this.container.link instanceof TileLinkMK3) {
            this.field_147000_g = 244;
        }
    }

    public void func_73866_w_() {
        super.func_73866_w_();
        if (this.container.link instanceof TileLinkMK3) {
            for (int i = 0; i < 54; ++i) {
                this.field_146292_n.add(new ButtonFilter(i, this.field_147003_i + 8 + i % 9 * 18, this.field_147009_r + 41 + i / 9 * 18));
            }
        } else if (this.container.link instanceof TileLinkMK2) {
            for (int i = 0; i < 9; ++i) {
                this.field_146292_n.add(new ButtonFilter(i, this.field_147003_i + 89 + i % 3 * 18, this.field_147009_r + 17 + i / 3 * 18));
            }
        } else {
            this.field_146292_n.add(new ButtonFilter(0, this.field_147003_i + 152, this.field_147009_r + 35));
        }
    }

    protected void func_146284_a(GuiButton button) {
        int id;
        if (button instanceof ButtonFilter && this.container.func_75140_a(this.container.player, id = button.field_146127_k + (GuiLink.func_146271_m() ? 2 : (GuiLink.func_146272_n() ? 1 : 0)) * this.container.link.outputSlots.length)) {
            this.field_146297_k.field_71442_b.func_78756_a(this.container.field_75152_c, id);
        }
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }

    public void func_191948_b(int x, int y) {
        super.func_191948_b(x, y);
        for (GuiButton button : this.field_146292_n) {
            if (!button.func_146115_a() || !(button instanceof ButtonFilter) || this.container.link.outputSlots[button.field_146127_k].func_190926_b()) continue;
            this.func_146285_a(this.container.link.outputSlots[button.field_146127_k], x, y);
        }
    }

    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        if (this.container.link instanceof TileLinkMK3) {
            this.field_146297_k.func_110434_K().func_110577_a(TEXTURE_MK3);
        } else if (this.container.link instanceof TileLinkMK2) {
            this.field_146297_k.func_110434_K().func_110577_a(TEXTURE_MK2);
        } else {
            this.field_146297_k.func_110434_K().func_110577_a(TEXTURE_MK1);
        }
        this.func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
    }

    protected void func_146979_b(int mouseX, int mouseY) {
        double emc = PersonalEMC.get(this.container.player).getEmc();
        this.field_146289_q.func_78276_b(this.container.link.name, 8, 6, 0x404040);
        String s = EMCFormat.INSTANCE.format(emc);
        if ((double)ProjectEXClientEventHandler.emcs != 0.0) {
            s = s + ((double)ProjectEXClientEventHandler.emcs > 0.0 ? TextFormatting.DARK_GREEN + "+" : TextFormatting.RED + "-") + EMCFormat.INSTANCE.format(Math.abs(ProjectEXClientEventHandler.emcs)) + "/s";
        }
        if (this.container.link instanceof TileLinkMK3) {
            this.field_146289_q.func_78276_b(s, 8, 151, 0x404040);
        } else {
            this.field_146289_q.func_78276_b(s, 8, 73, 0x404040);
        }
    }

    public List<GuiButton> getButtons() {
        return this.field_146292_n;
    }

    public class ButtonFilter
    extends GuiButton {
        public ButtonFilter(int id, int x, int y) {
            super(id, x, y, 16, 16, "");
        }

        public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
            if (this.field_146125_m) {
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                this.field_146123_n = mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g;
                GlStateManager.func_179147_l();
                GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
                GlStateManager.func_187401_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
                if (this.field_146123_n) {
                    ButtonFilter.func_73734_a((int)this.field_146128_h, (int)this.field_146129_i, (int)(this.field_146128_h + this.field_146120_f), (int)(this.field_146129_i + this.field_146121_g), (int)-2130706433);
                }
                if (!GuiLink.this.container.link.outputSlots[this.field_146127_k].func_190926_b()) {
                    this.field_73735_i = 100.0f;
                    ((GuiLink)GuiLink.this).field_146296_j.field_77023_b = 100.0f;
                    GlStateManager.func_179126_j();
                    RenderHelper.func_74520_c();
                    GuiLink.this.field_146296_j.func_184391_a((EntityLivingBase)mc.field_71439_g, GuiLink.this.container.link.outputSlots[this.field_146127_k], this.field_146128_h, this.field_146129_i);
                    GuiLink.this.field_146296_j.func_180453_a(GuiLink.this.field_146289_q, GuiLink.this.container.link.outputSlots[this.field_146127_k], this.field_146128_h, this.field_146129_i, "");
                    ((GuiLink)GuiLink.this).field_146296_j.field_77023_b = 0.0f;
                    this.field_73735_i = 0.0f;
                }
                this.func_146119_b(mc, mouseX, mouseY);
            }
        }

        public void func_146113_a(SoundHandler soundHandlerIn) {
        }
    }
}

