/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.text.TextFormatting
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.gui.ButtonArrow;
import com.latmod.mods.projectex.gui.ButtonBurnItem;
import com.latmod.mods.projectex.gui.ButtonCreateItem;
import com.latmod.mods.projectex.gui.ButtonLearnItem;
import com.latmod.mods.projectex.gui.ButtonUnlearnItem;
import com.latmod.mods.projectex.gui.ContainerStoneTable;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.gui.GuiTableBase;
import com.latmod.mods.projectex.integration.PersonalEMC;
import java.awt.Rectangle;
import java.util.List;
import moze_intel.projecte.api.ProjectEAPI;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class GuiStoneTable
extends GuiTableBase {
    private static final ResourceLocation TEXTURE = new ResourceLocation("projectex", "textures/gui/stone_table.png");

    public GuiStoneTable(ContainerStoneTable c) {
        super(c);
        this.field_147000_g = 217;
    }

    @Override
    public Rectangle getTextBox() {
        return new Rectangle(this.field_147003_i + 8, this.field_147009_r + 7, 160, 11);
    }

    @Override
    public void addButtons() {
        this.func_189646_b(new ButtonArrow(this, 1, this.field_147003_i + 7, this.field_147009_r + 20, 196, 0));
        this.func_189646_b(new ButtonArrow(this, 2, this.field_147003_i + 151, this.field_147009_r + 20, 215, 0));
        this.func_189646_b(new ButtonBurnItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 28));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 110, this.field_147009_r + 38));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 50, this.field_147009_r + 38));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 120, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 40, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 110, this.field_147009_r + 98));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 50, this.field_147009_r + 98));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 108));
        this.func_189646_b(new ButtonLearnItem(this.table, 4, this.field_147003_i + 8, this.field_147009_r + 115));
        this.func_189646_b(new ButtonUnlearnItem(this.table, 5, this.field_147003_i + 152, this.field_147009_r + 115));
    }

    @Override
    public ResourceLocation getTexture() {
        return TEXTURE;
    }

    protected void func_146979_b(int mouseX, int mouseY) {
        String s = EMCFormat.INSTANCE.format(PersonalEMC.get((EntityPlayer)this.field_146297_k.field_71439_g).getEmc());
        this.field_146289_q.func_175063_a(s, (float)(this.field_146999_f - this.field_146289_q.func_78256_a(s)) / 2.0f, -9.0f, -4868683);
    }

    public List<String> func_191927_a(ItemStack stack) {
        List list = super.func_191927_a(stack);
        if (!ProjectEXConfig.general.isStoneTableWhitelisted(stack) && ProjectEAPI.getEMCProxy().hasValue(stack)) {
            list.add(TextFormatting.RED + I18n.func_135052_a((String)"gui.stone_table.cant_use", (Object[])new Object[0]));
        }
        return list;
    }
}

