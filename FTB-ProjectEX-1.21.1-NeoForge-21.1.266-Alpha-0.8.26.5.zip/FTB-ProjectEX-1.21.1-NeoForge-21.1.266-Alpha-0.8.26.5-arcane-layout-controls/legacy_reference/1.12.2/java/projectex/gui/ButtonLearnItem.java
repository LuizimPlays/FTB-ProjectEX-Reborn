/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.gui.ButtonSlot;
import com.latmod.mods.projectex.gui.ContainerTableBase;

public class ButtonLearnItem
extends ButtonSlot {
    public ButtonLearnItem(ContainerTableBase t, int id, int x, int y) {
        super(t, id, x, y);
    }
}

