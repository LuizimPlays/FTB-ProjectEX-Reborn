/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  moze_intel.projecte.api.capabilities.IKnowledgeProvider
 *  moze_intel.projecte.api.item.IItemEmc
 *  moze_intel.projecte.config.ProjectEConfig
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.items.ItemHandlerHelper
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.ProjectEXUtils;
import com.latmod.mods.projectex.integration.PersonalEMC;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.item.IItemEmc;
import moze_intel.projecte.config.ProjectEConfig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.ItemHandlerHelper;

public class ContainerTableBase
extends Container {
    public static final int BURN = 1;
    public static final int TAKE_STACK = 2;
    public static final int TAKE_ONE = 3;
    public static final int BURN_ALT = 4;
    public static final int LEARN = 5;
    public static final int UNLEARN = 6;
    public final EntityPlayer player;
    public final IKnowledgeProvider playerData;
    public KnowledgeUpdate knowledgeUpdate;

    public ContainerTableBase(EntityPlayer p) {
        this.player = p;
        this.playerData = PersonalEMC.get(this.player);
    }

    public ItemStack func_82846_b(EntityPlayer player, int index) {
        Slot slot = (Slot)this.field_75151_b.get(index);
        ItemStack stack = slot.func_75211_c();
        if (!stack.func_190926_b()) {
            if (!ProjectEAPI.getEMCProxy().hasValue(stack)) {
                return ItemStack.field_190927_a;
            }
            ItemStack stack1 = ProjectEXUtils.fixOutput(stack);
            if (!this.isItemValid(stack1)) {
                return ItemStack.field_190927_a;
            }
            int k = ProjectEXUtils.addKnowledge(player, this.playerData, stack1);
            if (k == 0) {
                return ItemStack.field_190927_a;
            }
            if (k == 2 && this.knowledgeUpdate != null) {
                this.knowledgeUpdate.updateKnowledge();
            }
            PersonalEMC.add(this.playerData, (long)((double)(ProjectEAPI.getEMCProxy().getValue(stack) * (long)stack.func_190916_E()) * ProjectEConfig.difficulty.covalenceLoss));
            slot.func_75215_d(ItemStack.field_190927_a);
            return stack1;
        }
        return ItemStack.field_190927_a;
    }

    public boolean func_75145_c(EntityPlayer player) {
        return true;
    }

    public boolean isItemValid(ItemStack stack) {
        return true;
    }

    public boolean clickGuiSlot(ItemStack type, int mode) {
        ItemStack stack = this.player.field_71071_by.func_70445_o();
        if (mode == 1 || mode == 4) {
            if (mode == 4 && stack.func_77973_b() instanceof IItemEmc) {
                IItemEmc emcItem = (IItemEmc)stack.func_77973_b();
                long stored = emcItem.getStoredEmc(stack);
                if (stored > 0L) {
                    PersonalEMC.add(this.playerData, emcItem.extractEmc(stack, stored));
                } else {
                    PersonalEMC.remove(this.playerData, emcItem.addEmc(stack, Math.min(this.playerData.getEmc(), emcItem.getMaximumEmc(stack))));
                }
                this.player.field_71071_by.func_70437_b(stack);
                return true;
            }
            if (stack.func_190926_b() || !ProjectEAPI.getEMCProxy().hasValue(stack)) {
                return false;
            }
            ItemStack stack1 = ProjectEXUtils.fixOutput(stack);
            if (!this.isItemValid(stack1)) {
                return false;
            }
            int k = ProjectEXUtils.addKnowledge(this.player, this.playerData, stack1);
            if (k == 0) {
                return false;
            }
            if (k == 2 && this.knowledgeUpdate != null) {
                this.knowledgeUpdate.updateKnowledge();
            }
            PersonalEMC.add(this.playerData, (long)((double)(ProjectEAPI.getEMCProxy().getValue(stack) * (long)stack.func_190916_E()) * ProjectEConfig.difficulty.covalenceLoss));
            this.player.field_71071_by.func_70437_b(ItemStack.field_190927_a);
            return true;
        }
        if (mode == 2) {
            long max;
            if (type.func_190926_b()) {
                return false;
            }
            ItemStack stack1 = ItemHandlerHelper.copyStackWithSize((ItemStack)type, (int)1);
            long value = ProjectEAPI.getEMCProxy().getValue(stack1);
            if (value <= 0L) {
                return false;
            }
            int amount = type.func_77976_d();
            if ((long)amount > (max = this.playerData.getEmc() / value)) {
                amount = (int)Math.min((long)amount, max);
            }
            if (amount <= 0) {
                return false;
            }
            PersonalEMC.remove(this.playerData, value * (long)amount);
            stack1.func_190920_e(amount);
            this.player.field_71071_by.func_191975_a(this.player.field_70170_p, stack1);
            return true;
        }
        if (mode == 3) {
            if (type.func_190926_b()) {
                return false;
            }
            if (!(stack.func_190926_b() || ItemHandlerHelper.canItemStacksStack((ItemStack)type, (ItemStack)stack) && stack.func_190916_E() < stack.func_77976_d())) {
                return false;
            }
            ItemStack stack1 = ItemHandlerHelper.copyStackWithSize((ItemStack)type, (int)1);
            long value = ProjectEAPI.getEMCProxy().getValue(stack1);
            if (value <= 0L) {
                return false;
            }
            if (this.playerData.getEmc() < value) {
                return false;
            }
            PersonalEMC.remove(this.playerData, value);
            if (!stack.func_190926_b()) {
                stack.func_190917_f(1);
            } else {
                this.player.field_71071_by.func_70437_b(stack1);
            }
            return true;
        }
        if (mode == 5) {
            if (stack.func_190926_b() || !ProjectEAPI.getEMCProxy().hasValue(stack)) {
                return false;
            }
            ItemStack stack1 = ProjectEXUtils.fixOutput(stack);
            if (!this.isItemValid(stack1)) {
                return false;
            }
            int k = ProjectEXUtils.addKnowledge(this.player, this.playerData, stack1);
            if (k == 0) {
                return false;
            }
            if (k == 2 && this.knowledgeUpdate != null) {
                this.knowledgeUpdate.updateKnowledge();
            }
            return true;
        }
        if (mode == 6) {
            if (stack.func_190926_b()) {
                return false;
            }
            if (this.playerData.removeKnowledge(ProjectEXUtils.fixOutput(stack))) {
                if (this.knowledgeUpdate != null) {
                    this.knowledgeUpdate.updateKnowledge();
                }
                return true;
            }
            return false;
        }
        return false;
    }

    public static interface KnowledgeUpdate {
        public void updateKnowledge();
    }
}

