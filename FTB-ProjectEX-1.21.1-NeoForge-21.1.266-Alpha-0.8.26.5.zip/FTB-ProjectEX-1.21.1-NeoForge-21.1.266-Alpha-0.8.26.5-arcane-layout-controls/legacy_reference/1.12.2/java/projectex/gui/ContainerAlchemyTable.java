/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.IContainerListener
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.relauncher.Side
 *  net.minecraftforge.fml.relauncher.SideOnly
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.SlotItemHandler
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.tile.TileAlchemyTable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class ContainerAlchemyTable
extends Container {
    public final EntityPlayer player;
    public final TileAlchemyTable table;
    public int progress = -1;
    public int emc = -1;

    public ContainerAlchemyTable(EntityPlayer ep, TileAlchemyTable p) {
        this.player = ep;
        this.table = p;
        this.func_75146_a((Slot)new SlotItemHandler((IItemHandler)this.table.items, 0, 44, 35));
        this.func_75146_a((Slot)new SlotItemHandler((IItemHandler)this.table.items, 1, 116, 35));
        for (int k = 0; k < 3; ++k) {
            for (int i1 = 0; i1 < 9; ++i1) {
                this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, i1 + k * 9 + 9, 8 + i1 * 18, 84 + k * 18));
            }
        }
        for (int l = 0; l < 9; ++l) {
            this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, l, 8 + l * 18, 142));
        }
    }

    public boolean func_75145_c(EntityPlayer player) {
        return true;
    }

    public ItemStack func_82846_b(EntityPlayer player, int index) {
        Slot slot = (Slot)this.field_75151_b.get(index);
        if (slot != null && slot.func_75216_d()) {
            ItemStack stack = slot.func_75211_c();
            ItemStack oldStack = stack.func_77946_l();
            if (index < 2 ? !this.func_75135_a(stack, 2, this.field_75151_b.size(), true) : !this.func_75135_a(stack, 0, 2, false)) {
                return ItemStack.field_190927_a;
            }
            if (stack.func_190926_b()) {
                slot.func_75215_d(ItemStack.field_190927_a);
            } else {
                slot.func_75218_e();
            }
            return oldStack;
        }
        return ItemStack.field_190927_a;
    }

    public void sendData(IContainerListener listener) {
        listener.func_71112_a((Container)this, 0, Math.min(255, this.table.totalProgress <= 0 ? 0 : this.table.progress * 255 / this.table.totalProgress));
        listener.func_71112_a((Container)this, 1, Math.min(255, (double)this.table.totalCost <= 0.0 ? 0 : (int)(this.table.storedEMC * 255L / this.table.totalCost)));
    }

    public void func_75132_a(IContainerListener listener) {
        super.func_75132_a(listener);
        this.sendData(listener);
    }

    public void func_75142_b() {
        super.func_75142_b();
        if (!this.table.func_145831_w().field_72995_K) {
            for (IContainerListener listener : this.field_75149_d) {
                this.sendData(listener);
            }
        }
    }

    @SideOnly(value=Side.CLIENT)
    public void func_75137_b(int id, int data) {
        if (id == 0) {
            this.progress = data & 0xFF;
        } else if (id == 1) {
            this.emc = data & 0xFF;
        } else {
            super.func_75137_b(id, data);
        }
    }
}

