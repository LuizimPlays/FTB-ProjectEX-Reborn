/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.text.TextFormatting
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.client.EnumSearchType;
import com.latmod.mods.projectex.client.ProjectEXClientConfig;
import com.latmod.mods.projectex.gui.ButtonArrow;
import com.latmod.mods.projectex.gui.ButtonBurnItem;
import com.latmod.mods.projectex.gui.ButtonCreateItem;
import com.latmod.mods.projectex.gui.ButtonLearnItem;
import com.latmod.mods.projectex.gui.ButtonSmall;
import com.latmod.mods.projectex.gui.ButtonUnlearnItem;
import com.latmod.mods.projectex.gui.ContainerArcaneTablet;
import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.gui.GuiTableBase;
import com.latmod.mods.projectex.integration.PersonalEMC;
import java.awt.Rectangle;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class GuiArcaneTablet
extends GuiTableBase {
    private static final ResourceLocation TEXTURE = new ResourceLocation("projectex", "textures/gui/arcane_tablet.png");

    public GuiArcaneTablet(ContainerArcaneTablet c) {
        super(c);
    }

    @Override
    public Rectangle getTextBox() {
        return new Rectangle(this.field_147003_i + 8, this.field_147009_r + 7, 160, 11);
    }

    @Override
    public void addButtons() {
        this.func_189646_b(new ButtonArrow(this, 1, this.field_147003_i + 7, this.field_147009_r + 20, 196, 0));
        this.func_189646_b(new ButtonArrow(this, 2, this.field_147003_i + 151, this.field_147009_r + 20, 215, 0));
        this.func_189646_b(new ButtonBurnItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 20));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 105, this.field_147009_r + 26));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 55, this.field_147009_r + 26));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 123, this.field_147009_r + 44));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 37, this.field_147009_r + 44));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 128, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 32, this.field_147009_r + 68));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 123, this.field_147009_r + 92));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 37, this.field_147009_r + 92));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 105, this.field_147009_r + 110));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 55, this.field_147009_r + 110));
        this.func_189646_b(new ButtonCreateItem(this.table, 3, this.field_147003_i + 80, this.field_147009_r + 116));
        this.func_189646_b(new ButtonLearnItem(this.table, 4, this.field_147003_i + 8, this.field_147009_r + 115));
        this.func_189646_b(new ButtonUnlearnItem(this.table, 5, this.field_147003_i + 152, this.field_147009_r + 115));
        this.func_189646_b(new ButtonSmall(6, this.field_147003_i - 71, this.field_147009_r + 16, I18n.func_135052_a((String)"gui.arcane_tablet.rotate", (Object[])new Object[0])));
        this.func_189646_b(new ButtonSmall(7, this.field_147003_i - 71, this.field_147009_r + 26, I18n.func_135052_a((String)"gui.arcane_tablet.balance", (Object[])new Object[0])));
        this.func_189646_b(new ButtonSmall(8, this.field_147003_i - 71, this.field_147009_r + 36, I18n.func_135052_a((String)"projectex.general.search_type", (Object[])new Object[0]) + ": " + TextFormatting.GRAY + I18n.func_135052_a((String)ProjectEXClientConfig.general.search_type.translationKey, (Object[])new Object[0])));
        this.func_189646_b(new ButtonSmall(9, this.field_147003_i - 71, this.field_147009_r + 61, I18n.func_135052_a((String)"gui.arcane_tablet.clear", (Object[])new Object[0])));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k == 6) {
            this.handleButton(GuiArcaneTablet.func_146272_n() ? 42 : 41);
        } else if (button.field_146127_k == 7) {
            this.handleButton(GuiArcaneTablet.func_146272_n() ? 44 : 43);
        } else if (button.field_146127_k == 8) {
            ProjectEXClientConfig.general.search_type = EnumSearchType.VALUES[(ProjectEXClientConfig.general.search_type.ordinal() + 1) % EnumSearchType.VALUES.length];
            button.field_146126_j = I18n.func_135052_a((String)"projectex.general.search_type", (Object[])new Object[0]) + ": " + TextFormatting.GRAY + I18n.func_135052_a((String)ProjectEXClientConfig.general.search_type.translationKey, (Object[])new Object[0]);
        } else if (button.field_146127_k == 9) {
            this.handleButton(40);
        } else {
            super.func_146284_a(button);
        }
    }

    private void handleButton(int id) {
        if (this.table.func_75140_a((EntityPlayer)this.field_146297_k.field_71439_g, id)) {
            this.field_146297_k.field_71442_b.func_78756_a(this.table.field_75152_c, id);
        }
    }

    @Override
    public ResourceLocation getTexture() {
        return TEXTURE;
    }

    @Override
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        super.func_146976_a(partialTicks, mouseX, mouseY);
        this.func_73729_b(this.field_147003_i - 75, this.field_147009_r + 10, 180, 19, 76, 89);
    }

    protected void func_146979_b(int mouseX, int mouseY) {
        String s = EMCFormat.INSTANCE.format(PersonalEMC.get((EntityPlayer)this.field_146297_k.field_71439_g).getEmc());
        this.field_146289_q.func_175063_a(s, (float)(this.field_146999_f - this.field_146289_q.func_78256_a(s)) / 2.0f, -9.0f, -4868683);
    }

    protected boolean func_193983_c(int mouseX, int mouseY, int x, int y) {
        if (mouseX >= x - 75 && mouseY >= y + 10 && mouseX < x + 1 && mouseY < y + 99) {
            return false;
        }
        return super.func_193983_c(mouseX, mouseY, x, y);
    }
}

