/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.network.IGuiHandler
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.ProjectEX;
import com.latmod.mods.projectex.gui.ContainerAlchemyTable;
import com.latmod.mods.projectex.gui.ContainerArcaneTablet;
import com.latmod.mods.projectex.gui.ContainerLink;
import com.latmod.mods.projectex.gui.ContainerStoneTable;
import com.latmod.mods.projectex.gui.GuiAlchemyTable;
import com.latmod.mods.projectex.gui.GuiArcaneTablet;
import com.latmod.mods.projectex.gui.GuiLink;
import com.latmod.mods.projectex.gui.GuiStoneTable;
import com.latmod.mods.projectex.tile.TileAlchemyTable;
import com.latmod.mods.projectex.tile.TileLink;
import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class ProjectEXGuiHandler
implements IGuiHandler {
    public static final int LINK = 1;
    public static final int STONE_TABLE = 2;
    public static final int ARCANE_TABLET = 3;
    public static final int ALCHEMY_TABLE = 4;

    public static void open(EntityPlayer player, int id, int x, int y, int z) {
        player.openGui((Object)ProjectEX.INSTANCE, id, player.field_70170_p, x, y, z);
    }

    @Nullable
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        if (id == 1) {
            TileEntity tileEntity = world.func_175625_s(new BlockPos(x, y, z));
            if (tileEntity instanceof TileLink) {
                return new ContainerLink(player, (TileLink)tileEntity);
            }
        } else {
            TileEntity tileEntity;
            if (id == 2) {
                return new ContainerStoneTable(player);
            }
            if (id == 3) {
                return new ContainerArcaneTablet(player);
            }
            if (id == 4 && (tileEntity = world.func_175625_s(new BlockPos(x, y, z))) instanceof TileAlchemyTable) {
                return new ContainerAlchemyTable(player, (TileAlchemyTable)tileEntity);
            }
        }
        return null;
    }

    @Nullable
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        Object container = this.getServerGuiElement(id, player, world, x, y, z);
        return this.getClientGuiElement0(id, (Container)container);
    }

    @Nullable
    private Object getClientGuiElement0(int id, @Nullable Container container) {
        if (id == 1) {
            if (container instanceof ContainerLink) {
                return new GuiLink((ContainerLink)container);
            }
        } else if (id == 2) {
            if (container instanceof ContainerStoneTable) {
                return new GuiStoneTable((ContainerStoneTable)container);
            }
        } else if (id == 3) {
            if (container instanceof ContainerArcaneTablet) {
                return new GuiArcaneTablet((ContainerArcaneTablet)container);
            }
        } else if (id == 4 && container instanceof ContainerAlchemyTable) {
            return new GuiAlchemyTable((ContainerAlchemyTable)container);
        }
        return null;
    }
}

