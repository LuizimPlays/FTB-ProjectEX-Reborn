/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.inventory.Container
 *  net.minecraft.util.ResourceLocation
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.gui.ContainerAlchemyTable;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.inventory.Container;
import net.minecraft.util.ResourceLocation;

public class GuiAlchemyTable
extends GuiContainer {
    private static final ResourceLocation TEXTURE = new ResourceLocation("projectex", "textures/gui/alchemy_table.png");
    public final ContainerAlchemyTable container;

    public GuiAlchemyTable(ContainerAlchemyTable c) {
        super((Container)c);
        this.container = c;
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }

    protected void func_146976_a(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        this.field_146297_k.func_110434_K().func_110577_a(TEXTURE);
        this.func_73729_b(this.field_147003_i, this.field_147009_r, 0, 0, this.field_146999_f, this.field_147000_g);
        if (this.container.emc > 0) {
            this.func_73729_b(this.field_147003_i + 77, this.field_147009_r + 34, 177, 17, Math.max(1, (int)((float)this.container.emc / 255.0f * 24.0f)), 18);
        }
        if (this.container.progress > 0) {
            this.func_73729_b(this.field_147003_i + 78, this.field_147009_r + 35, 177, 0, Math.max(1, (int)((float)this.container.progress / 255.0f * 22.0f)), 16);
        }
    }

    protected void func_146979_b(int mouseX, int mouseY) {
    }
}

