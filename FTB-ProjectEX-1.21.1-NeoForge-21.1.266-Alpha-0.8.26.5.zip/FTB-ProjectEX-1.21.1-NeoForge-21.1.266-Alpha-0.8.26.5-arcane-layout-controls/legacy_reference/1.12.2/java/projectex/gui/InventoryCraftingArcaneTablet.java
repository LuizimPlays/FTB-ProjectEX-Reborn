/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.util.RecipeItemHelper
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.inventory.InventoryCrafting
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.items.IItemHandlerModifiable
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.gui.ContainerArcaneTablet;
import net.minecraft.client.util.RecipeItemHelper;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;

public class InventoryCraftingArcaneTablet
extends InventoryCrafting {
    private final ContainerArcaneTablet tablet;
    private final IItemHandlerModifiable items;

    public InventoryCraftingArcaneTablet(ContainerArcaneTablet container, int width, int height, IItemHandlerModifiable i) {
        super((Container)container, width, height);
        this.tablet = container;
        this.items = i;
    }

    public boolean func_191420_l() {
        for (int i = 0; i < this.items.getSlots(); ++i) {
            if (this.items.getStackInSlot(i).func_190926_b()) continue;
            return false;
        }
        return true;
    }

    public ItemStack func_70301_a(int index) {
        return index < 0 || index >= this.func_70302_i_() ? ItemStack.field_190927_a : this.items.getStackInSlot(index);
    }

    public void func_70299_a(int index, ItemStack stack) {
        this.items.setStackInSlot(index, stack);
        this.tablet.func_75130_a((IInventory)this);
    }

    public ItemStack func_70304_b(int index) {
        if (index < 0 || index >= this.func_70302_i_()) {
            return ItemStack.field_190927_a;
        }
        ItemStack stack0 = this.items.getStackInSlot(index);
        this.items.setStackInSlot(index, ItemStack.field_190927_a);
        return stack0;
    }

    public ItemStack func_70298_a(int index, int count) {
        if (index < 0 || index >= this.func_70302_i_() || count <= 0 || this.items.getStackInSlot(index).func_190926_b()) {
            return ItemStack.field_190927_a;
        }
        ItemStack stack = this.items.getStackInSlot(index).func_77979_a(count);
        if (!stack.func_190926_b()) {
            this.tablet.func_75130_a((IInventory)this);
        }
        return stack;
    }

    public void func_174888_l() {
        for (int i = 0; i < this.items.getSlots(); ++i) {
            this.items.setStackInSlot(i, ItemStack.field_190927_a);
        }
    }

    public void func_194018_a(RecipeItemHelper helper) {
        for (int i = 0; i < this.items.getSlots(); ++i) {
            helper.func_194112_a(this.items.getStackInSlot(i));
        }
    }

    public void func_70296_d() {
        this.tablet.func_75130_a((IInventory)this);
    }
}

