/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.gui.ButtonSlot;
import com.latmod.mods.projectex.gui.ContainerTableBase;

public class ButtonUnlearnItem
extends ButtonSlot {
    public ButtonUnlearnItem(ContainerTableBase t, int id, int x, int y) {
        super(t, id, x, y);
    }
}

