/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  moze_intel.projecte.config.ProjectEConfig
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.Container
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.items.IItemHandler
 *  net.minecraftforge.items.SlotItemHandler
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.ProjectEXUtils;
import com.latmod.mods.projectex.integration.PersonalEMC;
import com.latmod.mods.projectex.tile.TileLink;
import com.latmod.mods.projectex.tile.TileLinkMK2;
import com.latmod.mods.projectex.tile.TileLinkMK3;
import moze_intel.projecte.api.ProjectEAPI;
import moze_intel.projecte.config.ProjectEConfig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class ContainerLink
extends Container {
    public final EntityPlayer player;
    public final TileLink link;

    public ContainerLink(EntityPlayer ep, TileLink p) {
        this.player = ep;
        this.link = p;
        if (this.link instanceof TileLinkMK3) {
            this.func_75146_a((Slot)new SlotItemHandler((IItemHandler)this.link, 0, 8, 17));
            for (int k = 0; k < 3; ++k) {
                for (int i1 = 0; i1 < 9; ++i1) {
                    this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, i1 + k * 9 + 9, 8 + i1 * 18, 162 + k * 18));
                }
            }
            for (int l = 0; l < 9; ++l) {
                this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, l, 8 + l * 18, 220));
            }
        } else if (this.link instanceof TileLinkMK2) {
            this.func_75146_a((Slot)new SlotItemHandler((IItemHandler)this.link, 0, 35, 35));
            for (int k = 0; k < 3; ++k) {
                for (int i1 = 0; i1 < 9; ++i1) {
                    this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, i1 + k * 9 + 9, 8 + i1 * 18, 84 + k * 18));
                }
            }
            for (int l = 0; l < 9; ++l) {
                this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, l, 8 + l * 18, 142));
            }
        } else {
            for (int i = 0; i < 18; ++i) {
                this.func_75146_a((Slot)new SlotItemHandler((IItemHandler)this.link, i, 8 + i % 6 * 18, 17 + i / 6 * 18));
            }
            for (int k = 0; k < 3; ++k) {
                for (int i1 = 0; i1 < 9; ++i1) {
                    this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, i1 + k * 9 + 9, 8 + i1 * 18, 84 + k * 18));
                }
            }
            for (int l = 0; l < 9; ++l) {
                this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, l, 8 + l * 18, 142));
            }
        }
    }

    public boolean func_75145_c(EntityPlayer player) {
        return true;
    }

    public ItemStack func_82846_b(EntityPlayer player, int index) {
        Slot slot = (Slot)this.field_75151_b.get(index);
        if (slot != null && slot.func_75216_d()) {
            ItemStack stack = slot.func_75211_c();
            ItemStack oldStack = stack.func_77946_l();
            double value = ProjectEAPI.getEMCProxy().getValue(stack);
            if (!(value > 0.0)) {
                return ItemStack.field_190927_a;
            }
            PersonalEMC.get(player).addKnowledge(ProjectEXUtils.fixOutput(stack));
            this.addItemToOutput(ProjectEXUtils.fixOutput(stack));
            this.link.storedEMC = (long)((double)this.link.storedEMC + (double)stack.func_190916_E() * value * ProjectEConfig.difficulty.covalenceLoss);
            this.link.func_70296_d();
            slot.func_75215_d(ItemStack.field_190927_a);
            return oldStack;
        }
        return ItemStack.field_190927_a;
    }

    private void addItemToOutput(ItemStack stack) {
        int i;
        for (i = 0; i < this.link.outputSlots.length; ++i) {
            if (this.link.outputSlots[i].func_77973_b() != stack.func_77973_b() || this.link.outputSlots[i].func_77960_j() != stack.func_77960_j()) continue;
            return;
        }
        for (i = 0; i < this.link.outputSlots.length; ++i) {
            if (!this.link.outputSlots[i].func_190926_b()) continue;
            this.link.outputSlots[i] = stack;
            return;
        }
    }

    public boolean func_75140_a(EntityPlayer player, int id) {
        if (!player.func_110124_au().equals(this.link.owner)) {
            return false;
        }
        int index = id % this.link.outputSlots.length;
        if (player.field_71071_by.func_70445_o().func_190926_b()) {
            ItemStack stack;
            int type = id / this.link.outputSlots.length;
            if (type == 1) {
                this.link.outputSlots[index] = ItemStack.field_190927_a;
                this.link.func_70296_d();
                return true;
            }
            if (!player.field_70170_p.field_72995_K && !(stack = this.link.extractItem(this.link.inputSlots.length + index, type == 2 ? 1 : 64, false)).func_190926_b()) {
                player.field_71071_by.func_191975_a(player.field_70170_p, stack);
            }
            return true;
        }
        return this.link.setOutputStack(player, index, player.field_71071_by.func_70445_o(), true);
    }
}

