/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.item.IItemEmc
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.IInventory
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.gui.ContainerTableBase;
import moze_intel.projecte.api.item.IItemEmc;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerStoneTable
extends ContainerTableBase {
    public ContainerStoneTable(EntityPlayer p) {
        super(p);
        for (int k = 0; k < 3; ++k) {
            for (int i1 = 0; i1 < 9; ++i1) {
                this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, i1 + k * 9 + 9, 8 + i1 * 18, 135 + k * 18));
            }
        }
        for (int l = 0; l < 9; ++l) {
            this.func_75146_a(new Slot((IInventory)this.player.field_71071_by, l, 8 + l * 18, 193));
        }
    }

    @Override
    public boolean isItemValid(ItemStack stack) {
        return stack.func_77973_b() instanceof IItemEmc || ProjectEXConfig.general.isStoneTableWhitelisted(stack);
    }
}

