/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.ProjectEAPI
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.RenderItem
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.gui;

import com.latmod.mods.projectex.gui.ButtonSlot;
import com.latmod.mods.projectex.gui.ContainerTableBase;
import com.latmod.mods.projectex.gui.EMCFormat;
import moze_intel.projecte.api.ProjectEAPI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public class ButtonCreateItem
extends ButtonSlot {
    public ItemStack type = ItemStack.field_190927_a;

    public ButtonCreateItem(ContainerTableBase t, int id, int x, int y) {
        super(t, id, x, y);
    }

    @Override
    public void func_191745_a(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
        if (this.field_146125_m) {
            boolean bl = this.field_146123_n = mouseX >= this.field_146128_h && mouseY >= this.field_146129_i && mouseX < this.field_146128_h + this.field_146120_f && mouseY < this.field_146129_i + this.field_146121_g;
            if (!this.type.func_190926_b()) {
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GlStateManager.func_179126_j();
                RenderHelper.func_74520_c();
                OpenGlHelper.func_77475_a((int)OpenGlHelper.field_77476_b, (float)240.0f, (float)240.0f);
                RenderItem renderItem = mc.func_175599_af();
                renderItem.func_184391_a((EntityLivingBase)mc.field_71439_g, this.type, this.field_146128_h, this.field_146129_i);
                renderItem.func_180453_a(mc.field_71466_p, this.type, this.field_146128_h, this.field_146129_i, null);
                RenderHelper.func_74518_a();
                double emc = ProjectEAPI.getEMCProxy().getValue(this.type);
                double d = (double)this.table.playerData.getEmc() / emc;
                String s = d >= 1.0 ? EMCFormat.INSTANCE_IGNORE_SHIFT.format(d) : (d >= 0.1 ? Double.toString((double)((int)(d * 10.0)) / 10.0) : "");
                GlStateManager.func_179094_E();
                GlStateManager.func_179109_b((float)(this.field_146128_h + 17), (float)(this.field_146129_i + 12), (float)0.0f);
                GlStateManager.func_179152_a((float)0.5f, (float)0.5f, (float)1.0f);
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                GlStateManager.func_179084_k();
                mc.field_71466_p.func_175063_a(s, (float)(-mc.field_71466_p.func_78256_a(s)), 0.0f, 0xFFFFFF);
                GlStateManager.func_179145_e();
                GlStateManager.func_179126_j();
                GlStateManager.func_179147_l();
                GlStateManager.func_179121_F();
            }
            if (this.field_146123_n) {
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                GlStateManager.func_179140_f();
                GlStateManager.func_179097_i();
                GlStateManager.func_179135_a((boolean)true, (boolean)true, (boolean)true, (boolean)false);
                this.func_73733_a(this.field_146128_h, this.field_146129_i, this.field_146128_h + this.field_146120_f, this.field_146129_i + this.field_146121_g, -2130706433, -2130706433);
                GlStateManager.func_179135_a((boolean)true, (boolean)true, (boolean)true, (boolean)true);
                GlStateManager.func_179145_e();
                GlStateManager.func_179126_j();
            }
        }
    }
}

