/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.client;

public enum EnumScreenPosition {
    DISABLED("Disabled"),
    TOP_LEFT("Top-Left"),
    TOP_RIGHT("Top-Right");

    private final String string;

    private EnumScreenPosition(String s) {
        this.string = s;
    }

    public String toString() {
        return this.string;
    }
}

