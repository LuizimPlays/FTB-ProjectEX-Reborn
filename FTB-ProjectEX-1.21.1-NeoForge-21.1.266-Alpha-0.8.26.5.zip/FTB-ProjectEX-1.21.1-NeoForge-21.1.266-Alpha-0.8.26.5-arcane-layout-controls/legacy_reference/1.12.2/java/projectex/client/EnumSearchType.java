/*
 * Decompiled with CFR 0.152.
 */
package com.latmod.mods.projectex.client;

public enum EnumSearchType {
    NORMAL("normal", false, false),
    AUTOSELECTED("autoselected", true, false),
    NORMAL_JEI_SYNC("normal_jei_sync", false, true),
    AUTOSELECTED_JEI_SYNC("autoselected_jei_sync", true, true);

    public static final EnumSearchType[] VALUES;
    public final String translationKey;
    public final boolean autoselected;
    public final boolean jeiSync;

    private EnumSearchType(String s, boolean a, boolean j) {
        this.translationKey = "projectex.general.search_type." + s;
        this.autoselected = a;
        this.jeiSync = j;
    }

    static {
        VALUES = EnumSearchType.values();
    }
}

