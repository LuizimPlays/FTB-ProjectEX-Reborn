/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.common.config.Config
 *  net.minecraftforge.common.config.Config$LangKey
 */
package com.latmod.mods.projectex.client;

import com.latmod.mods.projectex.client.EnumScreenPosition;
import com.latmod.mods.projectex.client.EnumSearchType;
import net.minecraftforge.common.config.Config;

@Config(modid="projectex", category="", name="../local/client/projectex")
@Config.LangKey(value="projectex_client")
public class ProjectEXClientConfig {
    @Config.LangKey(value="stat.generalButton")
    public static final General general = new General();

    public static class General {
        public EnumScreenPosition emc_screen_position = EnumScreenPosition.TOP_LEFT;
        public EnumSearchType search_type = EnumSearchType.NORMAL;
    }
}

