/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 */
package com.latmod.mods.projectex.client;

import com.latmod.mods.projectex.ProjectEXCommon;
import com.latmod.mods.projectex.integration.PersonalEMC;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class ProjectEXClient
extends ProjectEXCommon {
    @Override
    public EntityPlayer getClientPlayer() {
        return Minecraft.func_71410_x().field_71439_g;
    }

    @Override
    public void updateEMC(long emc) {
        PersonalEMC.get((EntityPlayer)Minecraft.func_71410_x().field_71439_g).setEmc(emc);
    }
}

