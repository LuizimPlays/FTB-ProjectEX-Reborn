/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.ingredients.IIngredients
 *  mezz.jei.api.ingredients.VanillaTypes
 *  mezz.jei.api.recipe.IRecipeWrapper
 *  net.minecraft.client.Minecraft
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.gui.EMCFormat;
import com.latmod.mods.projectex.tile.AlchemyTableRecipe;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.ingredients.VanillaTypes;
import mezz.jei.api.recipe.IRecipeWrapper;
import net.minecraft.client.Minecraft;

public class AlchemyTableWrapper
implements IRecipeWrapper {
    public final AlchemyTableRecipe recipe;

    public AlchemyTableWrapper(AlchemyTableRecipe r) {
        this.recipe = r;
    }

    public void getIngredients(IIngredients ingredients) {
        ingredients.setInput(VanillaTypes.ITEM, (Object)this.recipe.input);
        ingredients.setOutput(VanillaTypes.ITEM, (Object)this.recipe.output);
    }

    public void drawInfo(Minecraft mc, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {
        long emc = this.recipe.getTotalCost();
        String s = EMCFormat.INSTANCE.format(emc) + " EMC";
        mc.field_71466_p.func_78276_b(s, (recipeWidth - mc.field_71466_p.func_78256_a(s)) / 2, 5, -14540254);
    }
}

