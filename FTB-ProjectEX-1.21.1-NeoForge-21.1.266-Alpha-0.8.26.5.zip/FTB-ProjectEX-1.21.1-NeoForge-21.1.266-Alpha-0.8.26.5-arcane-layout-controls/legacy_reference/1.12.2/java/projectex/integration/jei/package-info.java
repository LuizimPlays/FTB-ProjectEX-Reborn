/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.ParametersAreNonnullByDefault
 *  mcp.MethodsReturnNonnullByDefault
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.latmod.mods.projectex.integration.jei;

import javax.annotation.ParametersAreNonnullByDefault;
import mcp.MethodsReturnNonnullByDefault;


