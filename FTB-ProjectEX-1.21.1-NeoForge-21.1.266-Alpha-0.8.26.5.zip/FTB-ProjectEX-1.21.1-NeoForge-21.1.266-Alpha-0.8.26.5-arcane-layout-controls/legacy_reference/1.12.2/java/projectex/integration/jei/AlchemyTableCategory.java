/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.IGuiHelper
 *  mezz.jei.api.gui.IDrawable
 *  mezz.jei.api.gui.IGuiItemStackGroup
 *  mezz.jei.api.gui.IRecipeLayout
 *  mezz.jei.api.ingredients.IIngredients
 *  mezz.jei.api.recipe.IRecipeCategory
 *  net.minecraft.client.resources.I18n
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.ResourceLocation
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.integration.jei.AlchemyTableWrapper;
import com.latmod.mods.projectex.item.ProjectEXItems;
import mezz.jei.api.IGuiHelper;
import mezz.jei.api.gui.IDrawable;
import mezz.jei.api.gui.IGuiItemStackGroup;
import mezz.jei.api.gui.IRecipeLayout;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.recipe.IRecipeCategory;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class AlchemyTableCategory
implements IRecipeCategory<AlchemyTableWrapper> {
    public static final String UID = "projectex.alchemy_table";
    private final IDrawable background;
    private final IDrawable icon;

    public AlchemyTableCategory(IGuiHelper guiHelper) {
        this.background = guiHelper.drawableBuilder(new ResourceLocation("projectex:textures/gui/alchemy_table_jei.png"), 0, 0, 128, 18).setTextureSize(128, 64).build();
        this.icon = guiHelper.createDrawableIngredient((Object)new ItemStack(ProjectEXItems.ALCHEMY_TABLE));
    }

    public String getUid() {
        return UID;
    }

    public String getTitle() {
        return I18n.func_135052_a((String)"tile.projectex.alchemy_table.name", (Object[])new Object[0]);
    }

    public String getModName() {
        return "Project EX";
    }

    public IDrawable getBackground() {
        return this.background;
    }

    public IDrawable getIcon() {
        return this.icon;
    }

    public void setRecipe(IRecipeLayout layout, AlchemyTableWrapper entry, IIngredients ingredients) {
        IGuiItemStackGroup stacks = layout.getItemStacks();
        stacks.init(0, true, 0, 0);
        stacks.init(1, false, 110, 0);
        stacks.set(ingredients);
    }
}

