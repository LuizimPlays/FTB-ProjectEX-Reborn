/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  mezz.jei.api.gui.IAdvancedGuiHandler
 *  mezz.jei.api.gui.IRecipeLayout
 *  mezz.jei.api.recipe.transfer.IRecipeTransferError
 *  mezz.jei.api.recipe.transfer.IRecipeTransferError$Type
 *  mezz.jei.api.recipe.transfer.IRecipeTransferHandler
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.inventory.InventoryCrafting
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.gui.ButtonCreateItem;
import com.latmod.mods.projectex.gui.ContainerArcaneTablet;
import com.latmod.mods.projectex.gui.GuiArcaneTablet;
import com.latmod.mods.projectex.net.MessageArcaneTableRecipeTransfer;
import com.latmod.mods.projectex.net.ProjectEXNetHandler;
import java.awt.Rectangle;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import mezz.jei.api.gui.IAdvancedGuiHandler;
import mezz.jei.api.gui.IRecipeLayout;
import mezz.jei.api.recipe.transfer.IRecipeTransferError;
import mezz.jei.api.recipe.transfer.IRecipeTransferHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public enum ArcaneTabletJEI implements IAdvancedGuiHandler<GuiArcaneTablet>,
IRecipeTransferHandler<ContainerArcaneTablet>
{
    INSTANCE;

    private static final IRecipeTransferError ERROR_CANNOT_TRANSFER;

    public Class<GuiArcaneTablet> getGuiContainerClass() {
        return GuiArcaneTablet.class;
    }

    public Class<ContainerArcaneTablet> getContainerClass() {
        return ContainerArcaneTablet.class;
    }

    @Nullable
    public IRecipeTransferError transferRecipe(ContainerArcaneTablet tablet, IRecipeLayout layout, EntityPlayer player, boolean maxTransfer, boolean doTransfer) {
        if (doTransfer) {
            ProjectEXNetHandler.NET.sendToServer((IMessage)new MessageArcaneTableRecipeTransfer(layout.getItemStacks().getGuiIngredients(), tablet.field_75151_b.stream().filter(s -> s.field_75224_c instanceof InventoryCrafting).collect(Collectors.toList()), maxTransfer));
        } else if (!layout.getRecipeCategory().getUid().equals("minecraft.crafting")) {
            return ERROR_CANNOT_TRANSFER;
        }
        return null;
    }

    public List<Rectangle> getGuiExtraAreas(GuiArcaneTablet gui) {
        return Collections.singletonList(new Rectangle(gui.getGuiLeft() - 75, gui.getGuiTop() + 10, 76, 89));
    }

    @Nullable
    public Object getIngredientUnderMouse(GuiArcaneTablet gui, int x, int y) {
        for (GuiButton button : gui.getButtons()) {
            if (!(button instanceof ButtonCreateItem) || x < button.field_146128_h || x >= button.field_146128_h + button.field_146120_f || y < button.field_146129_i || y >= button.field_146129_i + button.field_146121_g || ((ButtonCreateItem)button).type.func_190926_b()) continue;
            return ((ButtonCreateItem)button).type;
        }
        return null;
    }

    static {
        ERROR_CANNOT_TRANSFER = new IRecipeTransferError(){

            public IRecipeTransferError.Type getType() {
                return IRecipeTransferError.Type.INTERNAL;
            }

            public void showError(Minecraft mc, int mouseX, int mouseY, IRecipeLayout layout, int recipeX, int recipeY) {
            }
        };
    }
}

