/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  mezz.jei.api.gui.IAdvancedGuiHandler
 *  net.minecraft.client.gui.GuiButton
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.gui.ButtonCreateItem;
import com.latmod.mods.projectex.gui.GuiStoneTable;
import javax.annotation.Nullable;
import mezz.jei.api.gui.IAdvancedGuiHandler;
import net.minecraft.client.gui.GuiButton;

public enum StoneTableJEI implements IAdvancedGuiHandler<GuiStoneTable>
{
    INSTANCE;


    public Class<GuiStoneTable> getGuiContainerClass() {
        return GuiStoneTable.class;
    }

    @Nullable
    public Object getIngredientUnderMouse(GuiStoneTable gui, int x, int y) {
        for (GuiButton button : gui.getButtons()) {
            if (!(button instanceof ButtonCreateItem) || x < button.field_146128_h || x >= button.field_146128_h + button.field_146120_f || y < button.field_146129_i || y >= button.field_146129_i + button.field_146121_g || ((ButtonCreateItem)button).type.func_190926_b()) continue;
            return ((ButtonCreateItem)button).type;
        }
        return null;
    }
}

