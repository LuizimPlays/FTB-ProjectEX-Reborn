/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  mezz.jei.api.IJeiRuntime
 *  mezz.jei.api.IModPlugin
 *  mezz.jei.api.IModRegistry
 *  mezz.jei.api.JEIPlugin
 *  mezz.jei.api.gui.IAdvancedGuiHandler
 *  mezz.jei.api.gui.IGhostIngredientHandler
 *  mezz.jei.api.ingredients.VanillaTypes
 *  mezz.jei.api.recipe.IRecipeCategory
 *  mezz.jei.api.recipe.IRecipeCategoryRegistration
 *  mezz.jei.api.recipe.transfer.IRecipeTransferHandler
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.gui.GuiArcaneTablet;
import com.latmod.mods.projectex.gui.GuiLink;
import com.latmod.mods.projectex.integration.jei.AlchemyTableCategory;
import com.latmod.mods.projectex.integration.jei.AlchemyTableWrapper;
import com.latmod.mods.projectex.integration.jei.ArcaneTabletJEI;
import com.latmod.mods.projectex.integration.jei.EMCLinkJEI;
import com.latmod.mods.projectex.integration.jei.StoneTableJEI;
import com.latmod.mods.projectex.item.ProjectEXItems;
import com.latmod.mods.projectex.tile.AlchemyTableRecipe;
import com.latmod.mods.projectex.tile.AlchemyTableRecipes;
import mezz.jei.api.IJeiRuntime;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.IModRegistry;
import mezz.jei.api.JEIPlugin;
import mezz.jei.api.gui.IAdvancedGuiHandler;
import mezz.jei.api.gui.IGhostIngredientHandler;
import mezz.jei.api.ingredients.VanillaTypes;
import mezz.jei.api.recipe.IRecipeCategory;
import mezz.jei.api.recipe.IRecipeCategoryRegistration;
import mezz.jei.api.recipe.transfer.IRecipeTransferHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

@JEIPlugin
public class ProjectEXJEIIntegration
implements IModPlugin {
    public static IJeiRuntime RUNTIME;

    public void register(IModRegistry registry) {
        registry.addGhostIngredientHandler(GuiLink.class, (IGhostIngredientHandler)EMCLinkJEI.INSTANCE);
        registry.addAdvancedGuiHandlers(new IAdvancedGuiHandler[]{StoneTableJEI.INSTANCE, ArcaneTabletJEI.INSTANCE, EMCLinkJEI.INSTANCE});
        registry.addRecipeClickArea(GuiArcaneTablet.class, -60, 75, 33, 17, new String[]{"minecraft.crafting"});
        registry.getRecipeTransferRegistry().addRecipeTransferHandler((IRecipeTransferHandler)ArcaneTabletJEI.INSTANCE, "minecraft.crafting");
        registry.addRecipeCatalyst((Object)new ItemStack(ProjectEXItems.ARCANE_TABLET), new String[]{"minecraft.crafting"});
        registry.handleRecipes(AlchemyTableRecipe.class, AlchemyTableWrapper::new, "projectex.alchemy_table");
        registry.addRecipeCatalyst((Object)new ItemStack(ProjectEXItems.ALCHEMY_TABLE), new String[]{"projectex.alchemy_table"});
        registry.addRecipes(AlchemyTableRecipes.INSTANCE.LIST, "projectex.alchemy_table");
        this.addInfo(registry, ProjectEXItems.ENERGY_LINK);
        this.addInfo(registry, ProjectEXItems.PERSONAL_LINK);
        this.addInfo(registry, ProjectEXItems.REFINED_LINK);
        this.addInfo(registry, ProjectEXItems.COMPRESSED_REFINED_LINK);
        this.addInfo(registry, ProjectEXItems.FINAL_STAR);
    }

    public void registerCategories(IRecipeCategoryRegistration r) {
        r.addRecipeCategories(new IRecipeCategory[]{new AlchemyTableCategory(r.getJeiHelpers().getGuiHelper())});
    }

    private void addInfo(IModRegistry registry, Item item) {
        registry.addIngredientInfo((Object)new ItemStack(item), VanillaTypes.ITEM, new String[]{item.func_77658_a() + ".tooltip"});
    }

    public void onRuntimeAvailable(IJeiRuntime r) {
        RUNTIME = r;
    }
}

