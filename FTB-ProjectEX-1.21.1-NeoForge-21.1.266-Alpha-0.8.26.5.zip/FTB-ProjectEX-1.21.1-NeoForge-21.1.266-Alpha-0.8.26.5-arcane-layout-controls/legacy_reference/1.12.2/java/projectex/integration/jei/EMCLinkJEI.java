/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  mezz.jei.api.gui.IAdvancedGuiHandler
 *  mezz.jei.api.gui.IGhostIngredientHandler
 *  mezz.jei.api.gui.IGhostIngredientHandler$Target
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.network.simpleimpl.IMessage
 */
package com.latmod.mods.projectex.integration.jei;

import com.latmod.mods.projectex.gui.GuiLink;
import com.latmod.mods.projectex.net.MessageSendLinkStack;
import com.latmod.mods.projectex.net.ProjectEXNetHandler;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import mezz.jei.api.gui.IAdvancedGuiHandler;
import mezz.jei.api.gui.IGhostIngredientHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;

public enum EMCLinkJEI implements IAdvancedGuiHandler<GuiLink>,
IGhostIngredientHandler<GuiLink>
{
    INSTANCE;


    public Class<GuiLink> getGuiContainerClass() {
        return GuiLink.class;
    }

    @Nullable
    public Object getIngredientUnderMouse(GuiLink gui, int x, int y) {
        for (GuiButton button : gui.getButtons()) {
            ItemStack stack;
            if (!(button instanceof GuiLink.ButtonFilter) || x < button.field_146128_h || x >= button.field_146128_h + button.field_146120_f || y < button.field_146129_i || y >= button.field_146129_i + button.field_146121_g || (stack = gui.container.link.outputSlots[button.field_146127_k]).func_190926_b()) continue;
            return stack;
        }
        return null;
    }

    public <I> List<IGhostIngredientHandler.Target<I>> getTargets(final GuiLink gui, I ingredient, boolean doStart) {
        if (ingredient instanceof ItemStack) {
            ArrayList<IGhostIngredientHandler.Target<I>> list = new ArrayList<IGhostIngredientHandler.Target<I>>();
            for (final GuiButton button : gui.getButtons()) {
                if (!(button instanceof GuiLink.ButtonFilter)) continue;
                list.add(new IGhostIngredientHandler.Target<I>(){

                    public Rectangle getArea() {
                        return new Rectangle(button.field_146128_h, button.field_146129_i, button.field_146120_f, button.field_146121_g);
                    }

                    public void accept(I ingredient) {
                        if (gui.container.link.setOutputStack(gui.container.player, button.field_146127_k, (ItemStack)ingredient, false)) {
                            ProjectEXNetHandler.NET.sendToServer((IMessage)new MessageSendLinkStack(gui.container.link.func_174877_v(), button.field_146127_k, (ItemStack)ingredient));
                        }
                    }
                });
            }
            return list;
        }
        return Collections.emptyList();
    }

    public void onComplete() {
    }
}

