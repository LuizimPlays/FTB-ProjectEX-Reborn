/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  moze_intel.projecte.api.item.IItemEmc
 *  moze_intel.projecte.gameObjs.ObjHandler
 *  moze_intel.projecte.gameObjs.items.KleinStar$EnumKleinTier
 *  net.minecraft.block.Block
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.crafting.IRecipe
 *  net.minecraft.item.crafting.Ingredient
 *  net.minecraft.item.crafting.ShapedRecipes
 *  net.minecraft.item.crafting.ShapelessRecipes
 *  net.minecraft.util.NonNullList
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.event.RegistryEvent$Register
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.PlayerEvent$ItemCraftedEvent
 *  net.minecraftforge.fml.common.registry.GameRegistry
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.IForgeRegistryEntry
 */
package com.latmod.mods.projectex;

import com.latmod.mods.projectex.ProjectEX;
import com.latmod.mods.projectex.ProjectEXConfig;
import com.latmod.mods.projectex.block.BlockAlchemyTable;
import com.latmod.mods.projectex.block.BlockCollector;
import com.latmod.mods.projectex.block.BlockEnergyLink;
import com.latmod.mods.projectex.block.BlockLinkMK1;
import com.latmod.mods.projectex.block.BlockLinkMK2;
import com.latmod.mods.projectex.block.BlockLinkMK3;
import com.latmod.mods.projectex.block.BlockPowerFlower;
import com.latmod.mods.projectex.block.BlockRelay;
import com.latmod.mods.projectex.block.BlockStoneTable;
import com.latmod.mods.projectex.block.EnumMatter;
import com.latmod.mods.projectex.block.EnumTier;
import com.latmod.mods.projectex.block.ProjectEXBlocks;
import com.latmod.mods.projectex.item.ItemArcaneTablet;
import com.latmod.mods.projectex.item.ItemBlockTier;
import com.latmod.mods.projectex.item.ItemColossalStar;
import com.latmod.mods.projectex.item.ItemCompressedCollector;
import com.latmod.mods.projectex.item.ItemFinalStar;
import com.latmod.mods.projectex.item.ItemKnowledgeSharingBook;
import com.latmod.mods.projectex.item.ItemMagnumStar;
import com.latmod.mods.projectex.item.ItemMatter;
import com.latmod.mods.projectex.item.ProjectEXItems;
import com.latmod.mods.projectex.tile.TileAlchemyTable;
import com.latmod.mods.projectex.tile.TileCollector;
import com.latmod.mods.projectex.tile.TileEnergyLink;
import com.latmod.mods.projectex.tile.TileLinkMK1;
import com.latmod.mods.projectex.tile.TileLinkMK2;
import com.latmod.mods.projectex.tile.TileLinkMK3;
import com.latmod.mods.projectex.tile.TilePowerFlower;
import com.latmod.mods.projectex.tile.TileRelay;
import moze_intel.projecte.api.item.IItemEmc;
import moze_intel.projecte.gameObjs.ObjHandler;
import moze_intel.projecte.gameObjs.items.KleinStar;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;

@Mod.EventBusSubscriber(modid="projectex")
public class ProjectEXEventHandler {
    private static Block withName(Block item, String name) {
        item.func_149647_a(ProjectEX.TAB);
        item.setRegistryName(name);
        item.func_149663_c("projectex." + name);
        return item;
    }

    private static Item withName(Item item, String name) {
        item.func_77637_a(ProjectEX.TAB);
        item.setRegistryName(name);
        item.func_77655_b("projectex." + name);
        return item;
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        IForgeRegistry r = event.getRegistry();
        if (ProjectEXConfig.items.link) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockEnergyLink(), "energy_link"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockLinkMK1(), "personal_link"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockLinkMK2(), "refined_link"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockLinkMK3(), "compressed_refined_link"));
            GameRegistry.registerTileEntity(TileEnergyLink.class, (ResourceLocation)new ResourceLocation("projectex", "energy_link"));
            GameRegistry.registerTileEntity(TileLinkMK1.class, (ResourceLocation)new ResourceLocation("projectex", "personal_link"));
            GameRegistry.registerTileEntity(TileLinkMK2.class, (ResourceLocation)new ResourceLocation("projectex", "refined_link"));
            GameRegistry.registerTileEntity(TileLinkMK3.class, (ResourceLocation)new ResourceLocation("projectex", "compressed_refined_link"));
        }
        if (ProjectEXConfig.items.collectors) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockCollector(), "collector"));
            GameRegistry.registerTileEntity(TileCollector.class, (ResourceLocation)new ResourceLocation("projectex", "collector"));
        }
        if (ProjectEXConfig.items.relays) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockRelay(), "relay"));
            GameRegistry.registerTileEntity(TileRelay.class, (ResourceLocation)new ResourceLocation("projectex", "relay"));
        }
        if (ProjectEXConfig.items.power_flowers) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockPowerFlower(), "power_flower"));
            GameRegistry.registerTileEntity(TilePowerFlower.class, (ResourceLocation)new ResourceLocation("projectex", "power_flower"));
        }
        if (ProjectEXConfig.items.stone_table) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockStoneTable(), "stone_table"));
        }
        if (ProjectEXConfig.items.alchemy_table) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new BlockAlchemyTable(), "alchemy_table"));
            GameRegistry.registerTileEntity(TileAlchemyTable.class, (ResourceLocation)new ResourceLocation("projectex", "alchemy_table"));
        }
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        IForgeRegistry r = event.getRegistry();
        if (ProjectEXConfig.items.link) {
            r.register(new ItemBlock(ProjectEXBlocks.ENERGY_LINK).setRegistryName("energy_link"));
            r.register(new ItemBlock(ProjectEXBlocks.PERSONAL_LINK).setRegistryName("personal_link"));
            r.register(new ItemBlock(ProjectEXBlocks.REFINED_LINK).setRegistryName("refined_link"));
            r.register(new ItemBlock(ProjectEXBlocks.COMPRESSED_REFINED_LINK).setRegistryName("compressed_refined_link"));
        }
        if (ProjectEXConfig.items.collectors) {
            r.register(new ItemBlockTier(ProjectEXBlocks.COLLECTOR).setRegistryName("collector"));
        }
        if (ProjectEXConfig.items.relays) {
            r.register(new ItemBlockTier(ProjectEXBlocks.RELAY).setRegistryName("relay"));
        }
        if (ProjectEXConfig.items.power_flowers) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemCompressedCollector(), "compressed_collector"));
            r.register(new ItemBlockTier(ProjectEXBlocks.POWER_FLOWER).setRegistryName("power_flower"));
        }
        if (ProjectEXConfig.items.stone_table) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName((Item)new ItemBlock(ProjectEXBlocks.STONE_TABLE), "stone_table"));
        }
        if (ProjectEXConfig.items.alchemy_table) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName((Item)new ItemBlock(ProjectEXBlocks.ALCHEMY_TABLE), "alchemy_table"));
        }
        if (ProjectEXConfig.items.stars) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.EIN), "magnum_star_ein"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.ZWEI), "magnum_star_zwei"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.DREI), "magnum_star_drei"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.VIER), "magnum_star_vier"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.SPHERE), "magnum_star_sphere"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMagnumStar(KleinStar.EnumKleinTier.OMEGA), "magnum_star_omega"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.EIN), "colossal_star_ein"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.ZWEI), "colossal_star_zwei"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.DREI), "colossal_star_drei"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.VIER), "colossal_star_vier"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.SPHERE), "colossal_star_sphere"));
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemColossalStar(KleinStar.EnumKleinTier.OMEGA), "colossal_star_omega"));
        }
        r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemMatter(), "matter"));
        if (ProjectEXConfig.items.clay_matter) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new Item(), "clay_matter").func_77655_b("projectex.matter.clay"));
        }
        r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new Item(), "final_star_shard"));
        if (ProjectEXConfig.items.final_star) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemFinalStar(), "final_star"));
        }
        if (ProjectEXConfig.items.knowledge_sharing_book) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemKnowledgeSharingBook(), "knowledge_sharing_book"));
        }
        if (ProjectEXConfig.items.arcane_tablet) {
            r.register((IForgeRegistryEntry)ProjectEXEventHandler.withName(new ItemArcaneTablet(), "arcane_tablet"));
        }
    }

    @SubscribeEvent
    public static void onItemCrafted(PlayerEvent.ItemCraftedEvent event) {
        if (ProjectEXConfig.items.stars && event.crafting.func_77973_b() instanceof ItemMagnumStar) {
            IItemEmc star = (IItemEmc)event.crafting.func_77973_b();
            for (int i = 0; i < event.craftMatrix.func_70302_i_(); ++i) {
                ItemStack stack = event.craftMatrix.func_70301_a(i);
                if (!(stack.func_77973_b() instanceof IItemEmc)) continue;
                star.addEmc(event.crafting, ((IItemEmc)stack.func_77973_b()).getStoredEmc(stack));
            }
        }
    }

    @SubscribeEvent
    public static void addRecipes(RegistryEvent.Register<IRecipe> event) {
        IForgeRegistry r = event.getRegistry();
        EnumMatter prevMatter = null;
        Ingredient afuel = Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ObjHandler.fuels, 1, 2)});
        for (EnumMatter matter : EnumMatter.VALUES) {
            if (prevMatter != null) {
                Ingredient prevMatterIngredient = Ingredient.func_193369_a((ItemStack[])new ItemStack[]{prevMatter.get()});
                NonNullList listh = NonNullList.func_191196_a();
                listh.add((Object)afuel);
                listh.add((Object)afuel);
                listh.add((Object)afuel);
                listh.add((Object)prevMatterIngredient);
                listh.add((Object)prevMatterIngredient);
                listh.add((Object)prevMatterIngredient);
                listh.add((Object)afuel);
                listh.add((Object)afuel);
                listh.add((Object)afuel);
                r.register(new ShapedRecipes("projectex:matter", 3, 3, listh, matter.get()).setRegistryName("matter/" + matter.func_176610_l() + "_h"));
                NonNullList listv = NonNullList.func_191196_a();
                listv.add((Object)afuel);
                listv.add((Object)prevMatterIngredient);
                listv.add((Object)afuel);
                listv.add((Object)afuel);
                listv.add((Object)prevMatterIngredient);
                listv.add((Object)afuel);
                listv.add((Object)afuel);
                listv.add((Object)prevMatterIngredient);
                listv.add((Object)afuel);
                r.register(new ShapedRecipes("projectex:matter", 3, 3, listv, matter.get()).setRegistryName("matter/" + matter.func_176610_l() + "_v"));
            }
            prevMatter = matter;
        }
        EnumTier prevTier = null;
        for (EnumTier tier : EnumTier.VALUES) {
            if (ProjectEXConfig.items.power_flowers) {
                r.register(new ShapedRecipes("projectex:compressed_collector", 3, 3, NonNullList.func_191197_a((int)9, (Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ProjectEXItems.COLLECTOR, 1, tier.ordinal())})), new ItemStack(ProjectEXItems.COMPRESSED_COLLECTOR, 1, tier.ordinal())).setRegistryName("compressed_collector/" + tier.func_176610_l()));
                NonNullList list = NonNullList.func_191196_a();
                Ingredient ccollector = Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ProjectEXItems.COMPRESSED_COLLECTOR, 1, tier.ordinal())});
                Ingredient relay = Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ProjectEXItems.RELAY, 1, tier.ordinal())});
                list.add((Object)ccollector);
                list.add((Object)Ingredient.func_193367_a((Item)ProjectEXItems.ENERGY_LINK));
                list.add((Object)ccollector);
                list.add((Object)relay);
                list.add((Object)relay);
                list.add((Object)relay);
                list.add((Object)relay);
                list.add((Object)relay);
                list.add((Object)relay);
                r.register(new ShapedRecipes("projectex:power_flower", 3, 3, list, new ItemStack(ProjectEXItems.POWER_FLOWER, 1, tier.ordinal())).setRegistryName("power_flower/" + tier.func_176610_l()));
            }
            if (prevTier != null) {
                NonNullList list;
                Ingredient matterIngredient = Ingredient.func_193369_a((ItemStack[])new ItemStack[]{tier.matter.get()});
                if (ProjectEXConfig.items.collectors) {
                    list = NonNullList.func_191196_a();
                    list.add((Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ProjectEXItems.COLLECTOR, 1, prevTier.ordinal())}));
                    list.add((Object)matterIngredient);
                    r.register(new ShapelessRecipes("projectex:collector", new ItemStack(ProjectEXItems.COLLECTOR, 1, tier.ordinal()), list).setRegistryName("collector/" + tier.func_176610_l()));
                }
                if (ProjectEXConfig.items.relays) {
                    list = NonNullList.func_191196_a();
                    list.add((Object)Ingredient.func_193369_a((ItemStack[])new ItemStack[]{new ItemStack(ProjectEXItems.RELAY, 1, prevTier.ordinal())}));
                    list.add((Object)matterIngredient);
                    r.register(new ShapelessRecipes("projectex:relay", new ItemStack(ProjectEXItems.RELAY, 1, tier.ordinal()), list).setRegistryName("relay/" + tier.func_176610_l()));
                }
            }
            prevTier = tier;
        }
    }
}

