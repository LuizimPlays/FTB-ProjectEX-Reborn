# ProjectEX 1.12.2 source index

Imported from the user-provided `projectex.zip`. These files are references only; they are not part of the active NeoForge Java source set.

Total: **88 Java files**. The supplied archive contains no non-Java resources.

## `.` (7)

`ProjectEX.java`, `ProjectEXCommon.java`, `ProjectEXConfig.java`, `ProjectEXEventHandler.java`, `ProjectEXKeyBindings.java`, `ProjectEXUtils.java`, `package-info.java`

## `block` (15)

`BlockAlchemyTable.java`, `BlockCollector.java`, `BlockEnergyLink.java`, `BlockLink.java`, `BlockLinkMK1.java`, `BlockLinkMK2.java`, `BlockLinkMK3.java`, `BlockPowerFlower.java`, `BlockRelay.java`, `BlockStoneTable.java`, `BlockTier.java`, `EnumMatter.java`, `EnumTier.java`, `ProjectEXBlocks.java`, `package-info.java`

## `client` (6)

`EnumScreenPosition.java`, `EnumSearchType.java`, `ProjectEXClient.java`, `ProjectEXClientConfig.java`, `ProjectEXClientEventHandler.java`, `package-info.java`

## `gui` (21)

`ButtonArrow.java`, `ButtonBurnItem.java`, `ButtonCreateItem.java`, `ButtonLearnItem.java`, `ButtonSlot.java`, `ButtonSmall.java`, `ButtonUnlearnItem.java`, `ContainerAlchemyTable.java`, `ContainerArcaneTablet.java`, `ContainerLink.java`, `ContainerStoneTable.java`, `ContainerTableBase.java`, `EMCFormat.java`, `GuiAlchemyTable.java`, `GuiArcaneTablet.java`, `GuiLink.java`, `GuiStoneTable.java`, `GuiTableBase.java`, `InventoryCraftingArcaneTablet.java`, `ProjectEXGuiHandler.java`, `package-info.java`

## `integration` (3)

`OfflineKnowledgeProvider.java`, `PersonalEMC.java`, `package-info.java`

## `integration/jei` (7)

`AlchemyTableCategory.java`, `AlchemyTableWrapper.java`, `ArcaneTabletJEI.java`, `EMCLinkJEI.java`, `ProjectEXJEIIntegration.java`, `StoneTableJEI.java`, `package-info.java`

## `item` (11)

`ItemArcaneTablet.java`, `ItemBlockTier.java`, `ItemColossalStar.java`, `ItemCompressedCollector.java`, `ItemFinalStar.java`, `ItemKnowledgeSharingBook.java`, `ItemMagnumStar.java`, `ItemMatter.java`, `ProjectEXItems.java`, `TomeRecipeFactory.java`, `package-info.java`

## `net` (6)

`MessageArcaneTableRecipeTransfer.java`, `MessageCreateItemButton.java`, `MessageSendLinkStack.java`, `MessageSyncEMC.java`, `ProjectEXNetHandler.java`, `package-info.java`

## `tile` (12)

`AlchemyTableRecipe.java`, `AlchemyTableRecipes.java`, `TileAlchemyTable.java`, `TileCollector.java`, `TileEnergyLink.java`, `TileLink.java`, `TileLinkMK1.java`, `TileLinkMK2.java`, `TileLinkMK3.java`, `TilePowerFlower.java`, `TileRelay.java`, `package-info.java`

