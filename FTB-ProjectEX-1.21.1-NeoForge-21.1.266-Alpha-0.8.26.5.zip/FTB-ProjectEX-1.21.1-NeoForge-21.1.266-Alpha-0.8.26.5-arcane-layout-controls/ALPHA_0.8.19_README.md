# ProjectEX Alpha 0.8.19 — All Link Tiers Open Their Inventory

## Implemented
- Personal, Refined and Compressed Refined Links now all open the registered `LinkMenu`.
- Removed the Refined/Compressed Refined chat-message fallback.
- The shared menu continues to select its slot layout from the placed block entity tier:
  - Personal: 18 input + 1 output.
  - Refined: 1 input + 9 outputs.
  - Compressed Refined: 1 input + 54 outputs.
- Opening remains server-authoritative and sends the block position through the menu opening buffer.

## Explicitly not implemented yet
- EMC value processing for inserted items.
- Learning items into the owner's ProjectE knowledge.
- EMC-funded crafting into output slots.
- Automated crafting/transmutation and its progress/status synchronization.

## Validation
- Source-level change reviewed.
- Run `gradlew.bat compileJava` and then test all three blocks in a fresh test world.
