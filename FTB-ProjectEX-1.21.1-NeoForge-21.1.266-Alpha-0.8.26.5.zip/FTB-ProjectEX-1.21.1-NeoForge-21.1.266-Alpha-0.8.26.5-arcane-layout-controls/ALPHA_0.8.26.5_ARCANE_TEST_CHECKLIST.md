# Alpha 0.8.26.5 — Arcane Tablet test checklist

## Visual alignment
- Main tablet panel should use its 176x217 original crop.
- Auxiliary 76x89 crafting panel should appear to the LEFT of the main panel.
- Search field should be 160x11 at offset (8,7).
- Page arrows should use atlas sprites at offsets (7,20) and (151,20).
- 16 ProjectE learned-item slots should be translated by (-70,+20) to sit around the magic circle.
- 3x3 crafting inputs should be at offsets (-59,17), and result at (-23,75).

## Controls
- Left side top icon: rotate clockwise; Shift+click rotates counter-clockwise.
- Left side second icon: balance stack counts; Shift+click spreads a largest stack into empty cells and balances.
- Left side third icon: cycle ProjectE search parser modes (name, mod id, tooltip, tag).
- Left side bottom icon: clear crafting grid; items that can safely be learned/burned under covalenceLoss >= 1 are converted to EMC, others return to player inventory (or drop if full).
- Green lower-left icon: learn item on cursor.
- Red lower-right icon: unlearn item on cursor.
- Central icon: burn item on cursor; Shift+click transfers EMC to/from an EMC-holder item.

## Crafting checks
- Insert a vanilla recipe into the 3x3 grid and verify result updates.
- Take output once; ingredients should be consumed once, remainders returned, known ingredients auto-refilled only when EMC is available.
- Close the tablet with ingredients still in the grid; all must return to player inventory or drop safely if full.
- Try invalid recipe, empty result, insufficient EMC, and a recipe with container remainders.
- Verify the normal ProjectE Transmutation Tablet and Transmutation Table are unchanged.

## Security / remaining parity work
- Custom action payloads validate the open ProjectE transmutation menu and Arcane Tablet in the selected hand.
- A fully independent Arcane menu and server-side interception of forged vanilla quick-move clicks are still future work.
- JEI recipe transfer is not implemented in this iteration.
