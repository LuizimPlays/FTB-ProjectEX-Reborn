# Alpha 0.8.26.2 — Alchemy Table registration overload fix

## Fix
The `AlchemyTableBlock::new` method reference was ambiguous between NeoForge `DeferredRegister.register(String, Supplier)` and `register(String, Function<ResourceLocation, ...>)`. The registration now explicitly casts the zero-argument factory lambda to `Supplier<Block>` and invokes the no-argument constructor.

The block codec and its `Properties` constructor are unchanged. No Alchemy Table processing, recipe, inventory, or GUI behavior was modified.

## Build validation
The source registration was checked to use an explicitly typed `Supplier<Block>`. Run `gradlew.bat compileJava` locally to confirm against the installed NeoForge 21.1.266 workspace. The EventBusSubscriber deprecation warnings are unrelated to this compile error.
