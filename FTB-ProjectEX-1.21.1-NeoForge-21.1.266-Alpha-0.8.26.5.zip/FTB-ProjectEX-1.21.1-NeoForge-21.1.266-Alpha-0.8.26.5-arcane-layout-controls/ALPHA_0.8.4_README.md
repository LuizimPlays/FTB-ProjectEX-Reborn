# ProjectEX Alpha 0.8.4 — ProjectE EMC item mapping

## Included
- Added a ProjectE `@EMCMapper` integration for the ProjectEX item registry.
- Every registered `projectex` item receives an explicit EMC value, so ProjectE can expose it to knowledge learning and transmutation.
- Matter items use tier-based EMC values; collectors, compressed collectors, relays and power flowers scale with their tier.
- Magnum and Colossal Stars scale by star tier. Link blocks, tables, books, tablet and progression items also receive values.
- Values are inserted with `setValueBefore`, allowing normal ProjectE recipe mappings to remain available when they provide a better derived result.
- Arcane Tablet UI and behavior were not modified in this increment.

## In-game use
1. Start a world with ProjectE and ProjectEX enabled so ProjectE performs its EMC mapping pass.
2. Open the ProjectE Transmutation interface (Transmutation Table/Stone or ProjectE tablet).
3. Learn a ProjectEX item by placing it in the learning slot when you have enough EMC.
4. Retrieve additional copies from the learned-item list; the EMC cost is deducted by ProjectE.

## EMC balance notes
Values are initial progression values intended for testing, not final balance. The mapping covers all items in the `projectex` namespace, including items that do not yet have a crafting recipe.

## Validation
Compilation could not be completed in this environment: Gradle Wrapper attempted to download Gradle 8.12.1 from `services.gradle.org`, but DNS/network access was unavailable (`UnknownHostException`). No successful build is claimed. Run `gradlew.bat compileJava` in the user's development environment before installing this build.
