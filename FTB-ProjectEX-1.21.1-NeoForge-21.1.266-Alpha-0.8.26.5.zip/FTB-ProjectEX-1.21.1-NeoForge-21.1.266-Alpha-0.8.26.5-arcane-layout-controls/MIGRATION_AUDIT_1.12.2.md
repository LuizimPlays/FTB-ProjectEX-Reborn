# ProjectEX 1.12.2 -> NeoForge 1.21.1 Migration Audit

## Source bundle supplied by the user

- The user-provided `projectex.zip` contains 88 Java source files across block, client, gui, integration, item, net and tile packages.
- It does **not** contain textures, models, blockstates, recipes, sounds, language files, or other binary/resource assets.
- The original sources are kept under `legacy_reference/1.12.2/java/projectex/` and are not included in the active Gradle source set. This prevents 1.12.2 Forge imports from breaking the NeoForge build.
- The original ZIP is also preserved as `legacy_reference/1.12.2/projectex-1.12.2-source-only.zip`.

## Current migration snapshot

| Original subsystem | Original files | Current 1.21.1 state |
|---|---|---|
| Blocks and tiers | BlockAlchemyTable, BlockCollector, BlockEnergyLink, BlockLink/MK1/MK2/MK3, BlockPowerFlower, BlockRelay, BlockStoneTable, BlockTier, EnumMatter, EnumTier | Core registrations/entities exist; parity and behaviors remain under review |
| Link containers / screens | ContainerLink, GuiLink, GuiTableBase, GuiStoneTable, GuiAlchemyTable, ContainerStoneTable, ContainerAlchemyTable | Link menus/screens exist for 3 tiers; Stone/Alchemy table UI still needs migration |
| Arcane Tablet | ContainerArcaneTablet, GuiArcaneTablet, InventoryCraftingArcaneTablet, buttons and table base | Existing 1.21.1 integration attaches a 3x3 grid to ProjectE's TransmutationContainer; compile issue fixed in this increment; JEI transfer and complete verification remain pending |
| Machines | TileLink, TileLinkMK1/2/3, TileEnergyLink, TileCollector, TileRelay, TilePowerFlower, TileAlchemyTable | NeoForge block entities exist; continue behavior-by-behavior parity work |
| Items | ItemArcaneTablet, ItemBlockTier, ItemColossalStar, ItemCompressedCollector, ItemFinalStar, ItemKnowledgeSharingBook, ItemMagnumStar, ItemMatter, TomeRecipeFactory | Modern registrations exist; verify every legacy behavior, tooltip, recipe and use action individually |
| Networking / EMC | MessageArcaneTableRecipeTransfer, MessageCreateItemButton, MessageSendLinkStack, MessageSyncEMC, PersonalEMC, OfflineKnowledgeProvider | Modern EnergyLink payloads and EMC APIs exist; legacy offline knowledge and custom packet semantics require further parity tests |
| JEI integration | ArcaneTabletJEI, EMCLinkJEI, AlchemyTableCategory/Wrapper, StoneTableJEI, ProjectEXJEIIntegration | Not fully ported to the active 1.21.1 source set |

## Alpha 0.8.24 implementation in this increment

- Fixed the Arcane crafting slot registration compile error by invoking the protected `AbstractContainerMenu.addSlot` method through one isolated, cached reflection helper. This calls the original menu registration path rather than manually editing menu lists.
- Corrected `Slot.onTake` to the 1.21.1 `void` signature.
- Link output filters now behave as ghost configuration: selecting a filter copies one representative stack without consuming the cursor item; it also learns that EMC item for the owner, matching the legacy `setOutputStack(..., addKnowledge=true)` flow.
- Clearing a filter no longer returns/drops the copied ghost stack. This prevents item duplication.
- External automation may insert only into real input slots; output slots are EMC-funded extraction endpoints, matching the legacy ItemHandler contract.
- Input slots reject items without positive EMC. Personal Link import now applies ProjectE's current server covalence-loss multiplier and rounding behavior.
- Output-filter configuration and crafting purchases remain owner-checked and server-authoritative.
- Virtual output previews follow the original high `emc_link_max_out` default (2,000,000,000); extraction itself is capped to each item's legal stack size.

## Not claimed complete

- No full build or in-game regression suite has been completed in this environment.
- Arcane Tablet's JEI recipe-transfer plugin, button set (rotate/balance/spread/clear), and full legacy recipe refill UX remain to be ported.
- Stone Table, Alchemy Table and full legacy integrations still require implementation.
- The source archive supplied by the user contains Java only; missing original 1.12.2 assets must be supplied separately if pixel-perfect fidelity is required.
- The legacy Link and Arcane behaviors should be compared in-game against 1.12.2 before declaring parity.

## Validation to run locally

1. `gradlew.bat compileJava`
2. `gradlew.bat build`
3. Test ghost filter selection/clear without consuming or duplicating the cursor item.
4. Test Personal Link import at non-default ProjectE covalence-loss settings.
5. Test automation insertion into input and extraction from outputs.
6. Test Arcane crafting result click, remainder items, ingredient refill, close/return behavior and normal ProjectE Transmutation Table isolation.


## Alpha 0.8.25 — Stone Table vertical slice

The generic Stone Table registration has been replaced with a directional interactive block and dedicated menu/screen. The port now includes the eight radial knowledge entries, 1.12.2 search field and paging arrows, learn/unlearn, burn, Shift-burn for ProjectE EMC-holder items, buy-one, buy-stack, covalence-loss application, player inventory synchronization, and server validation of menu ID/range/knowledge/balance. The old optional whitelist and JEI text synchronization are not yet migrated. This vertical slice has not passed Gradle or in-game validation.
