# ProjectEX Alpha 0.8.8 — EMC HUD polish

Base: Alpha 0.8.7 (Minecraft 1.21.1 / NeoForge 21.1.266).

## Changes
- Reworked the upper-left EMC HUD with a layered dark panel, subtle outline, emerald accent, clearer typography, and improved spacing.
- The compact HUD continues to show abbreviated EMC balance and measured EMC/s rate.
- While the local player is crouching (the normal SHIFT sneak action), the HUD expands and displays the exact EMC balance using the complete un-abbreviated integer string.
- Very long balances are split across visual lines so no digits are omitted or pushed off-screen.
- Rate sampling resets when the local player changes, preventing stale values after player/world changes.
- Machine telemetry and existing gameplay values/recipes are retained from Alpha 0.8.7.

## Validation
- Source-level review completed. Run `gradlew.bat build` with JDK 21 and test in-game before installing.
