# FTB ProjectEX 1.21.1 - Alpha 0.8.0 (functional transmutation integration)

## What changed

- Arcane Tablet now opens ProjectE 1.21.1's real `TransmutationContainer`.
- The menu is created with the actual hand and selected hotbar slot, using ProjectE's own network menu factory.
- EMC balance, knowledge, search, paging, learning/unlearning, and transmutation output slots are handled by ProjectE's server-authoritative implementation.
- The previous non-functional ProjectEX placeholder menu is no longer used by the Arcane Tablet item.
- Energy Link, Power Flower, and HUD source files were left unchanged.

## Important scope note

This is the functional backend integration pass. The original ProjectEX dark custom skin and its separate 3x3 crafting panel are not yet fully ported. The Arcane Tablet currently uses ProjectE's registered transmutation screen so that its core mechanics are real and synchronized rather than simulated by decorative client-only slots. The next pass can safely skin the working menu and then port the old crafting panel with actual recipe slots.

## Build

Run `gradlew.bat build` using the project's supplied Gradle wrapper. The build was not executed in this environment because Gradle 8.12.1 is not installed/cached here and external distribution downloads are unavailable.
