# Auditoria inicial de migração — Alpha 0.8.14

## Arquivos de referência
- `ProjectEX-1.2.0.40.jar`: binário original 1.12.2 enviado pelo usuário.
- `FTB-ProjectEX-1.21.1-NeoForge-21.1.266-Alpha-0.8.14-source.zip`: código-fonte atual enviado pelo usuário.

## Observações de estrutura
- O código atual declara Minecraft 1.21.1, NeoForge 21.1.266, Java 21 e versão `0.8.14-alpha`.
- A pasta `legacy_reference` no ZIP contém apenas um README; não contém o código Java legado descrito como referência. A comparação da versão antiga, nesta etapa, foi feita contra as classes presentes no JAR binário.
- O JAR legado contém implementações distintas para três tiers de Link, Energy Link, Stone Table, Alchemy Table, Arcane Tablet, estrelas, compressed collectors, livro de compartilhamento, JEI e Offline Knowledge.
- A árvore Java atual tem aproximadamente 1.711 linhas e não contém pacotes equivalentes a várias dessas implementações antigas.
- A listagem de receitas/loot tables atuais mostra que vários recursos já têm dados declarativos, mas isso não substitui a lógica de block entities, menus, sincronização e comportamento dos itens.

## Primeira prioridade recomendada
Os Links são o primeiro grande subsistema a portar: no original há uma classe-base `TileLink` com inventários de entrada/saída, EMC armazenado, proprietário, nome, aprendizagem de itens, transferência e três especializações (`MK1`, `MK2`, `MK3`). No código atual, os três blocos correspondentes são blocos genéricos. A implementação deve começar pela especificação do contrato legado e só então construir block entity/menu/pacotes NeoForge.

## Limitações desta rodada
A compilação não foi executada: o wrapper precisou baixar Gradle 8.12.1 e a rede do ambiente não conseguiu resolver `services.gradle.org`. Não afirmar que o projeto compila até uma execução real de `gradlew build`.
