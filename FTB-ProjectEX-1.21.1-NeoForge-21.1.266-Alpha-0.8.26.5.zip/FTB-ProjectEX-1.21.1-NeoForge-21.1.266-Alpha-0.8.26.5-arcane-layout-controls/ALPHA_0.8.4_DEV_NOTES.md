# Alpha 0.8.4 development notes

- Scope: EMC mapping for ProjectEX items and ProjectE transmutation eligibility.
- New class: `dev.latvian.mods.projectex.emc.ProjectEXEMCMapper`.
- Mapper is discovered through ProjectE's `@EMCMapper` scan and registered through its `@EMCMapper.Instance` field.
- Uses ProjectE API `IMappingCollector.setValueBefore(NSSItem, Long)`.
- No changes to Arcane Tablet, Energy Link block entities, or player EMC storage in this increment.
- Build blocked by unavailable Gradle 8.12.1 distribution download; must compile and test in local Windows workspace.
