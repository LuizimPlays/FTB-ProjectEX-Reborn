# FTB ProjectEX Alpha 0.8.26 — Alchemy Table port

Target: Minecraft 1.21.1 / NeoForge 21.1.266 / ProjectE 1.21.1 PE1.1.0.

## Ported from the supplied 1.12.2 source

Source classes reviewed:
- `projectex/tile/TileAlchemyTable.java`
- `projectex/tile/AlchemyTableRecipe.java`
- `projectex/tile/AlchemyTableRecipes.java`
- `projectex/block/BlockAlchemyTable.java`
- `projectex/gui/ContainerAlchemyTable.java`
- `projectex/gui/GuiAlchemyTable.java`
- `projectex/integration/jei/AlchemyTableCategory.java`
- `projectex/integration/jei/AlchemyTableWrapper.java`

## Implemented in the 1.21.1 branch

- Replaced the previous ProjectE Transmutation Stone alias with a ProjectEX `AlchemyTableBlock` and block entity.
- Registered a dedicated block entity, server ticker, menu type, client screen, EMC storage capability, and item-handler capability.
- Added the original two-slot behavior: recipe-valid input and protected output.
- Added the original 12 default transformation chains (31 transitions) using modern item/block registry entries.
- Processing is server-authoritative, one input item per completed operation.
- Default progress is 200 server ticks; cost is `max(64, (input EMC + output EMC) * 3)` unless a recipe override is supplied.
- EMC buffer capacity is eight times the current recipe cost; the table accepts EMC but does not expose it for extraction.
- Processing pauses if EMC is insufficient or the output is full/occupied by a different result.
- Input, output, EMC buffer, and progress are saved in block entity NBT.
- The two menu data values synchronize progress and EMC bars to the open client screen.
- Contents are dropped if the block is removed.
- Restored the original flame particle positions and table collision shape from the legacy implementation.

## Preserved

- Existing Stone Table, Links, Energy Link, Collectors, Relays, Power Flowers, recipes, and Arcane Tablet sources are carried forward from Alpha 0.8.25.1.
- The `projectex:alchemy_table` registry identifier and existing item/block model assets are retained.

## Not yet ported/verified

- JEI Alchemy Table recipe category is not registered in this module. Its 1.12.2 source was identified, but modern JEI API integration needs a separate optional-integration module.
- Recipe chains were ported to modern item IDs, but each EMC value should be confirmed in-game with the exact ProjectE configuration in use.
- No full Gradle compile or Minecraft runtime test was possible in this environment because Gradle 8.12.1 could not be downloaded (`UnknownHostException: services.gradle.org`).
- Multiplayer, automation with hoppers, save/reload, and output-full recovery still require runtime verification.

## Build and test

Use JDK 21, then run `gradlew.bat build`. Install the generated JAR alongside the matching ProjectE 1.21.1 build. Test every recipe chain, input/output automation, insufficient EMC, full output, world save/reload, and removal/drop behavior.
