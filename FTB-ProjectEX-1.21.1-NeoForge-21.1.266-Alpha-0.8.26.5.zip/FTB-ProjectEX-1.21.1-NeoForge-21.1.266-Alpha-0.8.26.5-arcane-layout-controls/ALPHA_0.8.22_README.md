# FTB ProjectEX Alpha 0.8.22 — Classic Links + Arcane Crafting

Minecraft 1.21.1 · NeoForge 21.1.266 · ProjectE PE1.1.0

## EMC Links
- Reworked the Personal, Refined and Compressed Refined Links to use persistent output-filter slots (1 / 9 / 54), rather than paging the owner's entire learned-item list into those slots.
- Personal Link: up to 18 input slots import EMC-valued items into the owner's ProjectE balance; its one output filter can be clicked to withdraw an affordable stack or right-clicked to withdraw one item.
- Refined and Compressed Refined: one input slot learns the inserted EMC-valued item for the owner; each configured output filter produces that learned item for EMC.
- Output filters persist independently from input inventories and are saved to block-entity NBT.
- The block `IItemHandler` exposes inputs for insertion and filter outputs as virtual EMC-funded stock for extraction, enabling hoppers/pipes/storage-network automation.
- Shift-clicking an output filter clears it and returns the filter item to the owner's inventory; normal click with an item on the cursor configures a filter.
- Link menus are owner-only; the owner UUID remains bound to the block.
- Legacy `Inventory` NBT from pre-0.8.22 saves is split into input storage and output filters when loading.
- Owner EMC/knowledge is resolved through ProjectE's UUID-backed transmutation provider, so processing and withdrawals do not depend on the owner being online. Online owners receive normal EMC/knowledge sync packets.

## Arcane Transmutation Tablet
- Reuses ProjectE's actual `TransmutationContainer` and GUITransmutation base so the existing search, learned-item ring, pages, learning/unlearning and EMC operations remain authoritative.
- Attaches a real 3x3 crafting input grid and one result slot to the right side of the Arcane atlas on both client and server.
- Craft results use the 1.21.1 vanilla recipe manager and recipe remainder rules.
- Taking a result consumes one recipe; ingredients with no container remainder are automatically bought back into their original cells from the player's EMC if the ingredient is learned and affordable. This allows repeat crafting until EMC runs out.
- Remaining grid ingredients are returned to the player when the tablet closes; if the inventory is full, the items are dropped safely instead of deleted.
- Right-click partial extraction of multi-item recipe results and Shift-click on the appended grid are blocked in the Arcane screen to avoid free outputs or ProjectE's inherited quick-sell behavior.

## Important limitations / follow-up
- JEI recipe-transfer buttons for the Arcane Tablet are not yet implemented.
- Shift-click protection for the Arcane grid is enforced in the normal client UI path; a dedicated server-side interception/mixin for forged container-click packets is not included in this iteration.
- Link target filters are configured by placing one EMC-valued item in an output slot. The item is used as the filter; it is not consumed as production stock. Production requires that the owner's ProjectE knowledge contains the item and that the owner has enough EMC.
- This package has not been verified with a completed Gradle build or in-game multiplayer test in this environment. Please run the build and perform the test checklist below before using it in a valuable world.

## Test checklist
1. Run `gradlew.bat compileJava`, then `gradlew.bat build` using JDK 21.
2. Place each Link type and confirm only the owner can open it.
3. Personal Link: insert known EMC items into its 18 input slots; verify the items are consumed and owner's EMC rises. Configure the output filter with a known item; left-click should take an affordable stack, right-click one item, Shift-click should clear and return the filter.
4. Refined / Compressed: insert an EMC-valued item in the input slot; verify it is learned, then configure an output filter and buy it with EMC.
5. Connect hoppers or another `IItemHandler` consumer: insert into Link inputs, insert a target into an output filter, extract virtual outputs; verify EMC is charged exactly once per extracted item.
6. Save/reload the world and verify input items, output filters, owner, and EMC buffer persist.
7. Arcane Tablet: place a vanilla recipe in the 3x3 grid, take output, confirm ingredient refill if learned/affordable, confirm bucket/container remainders, close with items left in the grid, and verify they return to inventory or drop without loss.
8. Repeat with a second player and a dedicated server to verify ownership, EMC/knowledge sync, and menu slot synchronization.
