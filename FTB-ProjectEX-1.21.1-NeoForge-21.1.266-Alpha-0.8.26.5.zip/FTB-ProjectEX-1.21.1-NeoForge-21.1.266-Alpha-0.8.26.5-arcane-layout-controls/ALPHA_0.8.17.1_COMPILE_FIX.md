# Alpha 0.8.17.1 — LinkScreen compile fix

## Fix
- Replaced the undefined `inventory` identifier in `LinkScreen.renderLabels` with the inherited `playerInventory` field supplied by `AbstractContainerScreen`.
- No menu, slot, inventory, EMC, transfer, or persistence behavior was changed.
- The two `EventBusSubscriber.Bus.MOD` deprecation warnings are unchanged; they are warnings, not compilation errors.

## Build
Run `gradlew.bat compileJava` or `gradlew.bat build` with JDK 21. This source patch is not claimed as build-verified unless the local command succeeds.
