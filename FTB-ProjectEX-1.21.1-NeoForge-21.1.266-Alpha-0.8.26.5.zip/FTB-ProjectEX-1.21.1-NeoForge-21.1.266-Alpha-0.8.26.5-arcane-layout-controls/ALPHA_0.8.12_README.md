# ProjectEX Alpha 0.8.12 — Responsive Energy Link & HUD feedback

## Changes
- Energy Link now forwards its stored EMC to its online owner every 5 server ticks (four times per second), instead of batching delivery once per second.
- The Energy Link status screen polls every 5 client ticks, so buffer, last delivery, total delivered, and owner balance refresh at the same cadence.
- Offline owners do not lose buffered EMC; the full amount remains stored until the owner is online.
- The classic HUD now renders the `EMC:` label in white. The balance briefly flashes green when a positive EMC gain is detected; the EMC/s line retains its existing green/red feedback.
- Exact EMC amounts continue to use BigInteger internally, including transfers larger than Long.MAX_VALUE.

## EMC accounting
- The Energy Link is a transport/storage block, not an EMC generator or multiplier. It transfers exactly the EMC inserted into its buffer and does not create duplicate EMC.

## Preserved
- Existing recipes, collector generation, relay bonuses, Power Flower behavior, Energy Link ownership, and Arcane Tablet implementation.

## Build and test
Run `gradlew.bat build` using JDK 21 and NeoForge 21.1.266.
Test with an online owner and an adjacent EMC producer: confirm the buffer drains into the owner's balance four times per second, the screen updates smoothly, and the HUD balance flashes green on gains. Then take the owner offline and confirm the buffer is retained until they reconnect.
