# FTB ProjectEX Alpha 0.8.24 — 1.12.2 behavior migration foundation

## Changes
- Preserved the complete user-supplied 1.12.2 Java source bundle as a migration reference under `legacy_reference/1.12.2/`. Legacy sources are deliberately not compiled with the 1.21.1 source set.
- Fixed the Arcane crafting slot registration compile blocker by using one isolated reflective bridge to the protected menu `addSlot` method. This preserves the vanilla/ProjectE slot-registration bookkeeping.
- Corrected the Arcane result slot callback to the Minecraft 1.21.1 `void onTake(Player, ItemStack)` method signature.
- Reworked Link output filter semantics to match the original ghost-filter model: setting a filter copies the cursor item, learns its EMC info for the owner, and never consumes the cursor stack.
- Clearing an output filter now clears only configuration. It no longer returns a copied ghost item, preventing duplication.
- External ItemHandler automation can insert into real input slots only; EMC output slots are extraction-only.
- Link input slots reject items without positive EMC. Shift-clicking an EMC-valued item from a Link slot or the player inventory now follows the original quick-move import path: it teaches the item, auto-fills the first free output filter, converts the batch to buffered EMC, and consumes the source stack only on the server.
- Personal Link EMC import applies ProjectE's current server-side covalence-loss multiplier and truncates the batch result to an integer, matching the legacy Link calculation.
- Output requests remain limited to available owner knowledge and EMC; automated extraction returns legal item-stack sizes while the handler's visible output count follows the original high max-output default (2,000,000,000).

## Important source inventory finding
The supplied `projectex.zip` contains 88 Java files but no original 1.12.2 textures, models, blockstates, recipes, sounds, language files or other resource assets. The existing 1.21.1 project resources remain intact. To achieve pixel-identical fidelity, the missing original resource pack still needs to be supplied separately.

## Not yet complete
- JEI integration and Arcane recipe-transfer support.
- Full Arcane buttons and recipe refill UX (rotate, balance, spread, clear, and JEI transfer).
- Stone Table, Alchemy Table, and all legacy network/knowledge integration behaviors.
- Full multiplayer, automation and reload regression testing.

## Build status
A full Gradle build is not claimed in this package. Run `gradlew.bat compileJava` and `gradlew.bat build` on the configured JDK 21 / NeoForge 21.1.266 environment before installing.


## Additional safety pass
- If the ProjectE covalence multiplier makes the imported Personal Link EMC amount zero, the input item is retained instead of being consumed for no return.
- Link menu actions check the bound owner UUID before changing filters or spending EMC.
- Removed a duplicate import in `LinkBlock.java`.
- The Link EMC capability is sink-only, matching the classic implementation: neighboring producers may insert EMC, but pipes cannot extract the owner-bound pending buffer.
