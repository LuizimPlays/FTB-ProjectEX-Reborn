# ProjectEX Alpha 0.8.5 — Energy Link live status

## Changes
- Increased the Energy Link status screen refresh frequency from once per second to four times per second (every 5 client ticks).
- The screen continues to request authoritative values from the server; it does not estimate or locally fake EMC values.
- Existing owner-bound EMC buffer, persistence, transfer-to-owner behavior, and ProjectE EMC storage capability are retained.
- The Transmutation Table EMC mapper and Arcane Tablet code are unchanged from Alpha 0.8.4.

## Test plan
1. Build with `gradlew.bat build` using Java 21 and the project's configured Gradle 8.12.1 wrapper.
2. Install the resulting mod with ProjectE 1.21.1.
3. Place an Energy Link and verify the placer is shown as its owner.
4. Place an EMC-producing ProjectEX machine adjacent to it and verify the buffer rises in the status screen.
5. Keep the screen open and confirm buffer/owner EMC values refresh several times per second.
6. Wait for transfer to the owner, then save/reload the world and verify the accumulated transfer statistics persist.

## Validation status
Not compiled in this environment. The Gradle wrapper requires Gradle 8.12.1, and the distribution download failed because `services.gradle.org` could not be resolved. Please run `gradlew.bat build` locally before installing; no error-free build is claimed.
