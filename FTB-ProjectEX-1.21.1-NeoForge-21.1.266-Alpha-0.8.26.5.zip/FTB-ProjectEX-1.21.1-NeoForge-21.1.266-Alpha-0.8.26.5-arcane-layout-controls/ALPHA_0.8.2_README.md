# FTB ProjectEX Alpha 0.8.3 — Arcane Tablet Layout Reconstruction

## What changed
- The Arcane screen now uses the actual 184x220 main-tablet viewport from the supplied 256x256 texture atlas.
- The decorative 3x3 panel at the right of the atlas is clipped out. It was not connected to a crafting container, so displaying it suggested functionality that did not exist and caused the transmutation item slots to overlap it.
- The inherited ProjectE transmutation output/lock slots are shifted inward so their horizontal positions stay inside the tablet body.
- Previous/next page controls are repositioned inside the main panel.
- The inherited ProjectE search widget, EMC/status rendering, transmutation inventory, item learning, page changes, and server-side transaction logic are retained.
- The regular ProjectE Transmutation Tablet/Table screen is not changed.

## Important scope note
This is a layout correction for the existing ProjectE transmutation screen, not yet a port of the original 1.12.2 Arcane Tablet's separate 3x3 crafting feature. The auxiliary panel is intentionally hidden until a real server-backed crafting menu and recipe handling are implemented.

## Build and test
Run `gradlew.bat build` in the configured NeoForge 21.1.266 environment. This archive has not been compiled in the packaging environment because Gradle 8.12.1 is not cached and external network access is unavailable. Please confirm the local build before installing the JAR.
