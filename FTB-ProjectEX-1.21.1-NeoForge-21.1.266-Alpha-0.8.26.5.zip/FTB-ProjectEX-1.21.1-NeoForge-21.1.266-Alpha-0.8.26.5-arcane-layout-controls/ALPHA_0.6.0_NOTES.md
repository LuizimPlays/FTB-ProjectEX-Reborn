# FTB ProjectEX Alpha 0.6.0 - EMC balance display + functional Arcane Transmutation Table

## Changes
- Power Flower right-click now distinguishes machine buffer (`Armazenado na máquina`) from the owner's ProjectE EMC account (`Saldo EMC`). When the owner is online, it reads the live account balance from ProjectE's knowledge capability. If the owner is offline, it reports that the balance is unavailable rather than showing a misleading zero.
- `alchemy_table` now registers ProjectE's own `TransmutationStone` block class. This reuses ProjectE's established transmutation menu, inventory handling, EMC checks, item knowledge, and transmutation behavior rather than introducing a nonfunctional custom screen.

## Build / test
Build using `gradlew.bat build` on the user's Windows development environment. This environment could not run the build because it could not resolve `services.gradle.org` to download Gradle 8.12.1; compilation is therefore not confirmed.
