# ProjectEX Alpha 0.8.26.4 — Recipe tag compatibility fix

## Cause
Several crafting recipes referenced legacy Forge item tags (`forge:*`) which are not populated by this NeoForge 1.21.1 setup. JEI therefore rendered barrier icons and reported Empty Tag, most visibly for `forge:rods/wooden` and `forge:gems/diamond` in the Alchemy Table recipe.

## Changes
- Migrated all legacy `forge:` recipe references to NeoForge common `c:` item tags.
- Added additive vanilla defaults for wooden rods, diamond gems, glass blocks, normal obsidian, natural stones, and chests.
- Updated affected recipes: Alchemy Table, Energy Link, Basic Collector, Arcane Tablet, and Basic Relay.
- Bumped the project version to `0.8.26.4-alpha`.

## Compatibility
The new common-tag files use `replace: false`, so third-party mods and datapacks can continue adding compatible items. Vanilla items are included as guaranteed defaults, avoiding empty recipe ingredients on a clean NeoForge installation.

## Validation
- All recipe JSON and newly-created tag JSON files were parsed successfully.
- Confirmed there are no remaining `forge:` tag references under `data/projectex/recipe`.
- Full Gradle build and in-game JEI verification still need to be run on the target installation.
