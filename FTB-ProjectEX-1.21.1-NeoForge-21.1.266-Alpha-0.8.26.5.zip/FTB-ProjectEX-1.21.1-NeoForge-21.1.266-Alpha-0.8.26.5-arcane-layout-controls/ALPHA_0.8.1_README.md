# FTB ProjectEX 1.21.1 - Alpha 0.8.1 (Arcane Tablet visual integration)

## Changes from Alpha 0.8.0

- Added a dedicated Arcane Tablet screen class that reuses ProjectE's real `GUITransmutation` implementation.
- The screen-opening hook swaps the GUI only when the player opened the ProjectE transmutation menu while holding the ProjectEX Arcane Tablet.
- ProjectE's normal Transmutation Tablet and Transmutation Table screens are left unchanged.
- The Arcane Tablet uses the ProjectEX dark 1.12.2-era GUI atlas (`assets/projectex/textures/gui/arcane_tablet.png`).
- Search, paging, EMC display, knowledge handling, output slots, learning and unlearning remain backed by ProjectE's original menu/container implementation.
- No duplicate menu type or second EMC/knowledge system was introduced.

## Important scope notes

This is a visual integration pass over ProjectE's actual transmutation menu. The side 3x3 crafting panel artwork is present in the legacy atlas, but its recipe-grid behavior is not implemented by this change. The live menu still uses ProjectE's native transmutation slot layout and interactions.

The screen replacement is triggered by NeoForge's `ScreenEvent.Opening`, so it does not register a second screen for ProjectE's menu type and does not overwrite the normal ProjectE table/tablet screen registration.

## Build and test

Run from the project directory:

```powershell
.\gradlew.bat build
```

Then test:
1. Open the ProjectEX Arcane Tablet.
2. Confirm the dark ProjectEX skin appears.
3. Search for a learned item and use the page arrows.
4. Insert an item into the learning/consume slot and confirm the EMC/knowledge behavior.
5. Open the normal ProjectE Transmutation Tablet and Table and confirm their original screen remains unchanged.

The build was not verified in this execution environment: the Gradle wrapper attempted to download Gradle 8.12.1, but outbound network access is unavailable. Treat this ZIP as a source update that still requires a local compile/test.
