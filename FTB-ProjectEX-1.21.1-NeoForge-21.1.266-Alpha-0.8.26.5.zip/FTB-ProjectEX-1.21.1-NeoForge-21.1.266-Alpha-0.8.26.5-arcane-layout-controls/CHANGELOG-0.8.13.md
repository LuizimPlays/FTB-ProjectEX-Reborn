# FTB ProjectEX 0.8.13-alpha

Target: Minecraft 1.21.1 / NeoForge 21.1.266

## Energy Collector and Antimatter Relay pass
- Added lightweight client-side energy particles to Energy Collectors.
- Added lightweight client-side transfer particles to Antimatter Relays.
- Kept EMC generation, storage, relay bonuses, and transfers server-authoritative.
- Preserved the existing tier values, 20-tick production cadence, EMC capability API,
  and NBT field names so existing worlds retain their stored EMC and counters.

## Validation
- Source review completed against the included 1.18.1 migration reference.
- Build could not be run in this environment because Gradle 8.12.1 is not cached
  and the environment cannot reach services.gradle.org to download it.
