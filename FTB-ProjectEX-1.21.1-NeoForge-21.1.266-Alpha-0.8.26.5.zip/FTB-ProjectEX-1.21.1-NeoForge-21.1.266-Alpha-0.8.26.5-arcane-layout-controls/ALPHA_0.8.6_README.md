# ProjectEX Alpha 0.8.6 — Recipes + Energy Link

Base: Alpha 0.8.5 (Minecraft 1.21.1 / NeoForge 21.1.266).

## Changes
- Migrated ProjectEX data recipes from `data/projectex/recipes/` to the 1.21+ singular path `data/projectex/recipe/`.
- Migrated recipe result ItemStacks from the legacy `result.item` field to `result.id`.
- Preserved the existing recipe definitions and progression ingredients.
- Preserved Energy Link implementation and UI from Alpha 0.8.5.

## Validation
- All recipe JSON files were parsed and re-serialized as valid JSON during packaging.
- This is a data/resource migration review, not a Gradle/Minecraft runtime build. Run `gradlew.bat build` and test recipe loading in-game.
