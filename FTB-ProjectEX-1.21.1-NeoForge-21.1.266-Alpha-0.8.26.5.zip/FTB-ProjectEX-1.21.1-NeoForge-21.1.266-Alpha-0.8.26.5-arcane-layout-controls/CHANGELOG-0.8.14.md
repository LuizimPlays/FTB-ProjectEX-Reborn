# FTB ProjectEX 0.8.14-alpha

Target: Minecraft 1.21.1 / NeoForge 21.1.266

## EMC HUD stability
- Kept the existing top-left HUD layout, position, panel, dimensions and text.
- Removed the temporary gain flash that changed the balance text and panel edge colors.
- Kept the EMC balance permanently yellow and the rate permanently green.
- Negative EMC rates now retain the same fixed green text color; the minus sign still communicates direction.
- Removed render-tick color transitions to prevent the reported color flicker.

## Energy Link follow-up
- Preserved the existing Energy Link dashboard, server refresh, owner status, buffer and transfer totals.
- No network payload or saved NBT format changes in this patch.

## Validation
- Source-level inspection completed.
- A full Gradle build still needs to be run in an environment with Gradle 8.12.1 and dependency access.
