# ProjectEX Alpha 0.8.25.1 — Stone Table screen tick fix

## Compiler error fixed
- Replaced the illegal override of `AbstractContainerScreen.tick()` with the supported `containerTick()` hook for Minecraft 1.21.1.
- The screen still polls knowledge changes and refreshes the search/catalogue at the same interval.
- `super.containerTick()` is called before custom screen updates.

## Warnings
- `EventBusSubscriber.Bus.MOD` deprecation warnings in LinkScreenClient and StoneTableScreenClient remain warnings only; they were not responsible for the compile failure.

## Validation
- The exact compile error reported for `StoneTableScreen.tick()` is addressed.
- Full Gradle compilation still needs confirmation in the user's JDK 21 / NeoForge 21.1.266 environment. No successful build is claimed here.
