# Alpha 0.8.26.3 — Visual test checklist

1. Place Alchemy Table on a full opaque block and inspect it from all four sides. Verify tabletop, four legs and candles are visible; only the normal outline should appear when targeted.
2. Open Alchemy Table. Confirm the two-slot GUI, arrow, EMC/progress bars and player inventory render; neutral grey panel matches the original 1.12.2 design.
3. Open Stone Table. Confirm `Inventário` starts to the right of the green Learn button and does not overlap it.
4. Recheck learn, unlearn, burn, page navigation, one-item purchase, stack purchase and search.
