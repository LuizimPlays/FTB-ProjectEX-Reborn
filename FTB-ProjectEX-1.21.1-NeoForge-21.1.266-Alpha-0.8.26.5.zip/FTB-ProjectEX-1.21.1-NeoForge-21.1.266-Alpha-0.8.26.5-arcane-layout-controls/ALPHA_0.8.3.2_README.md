# FTB ProjectEX Alpha 0.8.3.2 — Arcane Tablet Layout Correction

This patch addresses the clipping visible in Alpha 0.8.3.1:

- Uses the measured 176x216 main-panel bounds from `arcane_tablet.png`, preventing the adjacent 3x3 panel from bleeding into the screen.
- Repositions ProjectE's 16 output-ring slots (container slot indices 11–26) 40 pixels left. Since `Slot.x` is final in Minecraft 1.21.1, the client screen uses reflective assignment so rendered items and click hitboxes share the corrected coordinates.
- Leaves the eight input slots, lock/consume/unlearn slots, player inventory, server-side EMC logic, and the normal ProjectE Transmutation Tablet untouched.
- Keeps the real ProjectE transmutation container and page controls.

Build with `gradlew.bat build` on the configured NeoForge 21.1.266 toolchain. This environment does not have the Gradle distribution cached, so a full Gradle build could not be run here.
