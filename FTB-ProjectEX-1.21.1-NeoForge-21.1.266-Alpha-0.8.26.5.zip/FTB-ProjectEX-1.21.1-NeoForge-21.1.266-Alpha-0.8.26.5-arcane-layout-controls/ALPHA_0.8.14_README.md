# FTB ProjectEX Alpha 0.8.14
Minecraft 1.21.1 / NeoForge 21.1.266

This patch stabilizes the existing top-left EMC HUD without redesigning it:
balance stays yellow, EMC/s stays green, and the green frame accent no longer flashes.
The Energy Link screen and its network/data formats are unchanged.
See CHANGELOG-0.8.14.md for details.
