# ProjectEX Alpha 0.8.20 — Link input processing and learned-item catalogue

## Implemented
- All three Link tiers process their input inventory on the server once per second, only while their owner is online and has a ProjectE knowledge capability.
- EMC values are resolved through ProjectE's `IEMCProxy` using `ItemInfo.fromStack` followed by `getPersistentInfo`, preserving the persistent item identity and rejecting volatile data that cannot safely be learned.
- Input stacks with no positive EMC value, or whose item data cannot be represented by ProjectE persistent `ItemInfo`, remain untouched; they are never voided by the processing loop.
- Personal Link: consumes EMC-valued input stacks, learns their exact `ItemInfo` for the owner, converts `unit EMC × stack count` to a `BigInteger` buffer, then transfers that buffer to the owner's ProjectE EMC balance. This uses a persistent staging buffer and avoids `long` overflow.
- Refined and Compressed Refined Links: consume EMC-valued input stacks and add their `ItemInfo` to the owner's ProjectE knowledge. Newly learned items are synced to the owner. These inputs do not create EMC.
- If the owner is offline or the knowledge capability is unavailable, input items and buffered EMC remain safe.
- Added persistent `LastImportedEMC` and `TotalImportedEMC` counters for Personal Link.
- Refined and Compressed Refined output grids are now read-only catalogues derived from the owner's learned ProjectE items. They show up to 9 / 54 EMC-valued learned items and refresh while the menu is open.
- Clicking a Refined/Compressed catalogue item buys up to a stack (right-click buys one); shift-click buys up to a stack into the player's inventory. EMC is charged only for the exact amount successfully inserted. Purchases are restricted to the Link owner.

## Reference behavior
The original ProjectEX 1.12.2 release notes describe Personal EMC Link as importing items into the player's personal EMC storage; Refined and Compressed Refined Links learn items received through hoppers/input; and Link output items can be clicked to receive them. They also document a fix preventing non-EMC items from being voided. This iteration follows those documented behaviors. See the original ProjectEX 1.2.0.40 source release notes on CurseForge.

## Still pending
- Personal Link's single output/target slot behavior (including condenser target selection and `PlayerAttemptCondenserSetEvent`) is not implemented yet; it is intentionally left inert rather than guessed.
- Refined/Compressed catalogue pagination beyond the first 9 / 54 learned items.
- JEI drag-and-drop target selection and complete parity for every click mode (including original Ctrl-click semantics).
- Live display of the Personal Link's imported EMC counters in the GUI.
- Full multiplayer / hopper / restart / large-EMC in-game test matrix.

## Build and test
Run `gradlew.bat build` using JDK 21, NeoForge 21.1.266 and ProjectE 1.21.1 PE1.1.0.

Suggested checks:
1. Personal Link: insert an EMC-valued stack. It should be consumed, the owner should learn the item, and `unit EMC × count` should be credited to the owner's EMC balance.
2. Insert an item with no EMC value. It must remain in the input slot.
3. Log out the owner before processing. Input items must remain in the Link until the owner returns.
4. Refined / Compressed: insert an EMC-valued item. It should be consumed and appear in the owner's Transmutation knowledge / Link output catalogue, without increasing EMC.
5. Click a learned item in the Refined catalogue. The owner should receive it and be charged precisely its EMC cost; right-click should buy one; shift-click should buy into inventory.
6. Confirm inventory and learned knowledge persist after server restart.

Build status: source-level checks and ZIP integrity only. No successful Gradle build or Minecraft in-game test is claimed in this environment; Gradle 8.12.1 cannot be downloaded here because `services.gradle.org` DNS resolution fails.
