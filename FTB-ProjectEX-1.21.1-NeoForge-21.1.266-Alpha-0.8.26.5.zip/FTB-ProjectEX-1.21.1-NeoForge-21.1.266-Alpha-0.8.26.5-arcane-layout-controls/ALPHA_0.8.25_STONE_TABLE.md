# ProjectEX Alpha 0.8.25 — Stone Table vertical slice

## Implemented
- Replaced the generic Stone Table block with a directional, thin-profile interactive block that opens a dedicated menu.
- Added a dedicated Stone Table MenuType and client screen.
- Added the original 36 player inventory/hotbar slots at the 1.12.2 screen positions.
- Restored the original 176x217 GUI texture and radial eight-item knowledge catalogue layout.
- Added search by item display name/registry ID and `@namespace`, paging arrows and mouse-wheel paging.
- Added server-authoritative Learn, Unlearn, Burn, Shift-Burn (transfer EMC to/from ProjectE EMC-holder items), Buy One and Buy Stack actions.
- Restored the original shift-click import behavior: shift-clicking an EMC-valued player-inventory stack burns the whole stack into personal EMC and learns the item, but leaves it untouched if the net EMC would be zero.
- Uses ProjectE `IKnowledgeProvider`, `IEMCProxy`, persistent `ItemInfo`, `PlayerAttemptLearnEvent`, ProjectE covalence-loss setting and EMC sync.
- Normalizes learned catalogue entries through ProjectE persistent item info to avoid duplicate NBT variants, while calculating burn yield from the actual held stack as in the legacy implementation.
- Catalogue knowledge-change polling is throttled to once every 10 client ticks to avoid hashing the full knowledge set every frame.
- All purchases are validated server-side against known items and available EMC. Bulk purchases only charge the quantity actually inserted into the player inventory.
- Burn uses BigDecimal/BigInteger and refuses to consume items if covalence loss yields zero EMC.

## Remaining
- The original optional Stone Table whitelist/config screen is not ported yet; current acceptance rule matches the legacy default (whitelist disabled): only items with positive EMC are accepted.
- JEI text synchronization, JEI plugin integration and the legacy custom learn/burn button sprite states are pending.
- Item-specific NBT whitelist behavior relies on ProjectE `IEMCProxy.getPersistentInfo`; require in-game validation against modded items.
- Multiplayer, server dedicated, exploit and persistence testing remain pending.

## Validation
- Static source/JSON/ZIP checks only.
- Gradle build not yet verified in this environment. Run `gradlew.bat build` with JDK 21 and NeoForge 21.1.266 before installing.
