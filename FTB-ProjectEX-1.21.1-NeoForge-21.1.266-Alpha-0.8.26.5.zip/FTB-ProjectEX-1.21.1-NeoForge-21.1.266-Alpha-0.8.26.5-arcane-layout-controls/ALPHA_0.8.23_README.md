# FTB ProjectEX Alpha 0.8.23 — Link item safety and Arcane crafting hardening

## Additional changes over 0.8.22
- Breaking/removing a Personal, Refined or Compressed Refined Link now drops its physical input inventory and configured output-filter items instead of deleting them with the block entity.
- If the Link has a pending EMC buffer and the owner's ProjectE knowledge provider is available, that buffer is credited to the owner before removal; online owners are synchronized.
- Existing tier-specific menus, output-filter purchasing, automation `IItemHandler`, EMC processing and Arcane 3x3 crafting are preserved.

## Behavior already present in 0.8.22
- Personal Link imports EMC-valued inputs to the owner's ProjectE EMC balance.
- Refined/Compressed Refined learn EMC-valued inputs and use configured output filters as EMC-funded virtual stock for GUI/automation extraction.
- Arcane Tablet attaches 9 input slots plus a result slot to ProjectE's existing transmutation menu, uses vanilla 3x3 crafting recipes, handles recipe remainders and can re-buy learned ingredients from EMC.

## Known limitations
- JEI recipe transfer into the Arcane Tablet is not implemented.
- The Arcane grid's protection against shift-click is in the normal UI path; a server-side packet interception/mixin for forged container-click packets is not included.
- Refined/Compressed behavior and automation require in-game verification with hoppers/storage networks and a dedicated server.
- If ProjectE cannot provide the owner's UUID-backed knowledge provider at the exact moment a Link is broken, any still-buffered EMC cannot be credited by this block-removal hook; input and filter items are still dropped. Normally the buffer is transferred on the normal processing tick.

## Validation
Source-level structural checks and ZIP integrity can be run locally. A full build and runtime test are not claimed. Use JDK 21 and run `gradlew.bat compileJava` followed by `gradlew.bat build`.
