# 0.8.26-alpha

- Added dedicated ProjectEX Alchemy Table block entity, menu and screen.
- Ported 12 legacy recipe chains (31 transformations).
- Added EMC-aware processing, an eight-times-recipe-cost EMC buffer, progress synchronization and NBT persistence.
- Added EMC storage and item handler capability registration.
- Added table removal drops and legacy flame particles.
- Replaced the previous Alchemy Table block alias with the ProjectEX machine implementation.

Validation caveat: source and resource checks completed; Gradle compile was blocked before compilation because the wrapper could not resolve `services.gradle.org` to download Gradle 8.12.1.
