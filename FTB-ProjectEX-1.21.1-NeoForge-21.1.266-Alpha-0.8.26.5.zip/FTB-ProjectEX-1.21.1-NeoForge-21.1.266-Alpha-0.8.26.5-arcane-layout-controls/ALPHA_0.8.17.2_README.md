# ProjectEX Alpha 0.8.17.2 — LinkScreen compile fix

## Fix
- `LinkScreen` now stores the `Inventory` passed to its constructor in an explicit `playerInventory` field.
- The inventory title renderer reads that field, rather than referencing an undeclared `inventory` or relying on a nonexistent inherited field.
- Personal Link menu layout, 18 input slots, extraction-only output slot, player inventory, and quick-move behavior are unchanged.

## Build
Run `gradlew.bat compileJava` or `gradlew.bat build` with JDK 21.
The source archive has been checked for the corrected field declaration and assignment. A complete Gradle build has not been verified in this environment.
