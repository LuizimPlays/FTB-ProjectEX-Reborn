# Alpha 0.8.26.5 — Arcane Tablet layout & controls

## First Arcane Tablet pass
- Restored the original 1.12.2 composition: the 176x217 tablet panel is centred, while the 76x89 crafting extension is rendered to its left.
- Restored search field geometry (8,7,160x11) and page arrows at (7,20) / (151,20).
- Corrected the ProjectE 16-slot output ring transform to X -70 and Y +20, rather than the former X -40-only offset that left output icons detached from the circle.
- Moved the 3x3 grid and result slot to the original legacy menu coordinates (-59,17) and (-23,75).
- Added server-validated Arcane actions: rotate clockwise/counter-clockwise, balance, spread, clear, learn, unlearn, burn, and Shift+burn EMC-holder transfer.
- Added tooltips over the legacy icon hit areas.
- Preserved ProjectE TransmutationContainer for search, EMC accounting, knowledge, pagination and output purchasing.

## Important behavior
- Actions are processed server-side only after checking that the open container is a TransmutationContainer opened from the Arcane Tablet hand.
- Shift-click from/to the Arcane crafting grid remains blocked to prevent ProjectE's inherited transmutation quick-move path from selling ingredients accidentally.
- Crafting ingredients are returned to the player when closing the tablet; overflow is dropped rather than deleted.

## Still pending
- Port of the original search-mode configuration (auto-focus / JEI filter synchronization).
- JEI recipe transfer into the 3x3 grid.
- A fully independent Arcane container, to remove the remaining dependency on the ProjectE GUI/container and reflective field access.
- Server-side handling for malicious vanilla click packets targeting the attached crafting slots.

## Validation
- Source-level checks and ZIP integrity only. A full Gradle compile and an in-game test remain necessary; no claim of bug-free behavior is made without them.
