# ProjectEX Alpha 0.8.21 — Classic Link UI alignment and Arcane atlas restoration

## Implemented
- Restored the bundled original GUI textures for Personal Link, Refined Link, and Compressed Refined Link instead of drawing generic dark panels.
- Repositioned Personal Link to its original 6x3 input arrangement (18 input slots) and single target/output position.
- Repositioned Refined Link to the original single input plus centered 3x3 output catalogue layout.
- Repositioned Compressed Refined Link to the original single input plus 9x6 output catalogue layout.
- Matched player inventory and hotbar coordinates to the legacy textures; Compressed Refined uses the taller 176x244 panel.
- Removed overlapping manually drawn labels; the legacy texture's arrows and slot banks provide the input/output affordances.
- Restored the full 256px-wide Arcane Tablet texture atlas. The prior 176px screen width cropped the whole right-side 3x3 crafting panel artwork.

## Explicitly not complete yet
- The Arcane Tablet's right-side 3x3 grid is currently restored visually from the original atlas, but is not yet backed by a server-side crafting inventory or recipe result. Making it interactive requires changing the current delegated ProjectE TransmutationContainer integration into a ProjectEX container that preserves ProjectE transmutation and adds server-authoritative crafting, recipe remainders, EMC purchases, and JEI transfer. This was not faked in this pass.
- Personal Link's single target/output slot is still a placeholder; its target/lock behavior and automated output crafting remain pending.
- Refined catalog pagination beyond the first 9 / 54 entries remains pending.

## Reference notes
- The project already contains the original 256x256 GUI texture atlases for the three Link tiers and Arcane Tablet. Their active GUI bounds are 176x166 (Personal/Refined), 176x244 (Compressed), and 256x217 (Arcane).
- ProjectEX 1.12.2 release notes document Arcane crafting-table buttons, recipe-grid refill after crafting, and JEI recipe transfer; these behaviors remain required for full parity.

## Validation
- Verified slot-coordinate counts and dimensions against the supplied texture atlases.
- ZIP/source integrity checks are separate from a Gradle build.
- Full build/in-game tests have not been run in this environment; run `gradlew.bat build` with JDK 21 and NeoForge 21.1.266 before installing.
