# ProjectEX Alpha 0.8.26.3 — Alchemy / Stone Table visual corrections

## Changes
- `AlchemyTableBlock` explicitly reports `RenderShape.MODEL` so its baked Blockbench geometry is rendered in-world alongside the existing block entity ticking and flame particles.
- Stone Table inventory label moved from x=8 to x=28, avoiding overlap with the classic Learn button at x=8..24.
- The Alchemy Table GUI remains the original two-slot layout. The 1.12.2 `GuiAlchemyTable` draws the same 176x166 `alchemy_table.png` texture and two slots; its neutral grey background is the original artwork, not a missing GUI texture.
- No changes to recipe costs, EMC processing, inventory persistence, or the Stone Table action protocol.

## Validation
- Source and JSON syntax checks are included in the local validation notes.
- Full Minecraft client rendering must still be tested in-game. If the Alchemy model remains invisible after this patch, collect `latest.log` after resource reload; a missing-model/texture bakery warning will identify the remaining resource issue.
- Build validation requires `gradlew.bat build` on the user's JDK 21/NeoForge setup.
