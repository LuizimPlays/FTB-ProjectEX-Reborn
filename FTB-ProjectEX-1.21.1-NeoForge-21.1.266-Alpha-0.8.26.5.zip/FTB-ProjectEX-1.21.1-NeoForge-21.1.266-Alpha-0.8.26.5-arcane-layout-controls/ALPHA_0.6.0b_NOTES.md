# Alpha 0.6.0b - Arcane Tablet menu fix

- Replaced the generic Arcane Tablet item with an item that opens ProjectE's existing transmutation menu.
- Uses ProjectE's `TransmutationContainer`, with hand and selected hotbar slot sent to the menu factory.
- No changes to Energy Link, Power Flower, EMC storage, or HUD behavior.

Build locally with `gradlew.bat build`. Compilation was not verified in this environment.
