# FTB ProjectEX — Alpha 0.8.15

## Link foundation port (Minecraft 1.21.1 / NeoForge 21.1.266)

This increment replaces the three placeholder Link blocks with real block entities and server-side storage foundations.

### Implemented in this increment
- Personal Link uses 18 input slots and 1 output slot.
- Refined Link uses 1 input slot and 9 output slots.
- Compressed Refined Link uses 1 input slot and 54 output slots.
- Inventory contents are serialized with the 1.21.1 registry-aware ItemStackHandler API.
- The placing player is stored as the owner (first owner is retained).
- EMC is buffered as BigInteger and delivered to the owner once per second while that owner is online.
- Buffered EMC remains stored while the owner is offline.
- EMC storage and item-handler block capabilities are registered for the Link block entity.

### Not yet complete
- The original Link container/screen has not yet been ported; right-click currently displays diagnostic information.
- Refined/Compressed Refined knowledge-learning and item conversion behavior is not yet implemented.
- Output-slot interaction rules and full automation compatibility still require parity testing against the 1.12.2 implementation.
- No successful Gradle compile is claimed for this environment: the Gradle 8.12.1 distribution was not cached and network access to services.gradle.org was unavailable.

The original 1.12.2 JAR remains the behavioral reference. Do not treat this increment as feature-complete Link parity.
