# ProjectEX Alpha 0.8.13 — Classic EMC HUD refinement

## Changes
- The HUD keeps the compact classic ProjectE layout: EMC balance on the first line and live EMC/s on the second.
- While the player crouches (SHIFT), the exact balance replaces the abbreviated balance on that same first line; no extra line is added below the HUD.
- The exact balance uses Brazilian thousands separators (example: `1.432.821.432.320`).
- The `EMC:` label remains white, the normal compact balance remains yellow, and positive EMC gains briefly flash green.
- The panel width adapts to the displayed balance while retaining the compact translucent blue styling.

## Preserved
- EMC rate sampling and positive/negative rate colors.
- Energy Link transfer behavior, recipes, machines, and existing gameplay systems from Alpha 0.8.12.

## Build and test
Run `gradlew.bat build` using JDK 21 and NeoForge 21.1.266. In game, verify that the balance is compact normally and changes to a grouped full integer on the same top line while crouching.

## Energy Collector / Antimatter Relay compatibility pass
- Collectors and ProjectEX relays now provide subtle client-side energy/transfer particles.
- Restored the classic interaction where an adjacent ProjectE MK1 Relay receives twenty
  bonus pulses per Collector production cycle; ProjectEX Antimatter Relays continue to
  receive one tier-defined bonus pulse.
- All EMC mutation remains server-side and uses ProjectE's EMC capability.
- Restored classic relay routing: ProjectEX relays avoid feeding themselves/other ProjectEX relays and ProjectE MK1, while higher-tier ProjectE relay acceptors remain valid destinations.
