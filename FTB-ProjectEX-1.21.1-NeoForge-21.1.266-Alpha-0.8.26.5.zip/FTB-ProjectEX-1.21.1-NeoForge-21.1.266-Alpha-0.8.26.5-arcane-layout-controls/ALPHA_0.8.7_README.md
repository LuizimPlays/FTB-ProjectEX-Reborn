# ProjectEX Alpha 0.8.7 — Machine telemetry pass

Base: Alpha 0.8.6 (Minecraft 1.21.1 / NeoForge 21.1.266).

## Changes
- Collector persists the EMC distributed during its most recent production cycle and its lifetime total distributed.
- Relay persists the EMC transferred during its most recent transfer cycle and its lifetime total transferred.
- Collector and Relay right-click diagnostics display these operational counters alongside stored EMC and configured rates.
- Relay's one-second diagnostic cycle advances even while its buffer is empty, so the last-cycle transfer display returns to zero instead of showing stale activity.
- Existing production values, transfer rules, recipe data, Energy Link behavior, and Arcane Tablet code are unchanged.
- Old worlds remain compatible: missing telemetry NBT fields default to zero.

## Validation
- Source changes reviewed for matching getters, NBT load/save, and diagnostic call sites.
- JSON recipe resources are unchanged.
- A Gradle/Minecraft build and in-game test could not be run in this environment because no Gradle executable/distribution is installed. Run `gradlew.bat build` with JDK 21 before installing this alpha.
