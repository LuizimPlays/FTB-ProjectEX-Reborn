# FTB ProjectEX 1.21.1 — NeoForge 21.1.266

## Alpha 0.5.5 — Energy Link Screen blur correction

Fixes the Energy Link status screen rendering order and suppresses the default screen background renderer that applies vanilla blur. The custom panel is rendered after the vanilla screen pass, keeping its text and panel crisp. EMC HUD and machine logic are unchanged.

Build with JDK 21:
```powershell
.\gradlew.bat build
```

Compilation has not been validated in this environment. Test in a separate instance/world.


## Alpha 0.8.1

See `ALPHA_0.8.1_README.md` for the Arcane Tablet visual integration and test checklist.


## Alpha 0.8.25 update — Stone Table

Alpha 0.8.25 introduces the first dedicated Stone Table port: a directional block, dedicated menu/screen, original 176x217 GUI layout, search by item/namespace, paging, Learn, Unlearn, Burn, Shift-Burn for ProjectE EMC-holder items, Buy One and Buy Stack. Server actions validate the active menu, distance, knowledge and EMC balance. Optional whitelist config and JEI synchronization remain pending. Build and in-game validation are required before treating the feature as stable.


## Validation status — Alpha 0.8.25

The Stone Table module is source-implemented, not build- or game-verified in this environment. The Gradle wrapper requires Gradle 8.12.1, which could not be fetched because `services.gradle.org` was unreachable. Run `gradlew.bat build` locally before installing. The optional whitelist setting and JEI search-field synchronization remain unported.
