# FTB ProjectEX 1.21.1 — Alpha 0.7.0 (Arcane Tablet UI migration foundation)

## Recovered from ProjectEX 1.2.0.40 (Minecraft 1.12.2)
- `assets/projectex/textures/gui/arcane_tablet.png` (256x256 original GUI atlas)
- Legacy GUI class names inspected: `GuiArcaneTablet`, `ContainerArcaneTablet`, `ButtonLearnItem`, `ButtonUnlearnItem`, `ButtonCreateItem`, `InventoryCraftingArcaneTablet`, and `ItemArcaneTablet`.

## Implemented in this development snapshot
- Dedicated `ArcaneTabletMenu` registration.
- Dedicated `ArcaneTabletScreen` registration on the client mod event bus.
- Arcane Tablet item now opens the ProjectEX menu rather than ProjectE's stock TransmutationContainer.
- Recovered 1.12.2 GUI texture is used as the screen background.
- Player inventory and hotbar slots are attached to the menu.
- Search text field is present as a UI foundation.

## Not implemented yet (do not consider feature-complete)
- Learned-item knowledge list and radial item rendering.
- EMC balance display and affordability checks in the tablet.
- Learn/unlearn/create actions and server payload validation.
- Crafting 3x3 recipe execution and item transfer/balance/spread actions.
- Search filtering, pagination, JEI integration, and tooltips for radial entries.

The original 1.12.2 GUI and container classes are obfuscated/compiled Java bytecode in the supplied JAR. Their behavior still needs to be ported and adapted to ProjectE 1.21.1 APIs. This snapshot is a first UI/menu migration foundation, not a completed Arcane Transmutation implementation.

## Build verification
Not verified in this environment: Gradle 8.12.1 distribution download failed because `services.gradle.org` was unreachable. Run `gradlew.bat build` locally before installing the JAR.
