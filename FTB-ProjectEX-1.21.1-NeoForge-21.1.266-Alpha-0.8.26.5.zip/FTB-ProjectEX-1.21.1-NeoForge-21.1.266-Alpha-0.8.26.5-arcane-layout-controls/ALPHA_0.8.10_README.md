# ProjectEX Alpha 0.8.10 — Classic HUD & Responsive Energy Link

## Changes
- Restored the compact classic ProjectE-style EMC HUD presentation: translucent blue panel, yellow EMC balance, green EMC/s rate, and a slim green accent.
- Preserved crouch/SHIFT display of the complete EMC balance without abbreviations.
- Reworked the Energy Link status screen to scale as a single centered panel to fit different GUI resolutions.
- Added width-aware clipping/ellipsis for owner names and metric values to prevent text escaping its cards.
- Added a subtle animated cyan accent while retaining the existing periodic server refresh.

## Build
Run `gradlew.bat build` on Windows from the project directory.

Build verification was not possible in this environment because the Gradle wrapper distribution could not be downloaded (network/DNS unavailable). Please compile locally before installing.
