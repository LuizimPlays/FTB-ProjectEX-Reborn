# Alpha 0.8.25 — build e roteiro de teste local

## Requisitos
- JDK 21 (o projeto usa Java toolchain 21)
- Minecraft 1.21.1
- NeoForge 21.1.266
- ProjectE 1.21.1 PE1.1.0 (o JAR de desenvolvimento está em `libs/` e é usado como dependência de compilação; ProjectE também deve estar instalado na instância do jogo)

## Compilar no Windows
Abra PowerShell na raiz da pasta do projeto e execute:

```powershell
.\gradlew.bat clean build
```

Se o build terminar com `BUILD SUCCESSFUL`, o JAR do mod ficará em:

```text
build\libs\ftb-projectex-0.8.25-alpha.jar
```

Copie esse JAR e o ProjectE compatível para a pasta `mods` de uma instância separada de Minecraft 1.21.1 + NeoForge 21.1.266. Não substitua sua instância principal até concluir os testes.

## Roteiro Stone Table
1. Coloque a Stone Table e confirme que ela abre a interface com clique vazio e segurando um item.
2. Verifique busca por nome, por ID (`minecraft:iron_ingot`) e por namespace (`@minecraft`).
3. Aprenda um item com EMC usando-o na mão e acionando Learn; confirme que o item continua na mão.
4. Desaprenda o mesmo item e confirme que ele some do catálogo após a sincronização.
5. Queime uma pilha de itens com EMC; confira que a pilha é consumida e o EMC aumenta segundo a covalence loss do ProjectE.
6. Tente queimar item sem EMC e confirme que não é consumido.
7. Compre um item conhecido com clique normal e uma pilha com Shift; confirme que o saldo cai somente pela quantidade realmente inserida.
8. Teste cursor ocupado com outro item e inventário cheio.
9. Com Shift sobre Burn, teste retirar EMC de uma EMC-holder item e depositar EMC nela.
10. Salve/recarregue o mundo e repita; verifique conhecimento e EMC persistidos pelo ProjectE.
11. Repita em servidor dedicado com dois jogadores; confirme que cada jogador altera apenas seu próprio conhecimento/EMC.

## Limitações conhecidas desta etapa
- A whitelist opcional da Stone Table da 1.12.2 ainda não foi portada. O comportamento padrão antigo (whitelist desativada) é usado: itens com valor EMC positivo podem ser aprendidos/queimados.
- Sincronização automática da busca com JEI ainda não está implementada.
- Esta entrega é o primeiro módulo da migração; não representa paridade total do ProjectEX 1.12.2.

## Status de validação
O ZIP foi verificado e os JSONs foram validados estruturalmente. Não foi possível concluir o Gradle build neste ambiente porque o Gradle Wrapper 8.12.1 não está em cache e `services.gradle.org` não resolveu via DNS. Portanto, o código ainda precisa passar pelo build e pelos testes acima antes de ser considerado pronto para uma instância de jogo.
