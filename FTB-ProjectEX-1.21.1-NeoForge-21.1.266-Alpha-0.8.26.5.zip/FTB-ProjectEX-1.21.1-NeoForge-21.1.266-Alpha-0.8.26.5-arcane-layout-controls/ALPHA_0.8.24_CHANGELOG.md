# Alpha 0.8.24 — Link behavior and Arcane API correction

### Link system
- Added a server-authoritative output-filter configuration path that copies the cursor item and learns its EMC info for the Link owner.
- Corrected ghost-filter clear semantics to prevent duplicate item returns/drops.
- Automation insertion is limited to EMC-valued input slots; output positions are extraction-only.
- Input inventory validation rejects items without positive ProjectE EMC.
- Shift-click imports from player inventory or Link input slots now mirror the legacy behavior: learn the EMC item, auto-fill the first free output filter, add covalence-adjusted EMC to the buffer, and consume the source stack only on the server.
- Personal Link import applies ProjectE's configured covalence-loss multiplier using decimal arithmetic and truncation to avoid floating-point overflow for large batches.
- Output count preview can show the amount currently affordable by the Link owner.

### Arcane Tablet
- Replaced direct calls to the protected `TransmutationContainer.addSlot` with a single reflective compatibility bridge that invokes the standard menu slot-registration path.
- Corrected the result slot's `onTake` override to the `void` return type used by Minecraft 1.21.1.
- Existing recipe matching, remainders, ingredient refill, and close-time ingredient return behavior were retained; these paths still require runtime testing.

### Legacy source inventory
- Preserved the user's 88 Java source files from the original ProjectEX 1.12.2 ZIP under `legacy_reference/1.12.2`.
- Confirmed that the supplied ZIP has Java sources only; no original binary assets/resources were included.

### Validation
- Static source sanity and ZIP integrity checks performed.
- Gradle compile attempt could not run because Gradle 8.12.1 must be downloaded and `services.gradle.org` could not be resolved (`UnknownHostException`).
- No successful compile or in-game testing is claimed.

- Safety pass: zero-value Personal Link imports are rejected without consuming the source stack.
- Link GUI click actions now enforce the owner UUID at the menu boundary.
- Restored sink-only EMC capability semantics for Links; external extraction cannot drain pending owner delivery.
