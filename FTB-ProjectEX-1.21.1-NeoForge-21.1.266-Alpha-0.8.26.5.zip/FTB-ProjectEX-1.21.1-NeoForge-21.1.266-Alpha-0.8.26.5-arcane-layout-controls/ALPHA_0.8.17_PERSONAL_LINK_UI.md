# ProjectEX Alpha 0.8.17 — Personal Link UI foundation

## Implemented in this iteration
- Added a dedicated `LinkMenu` for the Personal Link.
- Added 18 input slots and one extraction-only output slot.
- Added player inventory and hotbar slots.
- Added shift-click routing from player inventory to Link inputs and back.
- Opening the Personal Link now opens its GUI; Refined and Compressed Refined Links retain their previous status-message behavior.
- Kept the existing owner binding, persistent inventory, EMC buffer, and one-second owner delivery logic.
- Added a clean dark-blue GUI frame and English block title.

## Not implemented yet
- EMC value lookup and item processing.
- Learning item EMC into the owner's ProjectE knowledge.
- Output production and live buffer synchronization in the GUI.
- Dedicated Refined / Compressed Refined Link layouts and their processing rules.

These are intentionally left for the next iteration rather than approximated with guessed ProjectE API calls.

## Validation
`./gradlew compileJava --no-daemon` was attempted. It did not reach compilation because this environment could not resolve `services.gradle.org` to download Gradle 8.12.1 (`UnknownHostException`). The source changes are therefore not build-verified and have not been tested in Minecraft.
