package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.ProjectEX;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class ProjectEXBlocks {
    public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(Registries.BLOCK, ProjectEX.MOD_ID);
    public static final Supplier<Block> ENERGY_LINK = REGISTRY.register("energy_link", () -> new EnergyLinkBlock());
    public static final Supplier<Block> PERSONAL_LINK = REGISTRY.register("personal_link", () -> new LinkBlock(LinkBlock.Tier.PERSONAL));
    public static final Supplier<Block> REFINED_LINK = REGISTRY.register("refined_link", () -> new LinkBlock(LinkBlock.Tier.REFINED));
    public static final Supplier<Block> COMPRESSED_REFINED_LINK = REGISTRY.register("compressed_refined_link", () -> new LinkBlock(LinkBlock.Tier.COMPRESSED_REFINED));
    public static final Map<Matter, Supplier<Block>> COLLECTOR = registerMatterBlocks("_collector", CollectorBlock::new);
    public static final Map<Matter, Supplier<Block>> RELAY = registerMatterBlocks("_relay", RelayBlock::new);
    public static final Map<Matter, Supplier<Block>> POWER_FLOWER = registerMatterBlocks("_power_flower", PowerFlowerBlock::new);
    public static final Supplier<Block> STONE_TABLE = REGISTRY.register("stone_table", StoneTableBlock::new);
    public static final Supplier<Block> ALCHEMY_TABLE = REGISTRY.register("alchemy_table", (Supplier<Block>) () -> new AlchemyTableBlock());

    private ProjectEXBlocks() {}
    private static Supplier<Block> block(String id) {
        return REGISTRY.register(id, () -> new Block(BlockBehaviour.Properties.of()));
    }
    private static Map<Matter, Supplier<Block>> registerMatterBlocks(String suffix, java.util.function.Function<Matter, Block> factory) {
        Map<Matter, Supplier<Block>> map = new LinkedHashMap<>();
        for (Matter matter : Matter.VALUES) map.put(matter, REGISTRY.register(matter.name + suffix, () -> factory.apply(matter)));
        return Map.copyOf(map);
    }
}
