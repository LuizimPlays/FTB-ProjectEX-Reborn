package dev.latvian.mods.projectex;

import dev.latvian.mods.projectex.crafting.ArcaneCraftingSupport;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import moze_intel.projecte.gameObjs.container.TransmutationContainer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerContainerEvent;

/** Installs and cleans up the server-side Arcane Tablet crafting slots. */
@EventBusSubscriber(modid = ProjectEX.MOD_ID)
public final class ArcaneCraftingEvents {
    private ArcaneCraftingEvents() {}

    @SubscribeEvent
    public static void onContainerOpen(PlayerContainerEvent.Open event) {
        if (!(event.getContainer() instanceof TransmutationContainer menu)) return;
        Player player = event.getEntity();
        if (player.level().isClientSide) return;
        if (menu.hand == null || !player.getItemInHand(menu.hand).is(ProjectEXItems.ARCANE_TABLET.get())) return;
        ArcaneCraftingSupport.attach(menu, player);
    }

    @SubscribeEvent
    public static void onContainerClose(PlayerContainerEvent.Close event) {
        if (event.getContainer() instanceof TransmutationContainer menu) {
            ArcaneCraftingSupport.close(menu, event.getEntity());
        }
    }
}
