package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.block.PowerFlowerBlock;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.math.BigInteger;
import java.util.UUID;

public final class PowerFlowerBlockEntity extends BlockEntity {
    private UUID owner = Util.NIL_UUID;
    private String ownerName = "";
    private int tickCounter;
    private BigInteger storedEmc = BigInteger.ZERO;
    public PowerFlowerBlockEntity(BlockPos pos, BlockState state) { super(ProjectEXBlockEntities.POWER_FLOWER.get(), pos, state); }
    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : Util.NIL_UUID;
        ownerName = tag.getString("OwnerName");
        tickCounter = tag.getInt("Tick");
        try { storedEmc = new BigInteger(tag.contains("StoredEMC") ? tag.getString("StoredEMC") : "0"); } catch (NumberFormatException ignored) { storedEmc = BigInteger.ZERO; }
    }
    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putUUID("Owner", owner);
        tag.putString("OwnerName", ownerName);
        tag.putInt("Tick", tickCounter);
        tag.putString("StoredEMC", storedEmc.toString());
    }
    public void setOwner(UUID uuid, String name) { owner = uuid; ownerName = name; setChanged(); }
    public BigInteger getStoredEmc() { return storedEmc; }
    public BigInteger getGeneratedPerSecond() {
        return getBlockState().getBlock() instanceof PowerFlowerBlock block ? BigInteger.valueOf(block.matter.getPowerFlowerOutput()) : BigInteger.ZERO;
    }
    public UUID getOwnerUUID() { return owner; }
    public String getOwnerName() { return ownerName.isBlank() ? "Desconhecido" : ownerName; }

    public void tickServer() {
        if (level == null || level.isClientSide || !(getBlockState().getBlock() instanceof PowerFlowerBlock block)) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;
        BigInteger generated = BigInteger.valueOf(block.matter.getPowerFlowerOutput());
        ServerPlayer player = level.getServer() == null ? null : level.getServer().getPlayerList().getPlayer(owner);
        IKnowledgeProvider knowledge = player == null ? null : player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge != null) {
            knowledge.setEmc(knowledge.getEmc().add(generated).add(storedEmc));
            storedEmc = BigInteger.ZERO;
            knowledge.syncEmc(player);
        } else {
            storedEmc = storedEmc.add(generated);
        }
        setChanged();
    }
}
