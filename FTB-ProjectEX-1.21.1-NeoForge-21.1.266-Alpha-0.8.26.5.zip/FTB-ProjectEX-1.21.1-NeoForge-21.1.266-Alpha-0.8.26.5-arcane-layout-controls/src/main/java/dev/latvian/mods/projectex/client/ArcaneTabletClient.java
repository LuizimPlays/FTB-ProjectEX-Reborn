package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import dev.latvian.mods.projectex.crafting.ArcaneCraftingSupport;
import moze_intel.projecte.gameObjs.gui.GUITransmutation;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/**
 * Replaces only the screen instance opened by the ProjectEX Arcane Tablet.
 * ProjectE's normal Transmutation Tablet and Transmutation Table remain untouched.
 */
@EventBusSubscriber(modid = ProjectEX.MOD_ID, value = Dist.CLIENT)
public final class ArcaneTabletClient {
    private ArcaneTabletClient() {
    }

    @SubscribeEvent
    public static void onScreenOpening(ScreenEvent.Opening event) {
        if (!(event.getScreen() instanceof GUITransmutation original)) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || original.getMenu().hand == null) {
            return;
        }

        if (minecraft.player.getItemInHand(original.getMenu().hand).is(ProjectEXItems.ARCANE_TABLET.get())) {
            ArcaneCraftingSupport.attach(original.getMenu(), minecraft.player);
            event.setNewScreen(new ArcaneTabletTransmutationScreen(
                    original.getMenu(), minecraft.player.getInventory(), original.getTitle()));
        }
    }
}
