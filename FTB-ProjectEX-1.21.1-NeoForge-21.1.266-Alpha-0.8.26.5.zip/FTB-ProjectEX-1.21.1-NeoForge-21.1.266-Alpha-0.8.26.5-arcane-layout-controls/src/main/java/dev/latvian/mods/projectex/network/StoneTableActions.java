package dev.latvian.mods.projectex.network;

import dev.latvian.mods.projectex.menu.StoneTableMenu;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage.EmcAction;
import moze_intel.projecte.api.event.PlayerAttemptLearnEvent;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.config.ProjectEConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.NeoForge;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

/** Server-side implementation of the original Stone Table learn/unlearn/burn/buy actions. */
public final class StoneTableActions {
    public static final int BURN = 1;
    public static final int BURN_ALT = 4;
    public static final int TAKE_STACK = 2;
    public static final int TAKE_ONE = 3;
    public static final int LEARN = 5;
    public static final int UNLEARN = 6;

    private StoneTableActions() {}

    public static void handle(ServerPlayer player, StoneTableActionPayload payload) {
        if (!(player.containerMenu instanceof StoneTableMenu menu)) return;
        if (menu.containerId != payload.menuId() || !menu.stillValid(player)) return;
        IKnowledgeProvider knowledge = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge == null) return;

        switch (payload.action()) {
            case BURN -> burnCarried(player, knowledge);
            case BURN_ALT -> {
                if (!transferHeldEmc(player, knowledge)) burnCarried(player, knowledge);
            }
            case LEARN -> learnCarried(player, knowledge);
            case UNLEARN -> unlearnCarried(player, knowledge);
            case TAKE_ONE -> buy(player, knowledge, payload.target(), false);
            case TAKE_STACK -> buy(player, knowledge, payload.target(), true);
            default -> { }
        }
        menu.broadcastChanges();
    }

    private static ItemInfo persistent(ItemStack stack) {
        if (stack.isEmpty()) return null;
        ItemInfo source = ItemInfo.fromStack(stack.copyWithCount(1));
        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(source);
        return info == null ? source : info;
    }

    private static boolean learn(ServerPlayer player, IKnowledgeProvider knowledge, ItemStack stack) {
        if (stack.isEmpty()) return false;
        ItemInfo sourceStackInfo = ItemInfo.fromStack(stack.copyWithCount(1));
        // The legacy GUI validates EMC on the held stack first, then learns its normalized output form.
        if (!IEMCProxy.INSTANCE.hasValue(stack)) return false;
        ItemInfo source = persistent(stack);
        if (source == null) return false;
        if (knowledge.hasKnowledge(source)) return true;
        PlayerAttemptLearnEvent event = new PlayerAttemptLearnEvent(player, sourceStackInfo, source);
        NeoForge.EVENT_BUS.post(event);
        if (event.isCanceled()) return false;
        ItemInfo learned = event.getReducedInfo() == null ? source : event.getReducedInfo();
        if (!knowledge.addKnowledge(learned)) return knowledge.hasKnowledge(learned);
        knowledge.syncKnowledgeChange(player, learned, true);
        return true;
    }

    private static void learnCarried(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty()) return;
        learn(player, knowledge, carried);
    }

    private static void unlearnCarried(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty()) return;
        ItemInfo info = persistent(carried);
        if (info != null && knowledge.removeKnowledge(info)) {
            knowledge.syncKnowledgeChange(player, info, false);
        }
    }


    /** Shift-clicking the burn control transfers EMC to/from ProjectE EMC-holder items, matching the old table. */
    private static boolean transferHeldEmc(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty()) return false;
        IItemEmcHolder holder = PECapabilities.EMC_HOLDER_ITEM_CAPABILITY.getCapability(carried, null);
        if (holder == null) return false;

        long stored = Math.max(0L, holder.getStoredEmc(carried));
        if (stored > 0L) {
            long extracted = holder.extractEmc(carried, stored, EmcAction.EXECUTE);
            if (extracted > 0L) {
                knowledge.setEmc(knowledge.getEmc().add(BigInteger.valueOf(extracted)));
                knowledge.syncEmc(player);
                player.containerMenu.setCarried(carried);
            }
            return true;
        }

        long needed = Math.max(0L, holder.getNeededEmc(carried));
        if (needed <= 0L || knowledge.getEmc().signum() <= 0) return true;
        BigInteger transferable = knowledge.getEmc().min(BigInteger.valueOf(needed));
        if (transferable.signum() <= 0) return true;
        long inserted = holder.insertEmc(carried, transferable.min(BigInteger.valueOf(Long.MAX_VALUE)).longValue(), EmcAction.EXECUTE);
        if (inserted > 0L) {
            knowledge.setEmc(knowledge.getEmc().subtract(BigInteger.valueOf(inserted)));
            knowledge.syncEmc(player);
            player.containerMenu.setCarried(carried);
        }
        return true;
    }

    private static void burnCarried(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (!carried.isEmpty() && burnStack(player, knowledge, carried)) {
            player.containerMenu.setCarried(ItemStack.EMPTY);
        }
    }

    /**
     * Converts an entire stack into personal EMC using the server's ProjectE covalence-loss setting.
     * The caller removes the source stack only after this method succeeds.
     */
    public static boolean burnStack(ServerPlayer player, IKnowledgeProvider knowledge, ItemStack stack) {
        if (stack.isEmpty()) return false;
        ItemInfo info = persistent(stack);
        // Match the 1.12.2 Stone Table: burn value is taken from the exact stack,
        // while learned knowledge is normalized through ProjectE's persistent info.
        if (info == null || !IEMCProxy.INSTANCE.hasValue(stack)) return false;
        long unitValue = IEMCProxy.INSTANCE.getValue(stack);
        if (unitValue <= 0L) return false;

        double loss = ProjectEConfig.server.difficulty.covalenceLoss.get();
        if (!Double.isFinite(loss) || loss <= 0D) return false;
        BigInteger gained;
        try {
            gained = BigDecimal.valueOf(unitValue)
                    .multiply(BigDecimal.valueOf(stack.getCount()))
                    .multiply(BigDecimal.valueOf(loss))
                    .setScale(0, RoundingMode.DOWN)
                    .toBigIntegerExact();
        } catch (ArithmeticException exception) {
            return false;
        }
        // Do not destroy an item batch when configured covalence loss yields zero EMC.
        if (gained.signum() <= 0 || !learn(player, knowledge, stack)) return false;

        knowledge.setEmc(knowledge.getEmc().add(gained));
        knowledge.syncEmc(player);
        return true;
    }

    private static void buy(ServerPlayer player, IKnowledgeProvider knowledge, ItemStack requested, boolean stack) {
        if (requested.isEmpty()) return;
        ItemInfo info = persistent(requested);
        if (info == null || !knowledge.hasKnowledge(info)) return;
        long unitValue = IEMCProxy.INSTANCE.getValue(info);
        if (unitValue <= 0L) return;

        ItemStack prototype = info.createStack();
        if (prototype.isEmpty()) return;
        prototype.setCount(1);
        BigInteger unitCost = BigInteger.valueOf(unitValue);
        BigInteger balance = knowledge.getEmc();
        if (balance.compareTo(unitCost) < 0) return;

        if (!stack) {
            ItemStack carried = player.containerMenu.getCarried();
            if (!carried.isEmpty() && (!ItemStack.isSameItemSameComponents(carried, prototype)
                    || carried.getCount() >= carried.getMaxStackSize())) return;
            knowledge.setEmc(balance.subtract(unitCost));
            if (carried.isEmpty()) player.containerMenu.setCarried(prototype);
            else carried.grow(1);
            knowledge.syncEmc(player);
            return;
        }

        BigInteger affordable = balance.divide(unitCost);
        int requestedCount = affordable.min(BigInteger.valueOf(prototype.getMaxStackSize())).intValue();
        if (requestedCount <= 0) return;
        ItemStack toGive = prototype.copyWithCount(requestedCount);
        player.getInventory().add(toGive);
        int inserted = requestedCount - toGive.getCount();
        if (inserted <= 0) return;
        knowledge.setEmc(balance.subtract(unitCost.multiply(BigInteger.valueOf(inserted))));
        knowledge.syncEmc(player);
    }
}
