package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.block.LinkBlock;
import dev.latvian.mods.projectex.menu.LinkMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Classic ProjectEX Link screens; each output slot is a persistent product filter. */
public final class LinkScreen extends AbstractContainerScreen<LinkMenu> {
    private static final ResourceLocation PERSONAL_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/personal_link.png");
    private static final ResourceLocation REFINED_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/refined_link.png");
    private static final ResourceLocation COMPRESSED_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/compressed_refined_link.png");

    private final Inventory playerInventory;

    public LinkScreen(LinkMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        playerInventory = inventory;
        imageWidth = menu.getScreenWidth();
        imageHeight = menu.getScreenHeight();
        titleLabelX = 8;
        titleLabelY = 5;
        inventoryLabelX = 8;
        inventoryLabelY = menu.getInventoryTop() - 11;
    }

    @Override protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        ResourceLocation texture = switch (menu.getLink().getTier()) {
            case PERSONAL -> PERSONAL_TEXTURE;
            case REFINED -> REFINED_TEXTURE;
            case COMPRESSED_REFINED -> COMPRESSED_TEXTURE;
        };
        graphics.blit(texture, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);
    }

    @Override protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, titleLabelX, titleLabelY, 0xFF404040, false);
        graphics.drawString(font, playerInventory.getDisplayName(), inventoryLabelX, inventoryLabelY, 0xFF404040, false);
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);

        // The legacy Links render their configured product with the amount
        // currently affordable from the owner's EMC. Our inventory slot keeps
        // the one-item ghost filter visible; this overlay renders the live count.
        for (int output = 0; output < menu.getOutputSlotCount(); output++) {
            int menuSlot = menu.getInputSlotCount() + output;
            Slot slot = menu.slots.get(menuSlot);
            if (!slot.hasItem()) continue;
            ItemStack available = menu.getLink().getAvailableOutput(output);
            int x = leftPos + slot.x;
            int y = topPos + slot.y;
            if (!available.isEmpty()) {
                graphics.renderItemDecorations(font, available, x, y);
            } else {
                graphics.fill(x + 8, y + 8, x + 18, y + 18, 0x99000000);
                graphics.drawString(font, Component.literal("0"), x + 10, y + 9, 0xFFB7C0C8, true);
            }
        }

        renderTooltip(graphics, mouseX, mouseY);
    }
}
