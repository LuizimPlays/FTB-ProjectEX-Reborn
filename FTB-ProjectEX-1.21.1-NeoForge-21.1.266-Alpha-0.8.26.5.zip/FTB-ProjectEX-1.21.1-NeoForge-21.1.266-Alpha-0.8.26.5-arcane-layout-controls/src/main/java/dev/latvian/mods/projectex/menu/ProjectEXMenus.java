package dev.latvian.mods.projectex.menu;

import dev.latvian.mods.projectex.ProjectEX;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

public final class ProjectEXMenus {
    public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, ProjectEX.MOD_ID);
    public static final Supplier<MenuType<ArcaneTabletMenu>> ARCANE_TABLET =
            REGISTRY.register("arcane_tablet", () -> IMenuTypeExtension.create((id, inv, data) -> new ArcaneTabletMenu(id, inv)));
    public static final Supplier<MenuType<LinkMenu>> LINK =
            REGISTRY.register("link", () -> IMenuTypeExtension.create((id, inv, data) -> {
                var pos = data.readBlockPos();
                if (inv.player.level().getBlockEntity(pos) instanceof dev.latvian.mods.projectex.block.entity.LinkBlockEntity link)
                    return new LinkMenu(id, inv, link);
                throw new IllegalStateException("Missing ProjectEX Link block entity at " + pos);
            }));
    public static final Supplier<MenuType<StoneTableMenu>> STONE_TABLE =
            REGISTRY.register("stone_table", () -> IMenuTypeExtension.create((id, inv, data) ->
                    new StoneTableMenu(id, inv, data.readBlockPos())));
    public static final Supplier<MenuType<AlchemyTableMenu>> ALCHEMY_TABLE =
            REGISTRY.register("alchemy_table", () -> IMenuTypeExtension.create((id, inv, data) -> {
                var pos = data.readBlockPos();
                if (inv.player.level().getBlockEntity(pos) instanceof dev.latvian.mods.projectex.block.entity.AlchemyTableBlockEntity table)
                    return AlchemyTableMenu.client(id, inv, table);
                throw new IllegalStateException("Missing ProjectEX Alchemy Table block entity at " + pos);
            }));
    private ProjectEXMenus() {}
}
