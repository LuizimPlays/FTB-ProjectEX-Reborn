package dev.latvian.mods.projectex;

/** Original ProjectEX matter tiers and production/transfer values from the legacy source. */
public enum Matter {
    BASIC("basic", "Basic", false, 4L, 1L, 64L),
    DARK("dark", "Dark", false, 12L, 3L, 192L),
    RED("red", "Red", false, 40L, 10L, 640L),
    MAGENTA("magenta", "Magenta", true, 160L, 40L, 2560L),
    PINK("pink", "Pink", true, 640L, 150L, 10240L),
    PURPLE("purple", "Purple", true, 2560L, 750L, 40960L),
    VIOLET("violet", "Violet", true, 10240L, 3750L, 163840L),
    BLUE("blue", "Blue", true, 40960L, 15000L, 655360L),
    CYAN("cyan", "Cyan", true, 163840L, 60000L, 2621440L),
    GREEN("green", "Green", true, 655360L, 240000L, 10485760L),
    LIME("lime", "Lime", true, 2621440L, 960000L, 41943040L),
    YELLOW("yellow", "Yellow", true, 10485760L, 3840000L, 167772160L),
    ORANGE("orange", "Orange", true, 41943040L, 15360000L, 671088640L),
    WHITE("white", "White", true, 167772160L, 61440000L, 2684354560L),
    FADING("fading", "Fading", true, 671088640L, 245760000L, 10737418240L),
    FINAL("final", "The Final", false, 1000000000000L, 1000000000000L, Long.MAX_VALUE);

    public static final Matter[] VALUES = values();
    public final String name;
    public final String displayName;
    public final boolean hasMatterItem;
    public final long collectorOutput;
    public final long relayBonus;
    public final long relayTransfer;

    Matter(String name, String displayName, boolean hasMatterItem, long collectorOutput, long relayBonus, long relayTransfer) {
        this.name = name;
        this.displayName = displayName;
        this.hasMatterItem = hasMatterItem;
        this.collectorOutput = collectorOutput;
        this.relayBonus = relayBonus;
        this.relayTransfer = relayTransfer;
    }

    public String getMK() { return "[MK" + (ordinal() + 1) + "]"; }
    public long getPowerFlowerOutput() { return collectorOutput * 18L + relayBonus * 30L; }
}
