package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ProjectEXBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, ProjectEX.MOD_ID);
    public static final Supplier<BlockEntityType<LinkBlockEntity>> LINK = REGISTRY.register("link", () -> BlockEntityType.Builder.of(LinkBlockEntity::new, ProjectEXBlocks.PERSONAL_LINK.get(), ProjectEXBlocks.REFINED_LINK.get(), ProjectEXBlocks.COMPRESSED_REFINED_LINK.get()).build(null));
    public static final Supplier<BlockEntityType<EnergyLinkBlockEntity>> ENERGY_LINK = REGISTRY.register("energy_link", () -> BlockEntityType.Builder.of(EnergyLinkBlockEntity::new, ProjectEXBlocks.ENERGY_LINK.get()).build(null));
    public static final Supplier<BlockEntityType<CollectorBlockEntity>> COLLECTOR = REGISTRY.register("collector", () -> BlockEntityType.Builder.of(CollectorBlockEntity::new, blocks(ProjectEXBlocks.COLLECTOR)).build(null));
    public static final Supplier<BlockEntityType<RelayBlockEntity>> RELAY = REGISTRY.register("relay", () -> BlockEntityType.Builder.of(RelayBlockEntity::new, blocks(ProjectEXBlocks.RELAY)).build(null));
    public static final Supplier<BlockEntityType<PowerFlowerBlockEntity>> POWER_FLOWER = REGISTRY.register("power_flower", () -> BlockEntityType.Builder.of(PowerFlowerBlockEntity::new, blocks(ProjectEXBlocks.POWER_FLOWER)).build(null));
    public static final Supplier<BlockEntityType<AlchemyTableBlockEntity>> ALCHEMY_TABLE = REGISTRY.register("alchemy_table", () -> BlockEntityType.Builder.of(AlchemyTableBlockEntity::new, ProjectEXBlocks.ALCHEMY_TABLE.get()).build(null));
    private ProjectEXBlockEntities() {}
    private static Block[] blocks(java.util.Map<dev.latvian.mods.projectex.Matter, Supplier<Block>> map) {
        return map.values().stream().map(Supplier::get).toArray(Block[]::new);
    }
}
