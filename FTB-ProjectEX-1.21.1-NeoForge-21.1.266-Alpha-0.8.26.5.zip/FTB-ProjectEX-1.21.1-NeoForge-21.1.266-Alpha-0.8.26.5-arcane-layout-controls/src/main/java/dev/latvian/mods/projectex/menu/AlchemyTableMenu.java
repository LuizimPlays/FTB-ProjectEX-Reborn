package dev.latvian.mods.projectex.menu;

import dev.latvian.mods.projectex.block.entity.AlchemyTableBlockEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.SlotItemHandler;

/** Two-slot Alchemy Table menu with synchronized EMC and progress indicators. */
public final class AlchemyTableMenu extends AbstractContainerMenu {
    private final AlchemyTableBlockEntity table;
    private final ContainerLevelAccess access;
    private final ContainerData data;

    public AlchemyTableMenu(int id, Inventory inventory, AlchemyTableBlockEntity table) {
        this(id, inventory, table, new SimpleContainerData(2));
    }

    private AlchemyTableMenu(int id, Inventory inventory, AlchemyTableBlockEntity table, ContainerData data) {
        super(ProjectEXMenus.ALCHEMY_TABLE.get(), id);
        this.table = table;
        this.access = ContainerLevelAccess.create(table.getLevel(), table.getBlockPos());
        this.data = data;

        addSlot(new SlotItemHandler(table.getItems(), 0, 44, 35));
        addSlot(new SlotItemHandler(table.getItems(), 1, 116, 35) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 142));
        }

        addDataSlots(data);
    }

    public static AlchemyTableMenu client(int id, Inventory inventory, AlchemyTableBlockEntity table) {
        return new AlchemyTableMenu(id, inventory, table, new SimpleContainerData(2));
    }

    public AlchemyTableBlockEntity getTable() { return table; }
    public int getProgressScaled() { return data.get(0); }
    public int getEmcScaled() { return data.get(1); }

    @Override public void broadcastChanges() {
        if (table.getLevel() != null && !table.getLevel().isClientSide) {
            data.set(0, table.getScaledProgress());
            data.set(1, table.getScaledEmc());
        }
        super.broadcastChanges();
    }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) return ItemStack.EMPTY;
        Slot source = slots.get(index);
        if (!source.hasItem()) return ItemStack.EMPTY;

        ItemStack stack = source.getItem();
        ItemStack original = stack.copy();
        boolean moved;
        if (index < 2) {
            moved = moveItemStackTo(stack, 2, slots.size(), true);
        } else {
            // Shift-click into the machine's input only; output slot is never an insertion target.
            moved = moveItemStackTo(stack, 0, 1, false);
        }
        if (!moved) return ItemStack.EMPTY;
        if (stack.isEmpty()) source.set(ItemStack.EMPTY); else source.setChanged();
        source.onTake(player, stack);
        return original;
    }

    @Override public boolean stillValid(Player player) {
        return stillValid(access, player, table.getBlockState().getBlock());
    }
}
