package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.block.entity.LinkBlockEntity;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class LinkBlock extends Block implements EntityBlock {
    public enum Tier {
        PERSONAL(18, 1), REFINED(1, 9), COMPRESSED_REFINED(1, 54);
        public final int inputSlots, outputSlots;
        Tier(int inputSlots, int outputSlots) { this.inputSlots = inputSlots; this.outputSlots = outputSlots; }
    }
    private final Tier tier;
    public LinkBlock(Tier tier) {
        super(BlockBehaviour.Properties.of().strength(5.0F).sound(SoundType.STONE));
        this.tier = tier;
    }
    public Tier getTier() { return tier; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LinkBlockEntity(pos, state);
    }
    @Override @SuppressWarnings("unchecked") public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ProjectEXBlockEntities.LINK.get()) return null;
        return (lvl, pos, blockState, entity) -> { if (entity instanceof LinkBlockEntity link) link.tickServer(); };
    }
    @Override public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof LinkBlockEntity link) link.setOwner(player);
    }
    @Override public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (state.getBlock() != newState.getBlock() && !level.isClientSide) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof LinkBlockEntity link) {
                for (ItemStack stack : link.removeContentsForDrop()) {
                    Block.popResource(level, pos, stack);
                }
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer
                && level.getBlockEntity(pos) instanceof LinkBlockEntity link) {
            if (link.getOwnerId().equals(net.minecraft.Util.NIL_UUID)) {
                link.setOwner(player);
            }
            if (!player.getUUID().equals(link.getOwnerId())) {
                player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                        "Este EMC Link pertence a " + link.getOwnerName() + "."), true);
                return InteractionResult.FAIL;
            }
            // All tiers use one server-authoritative menu with tier-specific slots.
            serverPlayer.openMenu(link, buffer -> buffer.writeBlockPos(pos));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
