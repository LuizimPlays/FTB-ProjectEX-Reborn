package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.menu.StoneTableMenu;
import dev.latvian.mods.projectex.network.StoneTableActionPayload;
import dev.latvian.mods.projectex.network.StoneTableActions;
import dev.latvian.mods.projectex.util.EmcFormat;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Classic ProjectEX Stone Table: searchable knowledge catalogue, paging, learn/burn and create actions. */
public final class StoneTableScreen extends AbstractContainerScreen<StoneTableMenu> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/stone_table.png");
    private static final int[][] ITEM_POSITIONS = {
            {80, 28}, {110, 38}, {50, 38}, {120, 68}, {40, 68},
            {110, 98}, {50, 98}, {80, 108}
    };

    private final List<ItemStack> filteredItems = new ArrayList<>();
    private final List<ItemStack> visibleItems = new ArrayList<>(ITEM_POSITIONS.length);
    private EditBox search;
    private int page;
    private String lastSearch = "";
    private int knownCount;
    private int knownHash;
    private int knowledgePollTicks;

    public StoneTableScreen(StoneTableMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 217;
        // The classic learn button occupies x=8..24 at y=115; start the label after it.
        inventoryLabelX = 28;
        inventoryLabelY = 125;
    }

    @Override protected void init() {
        super.init();
        search = new EditBox(font, leftPos + 8, topPos + 7, 160, 11, Component.translatable("gui.projectex.stone_table.search"));
        search.setBordered(false);
        search.setTextColor(0xFFE7E7E7);
        search.setTextColorUneditable(0xFF999999);
        search.setMaxLength(35);
        search.setValue(lastSearch);
        addRenderableWidget(search);

        refreshCatalogue();
    }

    @Override protected void containerTick() {
        super.containerTick();
        String currentSearch = search == null ? "" : search.getValue();
        if (!currentSearch.equals(lastSearch)) {
            lastSearch = currentSearch;
            page = 0;
            refreshCatalogue();
        }
        if (++knowledgePollTicks >= 10) {
            knowledgePollTicks = 0;
            IKnowledgeProvider knowledge = getClientKnowledge();
            int count = knowledge == null ? 0 : knowledge.getKnowledge().size();
            int hash = knowledge == null ? 0 : knowledge.getKnowledge().hashCode();
            if (count != knownCount || hash != knownHash) refreshCatalogue();
        }
    }

    private IKnowledgeProvider getClientKnowledge() {
        Minecraft minecraft = Minecraft.getInstance();
        return minecraft.player == null ? null : minecraft.player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
    }

    private void refreshCatalogue() {
        filteredItems.clear();
        visibleItems.clear();
        IKnowledgeProvider knowledge = getClientKnowledge();
        if (knowledge == null) {
            knownCount = 0;
            knownHash = 0;
            return;
        }
        knownCount = knowledge.getKnowledge().size();
        knownHash = knowledge.getKnowledge().hashCode();
        String query = lastSearch.trim().toLowerCase(Locale.ROOT);
        boolean modSearch = query.startsWith("@");
        if (modSearch) query = query.substring(1);

        List<ItemInfo> infos = new ArrayList<>(knowledge.getKnowledge());
        infos.sort(Comparator.comparing(info -> BuiltInRegistries.ITEM.getKey(info.getItem().value()).toString()));
        Set<ItemInfo> displayedInfo = new HashSet<>();
        for (ItemInfo learnedInfo : infos) {
            // ProjectEX 1.12.2 displays the normalized output form, not each NBT variant.
            ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(learnedInfo);
            if (info == null) info = learnedInfo;
            if (!displayedInfo.add(info)) continue;
            ItemStack stack = info.createStack();
            if (stack.isEmpty() || IEMCProxy.INSTANCE.getValue(info) <= 0L) continue;
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(stack.getItem());
            if (!query.isEmpty()) {
                String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                String id = key == null ? "" : key.toString().toLowerCase(Locale.ROOT);
                if (modSearch ? key == null || !key.getNamespace().startsWith(query) : !name.contains(query) && !id.contains(query)) continue;
            }
            filteredItems.add(stack.copyWithCount(1));
        }
        int maxPage = Math.max(0, (filteredItems.size() - 1) / ITEM_POSITIONS.length);
        page = Math.min(page, maxPage);
        for (int i = 0; i < ITEM_POSITIONS.length; i++) {
            int index = page * ITEM_POSITIONS.length + i;
            visibleItems.add(index < filteredItems.size() ? filteredItems.get(index) : ItemStack.EMPTY);
        }
    }

    private void changePage(int delta) {
        int pages = Math.max(1, (filteredItems.size() + ITEM_POSITIONS.length - 1) / ITEM_POSITIONS.length);
        page = Math.max(0, Math.min(pages - 1, page + delta));
        refreshVisibleItems();
    }

    private void refreshVisibleItems() {
        visibleItems.clear();
        for (int i = 0; i < ITEM_POSITIONS.length; i++) {
            int index = page * ITEM_POSITIONS.length + i;
            visibleItems.add(index < filteredItems.size() ? filteredItems.get(index) : ItemStack.EMPTY);
        }
    }

    @Override protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);
    }

    @Override protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        // The original Stone Table has no title text inside the search field.
        graphics.drawString(font, Component.translatable("container.inventory"), inventoryLabelX, inventoryLabelY, 0xFF404040, false);
        IKnowledgeProvider knowledge = getClientKnowledge();
        BigInteger balance = knowledge == null ? BigInteger.ZERO : knowledge.getEmc();
        String text = EmcFormat.format(balance) + " EMC";
        graphics.drawString(font, text, (imageWidth - font.width(text)) / 2, -10, 0xFFB5B5B5, false);
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);

        for (int i = 0; i < ITEM_POSITIONS.length; i++) {
            ItemStack stack = i < visibleItems.size() ? visibleItems.get(i) : ItemStack.EMPTY;
            if (stack.isEmpty()) continue;
            int x = leftPos + ITEM_POSITIONS[i][0];
            int y = topPos + ITEM_POSITIONS[i][1];
            graphics.renderItem(stack, x, y);
            graphics.renderItemDecorations(font, stack, x, y);
            if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
                long value = IEMCProxy.INSTANCE.getValue(stack);
                List<Component> tooltip = new ArrayList<>();
                tooltip.add(stack.getHoverName());
                tooltip.add(Component.translatable("gui.projectex.stone_table.emc", EmcFormat.format(value)));
                IKnowledgeProvider knowledge = getClientKnowledge();
                BigInteger balance = knowledge == null ? BigInteger.ZERO : knowledge.getEmc();
                BigInteger affordable = value <= 0 ? BigInteger.ZERO : balance.divide(BigInteger.valueOf(value));
                tooltip.add(Component.translatable("gui.projectex.stone_table.available", EmcFormat.format(affordable)));
                graphics.renderTooltip(font, tooltip, java.util.Optional.empty(), mouseX, mouseY);
            }
        }

        drawHoverAction(graphics, 80, 68, mouseX, mouseY);
        drawHoverAction(graphics, 8, 115, mouseX, mouseY);
        drawHoverAction(graphics, 152, 115, mouseX, mouseY);

        // The legacy GUI atlas stores the arrow sprites outside the 176x217 visible panel.
        if (insideAbsolute(mouseX, mouseY, 7, 20, 18, 18))
            graphics.blit(TEXTURE, leftPos + 7, topPos + 20, 196, 0, 18, 18, 256, 256);
        if (insideAbsolute(mouseX, mouseY, 151, 20, 18, 18))
            graphics.blit(TEXTURE, leftPos + 151, topPos + 20, 215, 0, 18, 18, 256, 256);

        // Context help for the three legacy actions.
        if (insideAbsolute(mouseX, mouseY, 80, 68, 16, 16)) {
            List<Component> help = List.of(Component.translatable("gui.projectex.stone_table.burn"),
                    Component.literal("Shift: transfer EMC to/from EMC items"));
            graphics.renderTooltip(font, help, java.util.Optional.empty(), mouseX, mouseY);
        } else if (insideAbsolute(mouseX, mouseY, 8, 115, 16, 16)) {
            graphics.renderTooltip(font, Component.translatable("gui.projectex.stone_table.learn"), mouseX, mouseY);
        } else if (insideAbsolute(mouseX, mouseY, 152, 115, 16, 16)) {
            graphics.renderTooltip(font, Component.translatable("gui.projectex.stone_table.unlearn"), mouseX, mouseY);
        }
        renderTooltip(graphics, mouseX, mouseY);
    }

    private void drawHoverAction(GuiGraphics graphics, int x, int y, int mouseX, int mouseY) {
        if (insideAbsolute(mouseX, mouseY, x, y, 16, 16)) {
            int sx = leftPos + x, sy = topPos + y;
            graphics.fill(sx, sy, sx + 16, sy + 16, 0x55FFFFFF);
            graphics.renderOutline(sx, sy, 16, 16, 0xFFB6C9D8);
        }
    }

    private boolean insideAbsolute(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= leftPos + x && mouseX < leftPos + x + width
                && mouseY >= topPos + y && mouseY < topPos + y + height;
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (int) mouseX - leftPos;
        int y = (int) mouseY - topPos;
        if (search != null && x >= 8 && x < 168 && y >= 7 && y < 18) {
            if (button == 1) {
                search.setValue("");
                search.setFocused(true);
                return true;
            }
            if (!menu.getCarried().isEmpty()) {
                search.setValue(menu.getCarried().getHoverName().getString());
                search.setFocused(true);
                return true;
            }
        }
        if (x >= 7 && x < 25 && y >= 20 && y < 38) {
            if (button == 0) changePage(-1);
            return true;
        }
        if (x >= 151 && x < 169 && y >= 20 && y < 38) {
            if (button == 0) changePage(1);
            return true;
        }
        if (super.mouseClicked(mouseX, mouseY, button)) return true;

        for (int i = 0; i < ITEM_POSITIONS.length; i++) {
            int ix = ITEM_POSITIONS[i][0], iy = ITEM_POSITIONS[i][1];
            if (x >= ix && x < ix + 16 && y >= iy && y < iy + 16) {
                if (i < visibleItems.size() && !visibleItems.get(i).isEmpty()) {
                    int action = net.minecraft.client.gui.screens.Screen.hasShiftDown()
                            ? StoneTableActions.TAKE_STACK : StoneTableActions.TAKE_ONE;
                    sendAction(action, visibleItems.get(i));
                }
                return true;
            }
        }

        if (inside(x, y, 80, 68)) {
            sendAction(net.minecraft.client.gui.screens.Screen.hasShiftDown() ? StoneTableActions.BURN_ALT : StoneTableActions.BURN, ItemStack.EMPTY);
            return true;
        }
        if (inside(x, y, 8, 115)) { sendAction(StoneTableActions.LEARN, ItemStack.EMPTY); return true; }
        if (inside(x, y, 152, 115)) { sendAction(StoneTableActions.UNLEARN, ItemStack.EMPTY); return true; }
        return false;
    }

    private static boolean inside(int mouseX, int mouseY, int x, int y) {
        return mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16;
    }

    private void sendAction(int action, ItemStack target) {
        PacketDistributor.sendToServer(new StoneTableActionPayload(menu.containerId, action,
                target.isEmpty() ? ItemStack.EMPTY : target.copyWithCount(1)));
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (deltaY != 0) {
            changePage(deltaY < 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, deltaX, deltaY);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (search != null && search.isFocused() && search.keyPressed(keyCode, scanCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean charTyped(char codePoint, int modifiers) {
        if (search != null && search.isFocused() && search.charTyped(codePoint, modifiers)) return true;
        return super.charTyped(codePoint, modifiers);
    }

}
