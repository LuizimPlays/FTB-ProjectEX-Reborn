package dev.latvian.mods.projectex.block.entity;

import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import java.math.BigInteger;
import java.util.UUID;

/** Owner-bound EMC buffer. Adjacent EMC providers can insert into it; it forwards its buffer to its owner once per second. */
public final class EnergyLinkBlockEntity extends BlockEntity implements IEmcStorage {
    private UUID owner = Util.NIL_UUID;
    private String ownerName = "";
    private static final int TRANSFER_INTERVAL_TICKS = 5; // Four transfers per second for responsive EMC delivery.
    private int tickCounter;
    private BigInteger storedEmc = BigInteger.ZERO;
    private BigInteger totalTransferred = BigInteger.ZERO;
    private BigInteger lastTransferred = BigInteger.ZERO;
    public EnergyLinkBlockEntity(BlockPos pos, BlockState state) { super(ProjectEXBlockEntities.ENERGY_LINK.get(), pos, state); }
    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : Util.NIL_UUID;
        ownerName = tag.getString("OwnerName"); tickCounter = tag.getInt("Tick");
        try { storedEmc = new BigInteger(tag.getString("StoredEMC")); if (storedEmc.signum() < 0) storedEmc = BigInteger.ZERO; }
        catch (RuntimeException ignored) { storedEmc = BigInteger.ZERO; }
        try { totalTransferred = new BigInteger(tag.getString("TotalTransferred")); if (totalTransferred.signum() < 0) totalTransferred = BigInteger.ZERO; }
        catch (RuntimeException ignored) { totalTransferred = BigInteger.ZERO; }
        try { lastTransferred = new BigInteger(tag.getString("LastTransferred")); if (lastTransferred.signum() < 0) lastTransferred = BigInteger.ZERO; }
        catch (RuntimeException ignored) { lastTransferred = BigInteger.ZERO; }
    }
    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries); tag.putUUID("Owner", owner); tag.putString("OwnerName", ownerName); tag.putInt("Tick", tickCounter); tag.putString("StoredEMC", storedEmc.toString()); tag.putString("TotalTransferred", totalTransferred.toString()); tag.putString("LastTransferred", lastTransferred.toString());
    }
    public void setOwner(net.minecraft.world.entity.player.Player player) { owner = player.getUUID(); ownerName = player.getGameProfile().getName(); setChanged(); }
    public String getOwnerName() { return ownerName.isBlank() ? "Nenhum" : ownerName; }
    public BigInteger getStoredBigEmc() { return storedEmc; }
    public BigInteger getTotalTransferred() { return totalTransferred; }
    public BigInteger getLastTransferred() { return lastTransferred; }
    public UUID getOwnerId() { return owner; }
    public void tickServer() {
        if (level == null || level.isClientSide) return;
        if (storedEmc.signum() <= 0 || owner.equals(Util.NIL_UUID)) {
            tickCounter = 0;
            return;
        }
        if (++tickCounter < TRANSFER_INTERVAL_TICKS) return;
        tickCounter = 0;

        ServerPlayer player = level.getServer() == null ? null : level.getServer().getPlayerList().getPlayer(owner);
        IKnowledgeProvider knowledge = player == null ? null : player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge == null) return; // Keep the buffer intact while its owner is offline.

        // Transfer the exact buffered amount. BigInteger avoids losing EMC above Long.MAX_VALUE.
        BigInteger transfer = storedEmc;
        if (transfer.signum() > 0) {
            knowledge.setEmc(knowledge.getEmc().add(transfer));
            knowledge.syncEmc(player);
            storedEmc = BigInteger.ZERO;
            lastTransferred = transfer;
            totalTransferred = totalTransferred.add(transfer);
            setChanged();
        }
    }
    @Override public long getStoredEmc() { return storedEmc.min(BigInteger.valueOf(Long.MAX_VALUE)).longValue(); }
    @Override public long getMaximumEmc() { return Long.MAX_VALUE; }
    @Override public long extractEmc(long amount, EmcAction action) {
        if (amount <= 0) return 0; BigInteger requested = BigInteger.valueOf(amount); BigInteger taken = storedEmc.min(requested);
        if (action.execute() && taken.signum() > 0) { storedEmc = storedEmc.subtract(taken); setChanged(); }
        return taken.longValue();
    }
    @Override public long insertEmc(long amount, EmcAction action) {
        if (amount <= 0) return 0;
        if (action.execute()) {
            storedEmc = storedEmc.add(BigInteger.valueOf(amount));
            setChanged();
        }
        return amount;
    }
}
