package dev.latvian.mods.projectex.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Live read-only status for a specific Energy Link. */
public record EnergyLinkStatusPayload(BlockPos pos, String owner, String buffer, String lastTransfer, String totalTransferred, String ownerBalance, boolean ownerOnline) implements CustomPacketPayload {
    public static final Type<EnergyLinkStatusPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("projectex", "energy_link_status"));
    public static final StreamCodec<RegistryFriendlyByteBuf, EnergyLinkStatusPayload> STREAM_CODEC = StreamCodec.of(
            (buf, payload) -> {
                buf.writeBlockPos(payload.pos);
                buf.writeUtf(payload.owner, 256);
                buf.writeUtf(payload.buffer, 128);
                buf.writeUtf(payload.lastTransfer, 128);
                buf.writeUtf(payload.totalTransferred, 128);
                buf.writeUtf(payload.ownerBalance, 128);
                buf.writeBoolean(payload.ownerOnline);
            },
            buf -> new EnergyLinkStatusPayload(buf.readBlockPos(), buf.readUtf(256), buf.readUtf(128), buf.readUtf(128), buf.readUtf(128), buf.readUtf(128), buf.readBoolean())
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
