package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.network.EnergyLinkStatusPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid = "projectex", value = Dist.CLIENT)
public final class EnergyLinkClientNetworking {
    private EnergyLinkClientNetworking() {}
    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("2").playToClient(EnergyLinkStatusPayload.TYPE, EnergyLinkStatusPayload.STREAM_CODEC, (payload, context) ->
                context.enqueueWork(() -> {
                    if (Minecraft.getInstance().screen instanceof EnergyLinkStatusScreen screen && screen.getLinkPos().equals(payload.pos())) {
                        screen.updateData(payload);
                    } else {
                        Minecraft.getInstance().setScreen(new EnergyLinkStatusScreen(payload));
                    }
                }));
    }
}
