package dev.latvian.mods.projectex.emc;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.Star;
import moze_intel.projecte.api.mapper.EMCMapper;
import moze_intel.projecte.api.mapper.IEMCMapper;
import moze_intel.projecte.api.mapper.collector.IMappingCollector;
import moze_intel.projecte.api.nss.NSSItem;
import moze_intel.projecte.api.nss.NormalizedSimpleStack;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ReloadableServerResources;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.Item;

/** Supplies stable EMC values for ProjectEX items so ProjectE can learn and transmute them. */
@EMCMapper
public final class ProjectEXEMCMapper implements IEMCMapper<NormalizedSimpleStack, Long> {
    @EMCMapper.Instance
    public static final ProjectEXEMCMapper INSTANCE = new ProjectEXEMCMapper();

    public ProjectEXEMCMapper() {}

    @Override
    public void addMappings(IMappingCollector<NormalizedSimpleStack, Long> collector,
                            ReloadableServerResources serverResources,
                            RegistryAccess registryAccess,
                            ResourceManager resourceManager) {
        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id == null || !"projectex".equals(id.getNamespace())) continue;
            long value = getValue(id.getPath());
            if (value > 0) collector.setValueBefore(NSSItem.createItem(item), value);
        }
    }

    @Override
    public String getName() { return "ProjectEX item EMC"; }

    @Override
    public String getTranslationKey() { return "projectex.emc.mapper.items"; }

    @Override
    public String getDescription() { return "Assigns EMC values to ProjectEX items for transmutation."; }

    private static long getValue(String path) {
        // Matter items inherit their tier's EMC. Machine blocks scale with the tier's
        // collector output so higher tiers remain progressively more valuable.
        for (Matter matter : Matter.VALUES) {
            String tier = matter.name;
            if (path.equals(tier + "_matter")) return Math.max(1L, matter.collectorOutput * 16L);
            if (path.equals(tier + "_collector") || path.equals(tier + "_compressed_collector"))
                return Math.max(1L, matter.collectorOutput * 64L);
            if (path.equals(tier + "_relay")) return Math.max(1L, safeMultiply(matter.relayTransfer, 8L));
            if (path.equals(tier + "_power_flower")) return Math.max(1L, matter.getPowerFlowerOutput() * 64L);
        }

        if (path.startsWith("magnum_star_")) return starValue(path.substring("magnum_star_".length()), 1_000_000L);
        if (path.startsWith("colossal_star_")) return starValue(path.substring("colossal_star_".length()), 16_000_000L);

        return switch (path) {
            case "final_star_shard" -> 1_000_000_000_000L;
            case "final_star" -> 16_000_000_000_000L;
            case "knowledge_sharing_book" -> 65_536L;
            case "energy_link" -> 16_384L;
            case "personal_link" -> 32_768L;
            case "refined_link" -> 262_144L;
            case "compressed_refined_link" -> 2_097_152L;
            case "stone_table" -> 1_024L;
            case "alchemy_table" -> 4_096L;
            case "arcane_tablet" -> 65_536L;
            default -> 64L;
        };
    }

    private static long safeMultiply(long value, long multiplier) {
        if (value <= 0 || multiplier <= 0) return 1L;
        return value > Long.MAX_VALUE / multiplier ? Long.MAX_VALUE : value * multiplier;
    }

    private static long starValue(String name, long base) {
        for (int i = 0; i < Star.VALUES.length; i++) {
            if (Star.VALUES[i].name.equals(name)) {
                int shift = Math.min(i, 20);
                return base << shift;
            }
        }
        return base;
    }
}
