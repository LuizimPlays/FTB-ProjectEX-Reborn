package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.block.entity.PowerFlowerBlockEntity;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public final class PowerFlowerBlock extends Block implements EntityBlock {
    public final Matter matter;
    public PowerFlowerBlock(Matter matter) {
        super(BlockBehaviour.Properties.of().strength(1.0F).sound(SoundType.STONE).noOcclusion());
        this.matter = matter;
    }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PowerFlowerBlockEntity(pos, state);
    }
    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != ProjectEXBlockEntities.POWER_FLOWER.get() || level.isClientSide) return null;
        return (lvl, pos, blockState, be) -> {
            if (be instanceof PowerFlowerBlockEntity flower) flower.tickServer();
        };
    }
    @Override public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (placer != null && level.getBlockEntity(pos) instanceof PowerFlowerBlockEntity flower) {
            flower.setOwner(placer.getUUID(), placer.getScoreboardName());
        }
    }
    @Override
    public net.minecraft.world.InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, net.minecraft.world.entity.player.Player player, net.minecraft.world.phys.BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof PowerFlowerBlockEntity machine) {
            String storedLine = "§eArmazenado na máquina: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getStoredEmc()) + " EMC";
            String balanceLine = "§6Saldo EMC: §fIndisponível (proprietário offline)";
            if (level.getServer() != null) {
                ServerPlayer ownerPlayer = level.getServer().getPlayerList().getPlayer(machine.getOwnerUUID());
                if (ownerPlayer != null) {
                    IKnowledgeProvider knowledge = ownerPlayer.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
                    if (knowledge != null) {
                        balanceLine = "§6Saldo EMC: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(knowledge.getEmc()) + " EMC";
                    }
                }
            }
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "§dPower Flower " + matter.getMK() + "\n" + storedLine + "\n" + balanceLine + "\n§aProdução: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getGeneratedPerSecond()) + " EMC/s\n§bProprietário: §f" + machine.getOwnerName()), false);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

}
