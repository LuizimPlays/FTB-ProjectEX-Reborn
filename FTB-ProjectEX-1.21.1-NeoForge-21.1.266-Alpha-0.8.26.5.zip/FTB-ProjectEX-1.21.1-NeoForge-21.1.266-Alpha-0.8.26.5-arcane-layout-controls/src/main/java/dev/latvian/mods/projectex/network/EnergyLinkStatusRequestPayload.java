package dev.latvian.mods.projectex.network;


import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client request to refresh an Energy Link screen currently open. */
public record EnergyLinkStatusRequestPayload(BlockPos pos) implements CustomPacketPayload {
    public static final Type<EnergyLinkStatusRequestPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("projectex", "energy_link_status_request"));
    public static final StreamCodec<RegistryFriendlyByteBuf, EnergyLinkStatusRequestPayload> STREAM_CODEC = StreamCodec.of(
            (buf, payload) -> buf.writeBlockPos(payload.pos),
            buf -> new EnergyLinkStatusRequestPayload(buf.readBlockPos())
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
