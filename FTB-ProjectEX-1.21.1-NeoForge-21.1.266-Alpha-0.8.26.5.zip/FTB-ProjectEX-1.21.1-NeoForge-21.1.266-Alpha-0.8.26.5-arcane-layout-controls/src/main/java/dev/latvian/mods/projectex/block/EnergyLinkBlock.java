package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.block.entity.EnergyLinkBlockEntity;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import dev.latvian.mods.projectex.network.EnergyLinkNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class EnergyLinkBlock extends Block implements EntityBlock {
    public EnergyLinkBlock() { super(BlockBehaviour.Properties.of().strength(5.0F).sound(SoundType.STONE)); }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new EnergyLinkBlockEntity(pos, state); }
    @Override @SuppressWarnings("unchecked") public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ProjectEXBlockEntities.ENERGY_LINK.get()) return null;
        return (lvl, pos, blockState, entity) -> { if (entity instanceof EnergyLinkBlockEntity link) link.tickServer(); };
    }
    @Override public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        if (level.getBlockEntity(pos) instanceof EnergyLinkBlockEntity link && placer instanceof Player player) link.setOwner(player);
    }
    @Override public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof EnergyLinkBlockEntity link) {
            EnergyLinkNetwork.sendStatus((net.minecraft.server.level.ServerPlayer) player, link);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
