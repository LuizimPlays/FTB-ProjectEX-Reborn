package dev.latvian.mods.projectex.client;
import dev.latvian.mods.projectex.menu.ArcaneTabletMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
/** Dark Arcane Tablet frame reconstructed from the original ProjectEX 1.12.2 texture atlas. */
public final class ArcaneTabletScreen extends AbstractContainerScreen<ArcaneTabletMenu> {
 private static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath("projectex","textures/gui/arcane_tablet.png");
 private EditBox search;
 public ArcaneTabletScreen(ArcaneTabletMenu menu, Inventory inv, Component title) { super(menu,inv,title); imageWidth=256; imageHeight=256; inventoryLabelX=8; inventoryLabelY=122; titleLabelX=8; titleLabelY=5; }
 @Override protected void init() { super.init(); search=new EditBox(font,leftPos+8,topPos+5,160,12,Component.translatable("gui.projectex.arcane_tablet.search")); search.setBordered(false); search.setTextColor(0xE0E0E0); search.setTextColorUneditable(0x888888); search.setMaxLength(64); addRenderableWidget(search); }
 @Override protected void renderBg(GuiGraphics g,float partial,int mx,int my) { g.blit(TEXTURE,leftPos,topPos,0,0,imageWidth,imageHeight,256,256); }
 @Override protected void renderLabels(GuiGraphics g,int mx,int my) { }
 @Override public void render(GuiGraphics g,int mx,int my,float partial) { renderBackground(g,mx,my,partial); super.render(g,mx,my,partial); renderTooltip(g,mx,my); }
 @Override public boolean keyPressed(int key,int scan,int mods) { if(search!=null && search.isFocused() && search.keyPressed(key,scan,mods)) return true; return super.keyPressed(key,scan,mods); }
 @Override public boolean charTyped(char c,int mods) { if(search!=null && search.isFocused() && search.charTyped(c,mods)) return true; return super.charTyped(c,mods); }
}
