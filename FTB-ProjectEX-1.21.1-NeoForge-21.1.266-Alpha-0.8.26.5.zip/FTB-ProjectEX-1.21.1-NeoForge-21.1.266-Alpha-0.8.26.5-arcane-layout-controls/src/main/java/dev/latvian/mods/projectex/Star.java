package dev.latvian.mods.projectex;

/** Original ProjectEX star tiers. */
public enum Star {
    EIN("ein", "Ein"),
    ZWEI("zwei", "Zwei"),
    DREI("drei", "Drei"),
    VIER("vier", "Vier"),
    SPHERE("sphere", "Sphere"),
    OMEGA("omega", "Omega");

    public static final Star[] VALUES = values();
    public final String name;
    public final String displayName;

    Star(String name, String displayName) {
        this.name = name;
        this.displayName = displayName;
    }
}
