package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.block.entity.AlchemyTableBlockEntity;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.Containers;

/** Original ProjectEX Alchemy Table machine block. */
public final class AlchemyTableBlock extends BaseEntityBlock {
    private static final MapCodec<AlchemyTableBlock> CODEC = BlockBehaviour.simpleCodec(AlchemyTableBlock::new);

    private static final VoxelShape SHAPE = Shapes.or(
            box(0, 9, 0, 16, 13, 16),
            box(2, 0, 2, 4, 9, 4),
            box(2, 0, 12, 4, 9, 14),
            box(12, 0, 12, 14, 9, 14),
            box(12, 0, 2, 14, 9, 4)
    );

    public AlchemyTableBlock() {
        this(BlockBehaviour.Properties.of().strength(2.0F).sound(SoundType.STONE).noOcclusion());
    }

    /** Codec constructor: retain the block properties supplied by the block registry. */
    public AlchemyTableBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    /** Keep the baked Blockbench model visible in-world; particles and the block entity are additive. */
    @Override protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AlchemyTableBlockEntity(pos, state);
    }

    @Override public VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level,
                                         BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                                        Player player, BlockHitResult hit) {
        return open(level, pos, player);
    }

    @Override public ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level,
                                                       BlockPos pos, Player player, InteractionHand hand,
                                                       BlockHitResult hit) {
        open(level, pos, player);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    private InteractionResult open(Level level, BlockPos pos, Player player) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;
        if (level.getBlockEntity(pos) instanceof AlchemyTableBlockEntity table) {
            serverPlayer.openMenu(table, buffer -> buffer.writeBlockPos(pos));
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                             BlockEntityType<T> type) {
        if (level.isClientSide || type != ProjectEXBlockEntities.ALCHEMY_TABLE.get()) return null;
        return (lvl, pos, blockState, blockEntity) -> {
            if (blockEntity instanceof AlchemyTableBlockEntity table) table.tickServer();
        };
    }

    @Override public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        double y = pos.getY() + 1.15D;
        level.addParticle(ParticleTypes.FLAME, pos.getX() + 0.15625D, y, pos.getZ() + 0.15625D, 0, 0, 0);
        level.addParticle(ParticleTypes.FLAME, pos.getX() + 0.84375D, y, pos.getZ() + 0.84375D, 0, 0, 0);
        level.addParticle(ParticleTypes.FLAME, pos.getX() + 0.84375D, y, pos.getZ() + 0.15625D, 0, 0, 0);
        level.addParticle(ParticleTypes.FLAME, pos.getX() + 0.15625D, y, pos.getZ() + 0.84375D, 0, 0, 0);
    }

    @Override public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof AlchemyTableBlockEntity table) {
            for (int slot = 0; slot < table.getItems().getSlots(); slot++) {
                ItemStack stack = table.getItems().getStackInSlot(slot);
                if (!stack.isEmpty()) Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), stack);
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }
}
