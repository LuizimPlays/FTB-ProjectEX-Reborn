package dev.latvian.mods.projectex.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server-authoritative actions for the Arcane Tablet's legacy controls. */
public record ArcaneTabletActionPayload(int menuId, int action) implements CustomPacketPayload {
    public static final Type<ArcaneTabletActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("projectex", "arcane_tablet_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, ArcaneTabletActionPayload> STREAM_CODEC = StreamCodec.of(
            (buf, payload) -> { buf.writeVarInt(payload.menuId()); buf.writeVarInt(payload.action()); },
            buf -> new ArcaneTabletActionPayload(buf.readVarInt(), buf.readVarInt())
    );
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
