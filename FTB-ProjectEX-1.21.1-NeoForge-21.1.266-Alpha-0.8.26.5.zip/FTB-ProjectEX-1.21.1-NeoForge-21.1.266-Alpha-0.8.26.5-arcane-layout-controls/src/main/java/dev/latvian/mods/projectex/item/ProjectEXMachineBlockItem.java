package dev.latvian.mods.projectex.item;
import dev.latvian.mods.projectex.Matter;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

/** Inventory tooltip for ProjectEX machine tiers and EMC rates. */
public final class ProjectEXMachineBlockItem extends BlockItem {
    public enum Machine { COLLECTOR, RELAY, POWER_FLOWER }
    private static final NumberFormat FORMAT = NumberFormat.getIntegerInstance(Locale.US);
    private final Matter matter;
    private final Machine machine;
    public ProjectEXMachineBlockItem(Block block, Item.Properties properties, Matter matter, Machine machine) {
        super(block, properties); this.matter = matter; this.machine = machine;
    }
    @Override public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.literal(matter.getMK()).withStyle(style -> style.withColor(0xAAAAAA)));
        switch (machine) {
            case COLLECTOR -> tooltip.add(Component.literal("Generates: " + fmt(matter.collectorOutput) + " EMC/s").withStyle(style -> style.withColor(0x55FF55)));
            case RELAY -> {
                tooltip.add(Component.literal("Transfer limit: " + fmt(matter.relayTransfer) + " EMC/s").withStyle(style -> style.withColor(0x55FF55)));
                tooltip.add(Component.literal("Collector bonus: +" + fmt(matter.relayBonus) + " EMC/s").withStyle(style -> style.withColor(0x55FFFF)));
            }
            case POWER_FLOWER -> tooltip.add(Component.literal("Generates: " + fmt(matter.getPowerFlowerOutput()) + " EMC/s").withStyle(style -> style.withColor(0x55FF55)));
        }
    }
    private static String fmt(long value) { return FORMAT.format(value); }
}
