package dev.latvian.mods.projectex.item;

import moze_intel.projecte.gameObjs.container.TransmutationContainer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * ProjectEX Arcane Tablet entry point.
 *
 * The actual transmutation implementation is delegated to ProjectE's own
 * TransmutationContainer. This keeps EMC, knowledge, search, paging, learning,
 * unlearning and output-slot validation on the authoritative server-side code.
 */
public final class ArcaneTabletItem extends Item {
    public ArcaneTabletItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack tablet = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            int selectedSlot = player.getInventory().selected;
            serverPlayer.openMenu(new MenuProvider() {
                @Override
                public Component getDisplayName() {
                    return Component.translatable("gui.projectex.arcane_tablet.title");
                }

                @Override
                public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player opener) {
                    // This factory is not used for the ProjectE menu type; the network factory below
                    // constructs TransmutationContainer with the original hand and selected slot.
                    return new TransmutationContainer(containerId, inventory, hand, selectedSlot);
                }
            }, buffer -> {
                buffer.writeBoolean(true);
                buffer.writeEnum(hand);
                buffer.writeByte(selectedSlot);
            });
        }
        return InteractionResultHolder.sidedSuccess(tablet, level.isClientSide);
    }
}
