package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.block.RelayBlock;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.gameObjs.block_entities.RelayMK1BlockEntity;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

public final class RelayBlockEntity extends BlockEntity implements IEmcStorage {
    private int tickCounter;
    private long storedEmc;
    private long lastTransferred;
    private long totalTransferred;
    public RelayBlockEntity(BlockPos pos, BlockState state) { super(ProjectEXBlockEntities.RELAY.get(), pos, state); }
    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        tickCounter = tag.getInt("Tick");
        storedEmc = Math.max(0L, tag.getLong("StoredEMC"));
        lastTransferred = Math.max(0L, tag.getLong("LastTransferred"));
        totalTransferred = Math.max(0L, tag.getLong("TotalTransferred"));
    }
    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Tick", tickCounter);
        tag.putLong("StoredEMC", storedEmc);
        tag.putLong("LastTransferred", lastTransferred);
        tag.putLong("TotalTransferred", totalTransferred);
    }
    public void tickServer() {
        if (level == null || level.isClientSide || !(getBlockState().getBlock() instanceof RelayBlock block)) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;
        lastTransferred = 0L;
        if (storedEmc <= 0) { setChanged(); return; }
        List<IEmcStorage> targets = new ArrayList<>(6);
        for (Direction direction : Direction.values()) {
            BlockPos targetPos = worldPosition.relative(direction);
            var targetState = level.getBlockState(targetPos);
            var targetEntity = level.getBlockEntity(targetPos);
            IEmcStorage storage = PECapabilities.EMC_STORAGE_CAPABILITY.getCapability(level, targetPos, targetState, targetEntity, direction.getOpposite());
            // Match the classic 1.12.2 routing rule: do not loop into another
            // ProjectEX relay or ProjectE's MK1 relay, but allow other EMC
            // acceptors (including higher-tier ProjectE relays) as destinations.
            if (storage != null
                    && !(targetEntity instanceof RelayBlockEntity)
                    && !(targetEntity instanceof RelayMK1BlockEntity)
                    && storage.insertEmc(1L, EmcAction.SIMULATE) > 0L) {
                targets.add(storage);
            }
        }
        if (!targets.isEmpty()) {
            long share = Math.min(storedEmc / targets.size(), block.matter.relayTransfer);
            if (share > 0) for (IEmcStorage target : targets) {
                long inserted = target.insertEmc(share, EmcAction.EXECUTE);
                storedEmc -= inserted;
                lastTransferred = saturatingAdd(lastTransferred, inserted);
                totalTransferred = saturatingAdd(totalTransferred, inserted);
                if (storedEmc < share) break;
            }
        }
        setChanged();
    }
    public long getLastTransferred() { return lastTransferred; }
    public long getTotalTransferred() { return totalTransferred; }

    public long getTransferPerSecond() {
        return getBlockState().getBlock() instanceof RelayBlock block ? block.matter.relayTransfer : 0L;
    }
    public long getBonusPerCollectorPulse() {
        return getBlockState().getBlock() instanceof RelayBlock block ? block.matter.relayBonus : 0L;
    }
    public void addBonus() {
        if (getBlockState().getBlock() instanceof RelayBlock block) {
            storedEmc = Long.MAX_VALUE - storedEmc < block.matter.relayBonus ? Long.MAX_VALUE : storedEmc + block.matter.relayBonus;
            setChanged();
        }
    }
    private static long saturatingAdd(long a, long b) { return Long.MAX_VALUE - a < b ? Long.MAX_VALUE : a + b; }
    @Override public long getStoredEmc() { return storedEmc; }
    @Override public long getMaximumEmc() { return Long.MAX_VALUE; }
    @Override public long extractEmc(long emc, EmcAction action) {
        if (emc <= 0) return 0;
        long extracted = Math.min(storedEmc, emc);
        if (action.execute() && extracted > 0) { storedEmc -= extracted; setChanged(); }
        return extracted;
    }
    @Override public long insertEmc(long emc, EmcAction action) {
        if (emc <= 0) return 0;
        long inserted = Math.min(Long.MAX_VALUE - storedEmc, emc);
        if (action.execute() && inserted > 0) { storedEmc += inserted; setChanged(); }
        return inserted;
    }
    @Override public boolean isRelay() { return true; }
}
