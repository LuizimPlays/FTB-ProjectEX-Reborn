package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.alchemy.AlchemyTableRecipe;
import dev.latvian.mods.projectex.alchemy.AlchemyTableRecipes;
import dev.latvian.mods.projectex.menu.AlchemyTableMenu;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;

import java.math.BigInteger;

/** Server-authoritative Alchemy Table: two slots, progress, and a recipe-sized EMC buffer. */
public final class AlchemyTableBlockEntity extends BlockEntity implements IEmcStorage, MenuProvider {
    private static final long MIN_BUFFER_CAPACITY = 0L;
    private long storedEmc;
    private int progress;
    private long totalCost;
    private int totalProgress = AlchemyTableRecipe.DEFAULT_PROGRESS;
    private ItemStack processingInput = ItemStack.EMPTY;

    private final ItemStackHandler items = new ItemStackHandler(2) {
        @Override protected void onContentsChanged(int slot) {
            if (slot == 0) {
                ItemStack current = getStackInSlot(0);
                if (current.isEmpty() || !processingInput.isEmpty() && !ItemStack.isSameItemSameComponents(current, processingInput)) {
                    progress = 0;
                    processingInput = current.isEmpty() ? ItemStack.EMPTY : current.copyWithCount(1);
                }
            }
            refreshRecipeCost();
            setChanged();
        }

        @Override public boolean isItemValid(int slot, ItemStack stack) {
            return slot == 0 && AlchemyTableRecipes.hasOutput(stack);
        }

    };

    public AlchemyTableBlockEntity(BlockPos pos, BlockState state) {
        super(ProjectEXBlockEntities.ALCHEMY_TABLE.get(), pos, state);
        AlchemyTableRecipes.initializeDefaults();
    }

    public ItemStackHandler getItems() { return items; }
    public long getStoredBigEmc() { return storedEmc; }
    public int getProgress() { return progress; }
    public int getTotalProgress() { return totalProgress; }
    public long getTotalCost() { return totalCost; }

    public int getScaledProgress() {
        if (totalProgress <= 0) return 0;
        return Math.min(255, (int) ((long) progress * 255L / totalProgress));
    }

    public int getScaledEmc() {
        if (totalCost <= 0L) return 0;
        return BigInteger.valueOf(storedEmc).multiply(BigInteger.valueOf(255L))
                .divide(BigInteger.valueOf(Math.max(1L, totalCost))).min(BigInteger.valueOf(255L)).intValue();
    }

    @Override public Component getDisplayName() {
        return Component.translatable("container.projectex.alchemy_table");
    }

    @Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        return new AlchemyTableMenu(id, inventory, this);
    }

    private void refreshRecipeCost() {
        AlchemyTableRecipe recipe = AlchemyTableRecipes.getOutput(items.getStackInSlot(0));
        if (recipe == null || !hasOutputSpace(recipe)) {
            totalCost = 0L;
            totalProgress = recipe == null ? AlchemyTableRecipe.DEFAULT_PROGRESS : recipe.totalProgress();
        } else {
            totalCost = recipe.totalCost();
            totalProgress = recipe.totalProgress();
        }
    }

    public void tickServer() {
        if (level == null || level.isClientSide) return;
        ItemStack input = items.getStackInSlot(0);
        if (input.isEmpty()) {
            if (progress != 0 || totalCost != 0L) {
                progress = 0;
                totalCost = 0L;
                totalProgress = AlchemyTableRecipe.DEFAULT_PROGRESS;
                processingInput = ItemStack.EMPTY;
                setChangedAndNotify();
            }
            return;
        }

        AlchemyTableRecipe recipe = AlchemyTableRecipes.getOutput(input);
        if (recipe == null) {
            if (totalCost != 0L || progress != 0) {
                totalCost = 0L;
                progress = 0;
                processingInput = input.copyWithCount(1);
                setChangedAndNotify();
            }
            return;
        }

        if (processingInput.isEmpty() || !ItemStack.isSameItemSameComponents(processingInput, input)) {
            processingInput = input.copyWithCount(1);
            progress = 0;
        }
        totalProgress = recipe.totalProgress();
        if (!hasOutputSpace(recipe)) {
            totalCost = 0L;
            return;
        }
        totalCost = recipe.totalCost();
        if (totalCost <= 0L || storedEmc < totalCost) return;

        ItemStack output = items.getStackInSlot(1);
        ItemStack result = recipe.output();
        progress++;
        if (progress >= totalProgress) {
            // Commit only after every precondition is checked. One input and its exact EMC cost
            // produce one output; no partial item or EMC mutation occurs on a blocked output.
            storedEmc -= totalCost;
            input.shrink(1);
            items.setStackInSlot(0, input.isEmpty() ? ItemStack.EMPTY : input);

            if (output.isEmpty()) {
                items.setStackInSlot(1, result);
            } else {
                output.grow(1);
                items.setStackInSlot(1, output);
            }
            progress = 0;
            processingInput = input.isEmpty() ? ItemStack.EMPTY : input.copyWithCount(1);
        }
        setChangedAndNotify();
    }

    private boolean hasOutputSpace(AlchemyTableRecipe recipe) {
        ItemStack output = items.getStackInSlot(1);
        if (output.isEmpty()) return true;
        ItemStack result = recipe.output();
        return ItemStack.isSameItemSameComponents(output, result)
                && output.getCount() < Math.min(output.getMaxStackSize(), items.getSlotLimit(1));
    }

    private void setChangedAndNotify() {
        // ContainerData and Slot synchronization update an open menu; avoid broadcasting a full
        // block update packet every progress tick. setChanged still persists the machine state.
        setChanged();
    }

    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        storedEmc = Math.max(MIN_BUFFER_CAPACITY, tag.getLong("StoredEMC"));
        progress = Math.max(0, tag.getInt("Progress"));
        if (tag.contains("Items")) items.deserializeNBT(registries, tag.getCompound("Items"));
        processingInput = tag.contains("ProcessingInput")
                ? ItemStack.parseOptional(registries, tag.getCompound("ProcessingInput")) : ItemStack.EMPTY;
        refreshRecipeCost();
        if (progress >= totalProgress) progress = 0;
    }

    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putLong("StoredEMC", storedEmc);
        tag.putInt("Progress", progress);
        tag.put("Items", items.serializeNBT(registries));
        if (!processingInput.isEmpty()) tag.put("ProcessingInput", processingInput.save(registries));
    }

    @Override public long getStoredEmc() { return storedEmc; }
    @Override public long getMaximumEmc() {
        if (totalCost <= 0L) return 0L;
        return totalCost > Long.MAX_VALUE / 8L ? Long.MAX_VALUE : totalCost * 8L;
    }

    @Override public long extractEmc(long amount, EmcAction action) {
        // Classic Alchemy Table accepts EMC; it does not expose its internal buffer for extraction.
        return 0L;
    }

    @Override public long insertEmc(long amount, EmcAction action) {
        if (amount <= 0L || totalCost <= 0L) return 0L;
        long capacity = getMaximumEmc();
        long available = Math.max(0L, capacity - Math.min(capacity, storedEmc));
        long accepted = Math.min(amount, available);
        if (action.execute() && accepted > 0L) {
            storedEmc += accepted;
            setChangedAndNotify();
        }
        return accepted;
    }
}
