package dev.latvian.mods.projectex;

import com.mojang.logging.LogUtils;
import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import dev.latvian.mods.projectex.menu.ProjectEXMenus;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

import java.util.function.Supplier;

@Mod(ProjectEX.MOD_ID)
public final class ProjectEX {
    public static final String MOD_ID = "projectex";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final Supplier<CreativeModeTab> MAIN_TAB = CREATIVE_TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.projectex"))
            .icon(() -> new ItemStack(ProjectEXItems.FINAL_STAR.get()))
            .displayItems((parameters, output) -> {
                ProjectEXItems.REGISTRY.getEntries().forEach(entry -> output.accept(entry.get()));
            })
            .build());

    public ProjectEX(IEventBus modBus) {
        ProjectEXBlocks.REGISTRY.register(modBus);
        ProjectEXBlockEntities.REGISTRY.register(modBus);
        ProjectEXItems.REGISTRY.register(modBus);
        ProjectEXMenus.REGISTRY.register(modBus);
        CREATIVE_TABS.register(modBus);
        modBus.addListener(this::registerCapabilities);
        LOGGER.info("FTB ProjectEX 0.8.26-alpha registries initialized.");
    }

    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(PECapabilities.EMC_STORAGE_CAPABILITY, ProjectEXBlockEntities.ENERGY_LINK.get(), (blockEntity, side) -> blockEntity);
        event.registerBlockEntity(PECapabilities.EMC_STORAGE_CAPABILITY, ProjectEXBlockEntities.LINK.get(), (blockEntity, side) -> blockEntity);
        event.registerBlockEntity(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK, ProjectEXBlockEntities.LINK.get(), (blockEntity, side) -> blockEntity.getInventory());
        event.registerBlockEntity(PECapabilities.EMC_STORAGE_CAPABILITY, ProjectEXBlockEntities.COLLECTOR.get(), (blockEntity, side) -> blockEntity);
        event.registerBlockEntity(PECapabilities.EMC_STORAGE_CAPABILITY, ProjectEXBlockEntities.RELAY.get(), (blockEntity, side) -> blockEntity);
        event.registerBlockEntity(PECapabilities.EMC_STORAGE_CAPABILITY, ProjectEXBlockEntities.ALCHEMY_TABLE.get(), (blockEntity, side) -> blockEntity);
        event.registerBlockEntity(net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK, ProjectEXBlockEntities.ALCHEMY_TABLE.get(), (blockEntity, side) -> blockEntity.getItems());
    }
}
