package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.crafting.ArcaneCraftingSupport;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import dev.latvian.mods.projectex.network.ArcaneTabletActionPayload;
import moze_intel.projecte.gameObjs.container.TransmutationContainer;
import moze_intel.projecte.gameObjs.gui.GUITransmutation;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.network.PacketDistributor;

import java.lang.reflect.Field;

/**
 * Arcane Tablet screen ported to the original 1.12.2 composition:
 * 176x217 transmutation panel, 76x89 crafting extension to its left,
 * circular learned-item slots, and the original action hit areas.
 */
public final class ArcaneTabletTransmutationScreen extends GUITransmutation {
    private static final ResourceLocation ARCANE_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/arcane_tablet.png");
    private static final int MAIN_WIDTH = 176;
    private static final int MAIN_HEIGHT = 217;
    private static final int SIDE_X = 180;
    private static final int SIDE_Y = 19;
    private static final int SIDE_WIDTH = 76;
    private static final int SIDE_HEIGHT = 89;
    private static final int OUTPUT_RING_SHIFT_X = 70;
    private static final int OUTPUT_RING_SHIFT_Y = 20;

    private static final Field PREVIOUS_BUTTON = findField("previous");
    private static final Field NEXT_BUTTON = findField("next");
    private static final Field FILTER_BOX = findField("textBoxFilter");
    private static final Field SLOT_X = findSlotField("x");
    private static final Field SLOT_Y = findSlotField("y");

    private boolean arcaneSlotsPositioned;
    private EditBox searchBox;
    private int searchMode;
    private static final char[] SEARCH_PREFIXES = {'~', '@', '$', '#'};
    private static final String[] SEARCH_MODE_LABELS = {"Nome", "Mod ID", "Descrição", "Tags"};

    public ArcaneTabletTransmutationScreen(TransmutationContainer menu, Inventory inventory, Component title) {
        super(menu, inventory, Component.empty());
        imageWidth = MAIN_WIDTH;
        imageHeight = MAIN_HEIGHT;
        titleLabelX = 300; // Hide ProjectE's normal title; the original artwork has no title line.
        titleLabelY = 300;
    }

    private static Field findField(String name) {
        try {
            Field field = GUITransmutation.class.getDeclaredField(name);
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private static Field findSlotField(String name) {
        try {
            Field field = Slot.class.getDeclaredField(name);
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private boolean isArcaneTabletMenu() {
        return minecraft != null && minecraft.player != null && menu.hand != null
                && minecraft.player.getItemInHand(menu.hand).is(ProjectEXItems.ARCANE_TABLET.get());
    }

    @Override
    public void init() {
        super.init();
        if (!isArcaneTabletMenu()) return;

        // Restore the original search field: x=8, y=7, width=160, height=11.
        try {
            searchBox = (EditBox) FILTER_BOX.get(this);
            if (searchBox != null) {
                searchBox.setX(leftPos + 8);
                searchBox.setY(topPos + 7);
                searchBox.setWidth(160);
                searchBox.setHeight(11);
            }
        } catch (IllegalAccessException exception) {
            throw new IllegalStateException("Unable to align Arcane Tablet search field", exception);
        }

        // The original GUI placed the page arrows at the two ends of the search/header strip.
        try {
            Button previous = (Button) PREVIOUS_BUTTON.get(this);
            Button next = (Button) NEXT_BUTTON.get(this);
            if (previous != null) {
                previous.setPosition(leftPos + 7, topPos + 20);
                previous.setWidth(18);
                previous.setHeight(18);
                previous.setAlpha(0.0F); // The original atlas arrow is drawn over this live ProjectE button.
            }
            if (next != null) {
                next.setPosition(leftPos + 151, topPos + 20);
                next.setWidth(18);
                next.setHeight(18);
                next.setAlpha(0.0F);
            }
        } catch (IllegalAccessException exception) {
            throw new IllegalStateException("Unable to align Arcane Tablet page controls", exception);
        }

        // ProjectE's 16 learned-item slots form a ring. Translate the full ring
        // from the wide ProjectE screen into the centre of the classic 176x217 tablet.
        if (!arcaneSlotsPositioned) {
            try {
                for (int slotIndex = 11; slotIndex <= 26; slotIndex++) {
                    Slot slot = menu.slots.get(slotIndex);
                    SLOT_X.setInt(slot, slot.x - OUTPUT_RING_SHIFT_X);
                    SLOT_Y.setInt(slot, slot.y + OUTPUT_RING_SHIFT_Y);
                }
                arcaneSlotsPositioned = true;
            } catch (IllegalAccessException | IndexOutOfBoundsException exception) {
                throw new IllegalStateException("Unable to position Arcane Tablet transmutation ring", exception);
            }
        }
    }

    private boolean hit(double mouseX, double mouseY, int x, int y, int width, int height) {
        double left = leftPos + x;
        double top = topPos + y;
        return mouseX >= left && mouseX < left + width && mouseY >= top && mouseY < top + height;
    }

    private void sendAction(int action) {
        PacketDistributor.sendToServer(new ArcaneTabletActionPayload(menu.containerId, action));
    }

    private void cycleSearchMode() {
        if (searchBox == null) return;
        String value = searchBox.getValue();
        String query = value;
        if (!value.isEmpty() && (value.charAt(0) == '~' || value.charAt(0) == '@'
                || value.charAt(0) == '$' || value.charAt(0) == '#')) {
            query = value.substring(1);
        }
        searchMode = (searchMode + 1) % SEARCH_PREFIXES.length;
        searchBox.setValue(SEARCH_PREFIXES[searchMode] + query);
        searchBox.setFocused(true);
        searchBox.moveCursorToEnd(false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isArcaneTabletMenu() && button == 0) {
            // Small mode controls embedded in the left-side 1.12.2 artwork.
            if (hit(mouseX, mouseY, -71, 16, 9, 9)) {
                sendAction(hasShiftDown() ? ArcaneCraftingSupport.ACTION_ROTATE_CCW : ArcaneCraftingSupport.ACTION_ROTATE_CW);
                return true;
            }
            if (hit(mouseX, mouseY, -71, 26, 9, 9)) {
                sendAction(hasShiftDown() ? ArcaneCraftingSupport.ACTION_SPREAD : ArcaneCraftingSupport.ACTION_BALANCE);
                return true;
            }
            if (hit(mouseX, mouseY, -71, 36, 9, 9)) {
                cycleSearchMode();
                return true;
            }
            if (hit(mouseX, mouseY, -71, 61, 9, 9)) {
                sendAction(ArcaneCraftingSupport.ACTION_CLEAR);
                return true;
            }
            // Original green learn, red unlearn and central burn controls.
            if (hit(mouseX, mouseY, 8, 115, 16, 16)) {
                sendAction(ArcaneCraftingSupport.ACTION_LEARN);
                return true;
            }
            if (hit(mouseX, mouseY, 152, 115, 16, 16)) {
                sendAction(ArcaneCraftingSupport.ACTION_UNLEARN);
                return true;
            }
            if (hit(mouseX, mouseY, 80, 68, 16, 16)) {
                sendAction(hasShiftDown() ? ArcaneCraftingSupport.ACTION_BURN_OR_TRANSFER : ArcaneCraftingSupport.ACTION_BURN);
                return true;
            }
        }

        if (isArcaneTabletMenu() && hoveredSlot != null
                && ArcaneCraftingSupport.isCraftingSlot(menu, hoveredSlot)) {
            // Prevent ProjectE's inherited quick-move path from treating Arcane
            // ingredients as EMC input/sale slots. Grid items are moved normally.
            if (hasShiftDown()) return true;
            if (button == 1 && ArcaneCraftingSupport.isResultSlot(menu, hoveredSlot)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        if (!isArcaneTabletMenu()) {
            super.renderBg(graphics, partialTick, mouseX, mouseY);
            return;
        }
        // Main transmutation tablet panel.
        graphics.blit(ARCANE_TEXTURE, leftPos, topPos,
                0, 0, MAIN_WIDTH, MAIN_HEIGHT, 256, 256);
        // The original companion crafting panel is drawn to the LEFT of the main tablet.
        graphics.blit(ARCANE_TEXTURE, leftPos - 75, topPos + 10,
                SIDE_X, SIDE_Y, SIDE_WIDTH, SIDE_HEIGHT, 256, 256);
        // Restore the original textured page arrows while retaining the inherited page actions.
        graphics.blit(ARCANE_TEXTURE, leftPos + 7, topPos + 20,
                196, 0, 18, 18, 256, 256);
        graphics.blit(ARCANE_TEXTURE, leftPos + 151, topPos + 20,
                215, 0, 18, 18, 256, 256);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        super.renderLabels(graphics, mouseX, mouseY);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        if (!isArcaneTabletMenu()) return;

        Component tooltip = null;
        if (hit(mouseX, mouseY, -71, 16, 9, 9)) tooltip = Component.literal("Girar receita (Shift: sentido anti-horário)");
        else if (hit(mouseX, mouseY, -71, 26, 9, 9)) tooltip = Component.literal("Balancear ingredientes (Shift: distribuir)");
        else if (hit(mouseX, mouseY, -71, 36, 9, 9)) tooltip = Component.literal("Modo de busca: " + SEARCH_MODE_LABELS[searchMode]);
        else if (hit(mouseX, mouseY, -71, 61, 9, 9)) tooltip = Component.literal("Limpar bancada");
        else if (hit(mouseX, mouseY, 8, 115, 16, 16)) tooltip = Component.literal("Aprender item da mão");
        else if (hit(mouseX, mouseY, 152, 115, 16, 16)) tooltip = Component.literal("Esquecer item da mão");
        else if (hit(mouseX, mouseY, 80, 68, 16, 16)) tooltip = Component.literal("Queimar item (Shift: transferir EMC)");
        if (tooltip != null) graphics.renderTooltip(font, tooltip, mouseX, mouseY);
    }
}
