package dev.latvian.mods.projectex.menu;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Dedicated portable menu for the ProjectEX Arcane Tablet. */
public final class ArcaneTabletMenu extends AbstractContainerMenu {
    private static final int MAIN_INVENTORY_START = 0;
    private static final int MAIN_INVENTORY_END = 27;
    private static final int HOTBAR_START = 27;
    private static final int HOTBAR_END = 36;

    public ArcaneTabletMenu(int id, Inventory inventory) {
        super(ProjectEXMenus.ARCANE_TABLET.get(), id);

        // Player inventory: 3 rows, excluding the hotbar.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, 8 + col * 18, 134 + row * 18));
            }
        }

        // Hotbar.
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 188));
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) {
            return ItemStack.EMPTY;
        }

        Slot sourceSlot = slots.get(index);
        if (!sourceSlot.hasItem()) {
            return ItemStack.EMPTY;
        }

        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack originalStack = sourceStack.copy();

        // Shift-click moves items between the main inventory and hotbar.
        boolean moved;
        if (index >= MAIN_INVENTORY_START && index < MAIN_INVENTORY_END) {
            moved = moveItemStackTo(sourceStack, HOTBAR_START, HOTBAR_END, false);
        } else if (index >= HOTBAR_START && index < HOTBAR_END) {
            moved = moveItemStackTo(sourceStack, MAIN_INVENTORY_START, MAIN_INVENTORY_END, false);
        } else {
            return ItemStack.EMPTY;
        }

        if (!moved) {
            return ItemStack.EMPTY;
        }

        if (sourceStack.isEmpty()) {
            sourceSlot.set(ItemStack.EMPTY);
        } else {
            sourceSlot.setChanged();
        }

        sourceSlot.onTake(player, sourceStack);
        return originalStack;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}
