package dev.latvian.mods.projectex.item;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.Star;
import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/** First-pass item registry using the original ProjectEX registry names. */
public final class ProjectEXItems {
    public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(Registries.ITEM, ProjectEX.MOD_ID);

    public static final Supplier<Item> ENERGY_LINK = blockItem("energy_link", ProjectEXBlocks.ENERGY_LINK);
    public static final Supplier<Item> PERSONAL_LINK = blockItem("personal_link", ProjectEXBlocks.PERSONAL_LINK);
    public static final Supplier<Item> REFINED_LINK = blockItem("refined_link", ProjectEXBlocks.REFINED_LINK);
    public static final Supplier<Item> COMPRESSED_REFINED_LINK = blockItem("compressed_refined_link", ProjectEXBlocks.COMPRESSED_REFINED_LINK);

    public static final Map<Matter, Supplier<Item>> COLLECTOR = machineBlockItems("_collector", ProjectEXBlocks.COLLECTOR, ProjectEXMachineBlockItem.Machine.COLLECTOR);
    public static final Map<Matter, Supplier<Item>> RELAY = machineBlockItems("_relay", ProjectEXBlocks.RELAY, ProjectEXMachineBlockItem.Machine.RELAY);
    public static final Map<Matter, Supplier<Item>> POWER_FLOWER = machineBlockItems("_power_flower", ProjectEXBlocks.POWER_FLOWER, ProjectEXMachineBlockItem.Machine.POWER_FLOWER);

    public static final Supplier<Item> STONE_TABLE = blockItem("stone_table", ProjectEXBlocks.STONE_TABLE);
    public static final Supplier<Item> ALCHEMY_TABLE = blockItem("alchemy_table", ProjectEXBlocks.ALCHEMY_TABLE);

    public static final Map<Star, Supplier<Item>> MAGNUM_STAR = registerStars("magnum_star_");
    public static final Map<Star, Supplier<Item>> COLOSSAL_STAR = registerStars("colossal_star_");
    public static final Map<Matter, Supplier<Item>> MATTER = registerMatterItems();

    public static final Supplier<Item> FINAL_STAR_SHARD = item("final_star_shard");
    public static final Supplier<Item> FINAL_STAR = item("final_star");
    public static final Supplier<Item> KNOWLEDGE_SHARING_BOOK = item("knowledge_sharing_book");
    public static final Supplier<Item> ARCANE_TABLET = REGISTRY.register("arcane_tablet", ArcaneTabletItem::new);
    public static final Map<Matter, Supplier<Item>> COMPRESSED_COLLECTOR = registerCompressedCollectors();

    private ProjectEXItems() {}

    private static Supplier<Item> item(String id) {
        return REGISTRY.register(id, () -> new Item(new Item.Properties()));
    }

    private static Supplier<Item> blockItem(String id, Supplier<net.minecraft.world.level.block.Block> block) {
        return REGISTRY.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    private static Map<Matter, Supplier<Item>> blockItems(String suffix, Map<Matter, Supplier<net.minecraft.world.level.block.Block>> blocks) {
        Map<Matter, Supplier<Item>> map = new LinkedHashMap<>();
        for (Matter matter : Matter.VALUES) {
            map.put(matter, blockItem(matter.name + suffix, blocks.get(matter)));
        }
        return Map.copyOf(map);
    }

    private static Map<Matter, Supplier<Item>> machineBlockItems(String suffix, Map<Matter, Supplier<net.minecraft.world.level.block.Block>> blocks, ProjectEXMachineBlockItem.Machine machine) {
        Map<Matter, Supplier<Item>> map = new LinkedHashMap<>();
        for (Matter matter : Matter.VALUES) map.put(matter, REGISTRY.register(matter.name + suffix, () -> new ProjectEXMachineBlockItem(blocks.get(matter).get(), new Item.Properties(), matter, machine)));
        return Map.copyOf(map);
    }

    private static Map<Star, Supplier<Item>> registerStars(String prefix) {
        Map<Star, Supplier<Item>> map = new LinkedHashMap<>();
        for (Star star : Star.VALUES) {
            map.put(star, item(prefix + star.name));
        }
        return Map.copyOf(map);
    }

    private static Map<Matter, Supplier<Item>> registerMatterItems() {
        Map<Matter, Supplier<Item>> map = new LinkedHashMap<>();
        for (Matter matter : Matter.VALUES) {
            if (matter.hasMatterItem) map.put(matter, item(matter.name + "_matter"));
        }
        return Map.copyOf(map);
    }

    private static Map<Matter, Supplier<Item>> registerCompressedCollectors() {
        Map<Matter, Supplier<Item>> map = new LinkedHashMap<>();
        for (Matter matter : Matter.VALUES) {
            map.put(matter, item(matter.name + "_compressed_collector"));
        }
        return Map.copyOf(map);
    }
}
