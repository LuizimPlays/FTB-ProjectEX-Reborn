package dev.latvian.mods.projectex.network;


import dev.latvian.mods.projectex.block.entity.EnergyLinkBlockEntity;
import dev.latvian.mods.projectex.crafting.ArcaneCraftingSupport;
import dev.latvian.mods.projectex.item.ProjectEXItems;
import moze_intel.projecte.gameObjs.container.TransmutationContainer;
import dev.latvian.mods.projectex.util.EmcFormat;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid = "projectex")
public final class EnergyLinkNetwork {
    private EnergyLinkNetwork() {}

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("2").playToServer(ArcaneTabletActionPayload.TYPE, ArcaneTabletActionPayload.STREAM_CODEC, (payload, context) -> {
            context.enqueueWork(() -> {
                if (!(context.player() instanceof ServerPlayer player)) return;
                if (!(player.containerMenu instanceof TransmutationContainer menu)) return;
                if (menu.containerId != payload.menuId() || menu.hand == null) return;
                if (!player.getItemInHand(menu.hand).is(ProjectEXItems.ARCANE_TABLET.get())) return;
                ArcaneCraftingSupport.performAction(menu, player, payload.action());
            });
        });
        event.registrar("2").playToServer(StoneTableActionPayload.TYPE, StoneTableActionPayload.STREAM_CODEC, (payload, context) -> {
            context.enqueueWork(() -> {
                if (context.player() instanceof ServerPlayer player) StoneTableActions.handle(player, payload);
            });
        });
        event.registrar("2").playToServer(EnergyLinkStatusRequestPayload.TYPE, EnergyLinkStatusRequestPayload.STREAM_CODEC, (payload, context) -> {
            context.enqueueWork(() -> {
                if (!(context.player() instanceof ServerPlayer player)) return;
                if (!player.level().hasChunkAt(payload.pos())) return;
                if (!(player.level().getBlockEntity(payload.pos()) instanceof EnergyLinkBlockEntity link)) return;
                if (player.distanceToSqr(payload.pos().getX() + 0.5, payload.pos().getY() + 0.5, payload.pos().getZ() + 0.5) > 64.0) return;
                sendStatus(player, link);
            });
        });
    }

    public static void sendStatus(ServerPlayer viewer, EnergyLinkBlockEntity link) {
        ServerPlayer owner = viewer.getServer().getPlayerList().getPlayer(link.getOwnerId());
        var knowledge = owner == null ? null : owner.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        boolean online = owner != null && knowledge != null;
        String balance = knowledge == null ? "Offline" : EmcFormat.format(knowledge.getEmc());
        PacketDistributor.sendToPlayer(viewer, new EnergyLinkStatusPayload(link.getBlockPos(), link.getOwnerName(), EmcFormat.format(link.getStoredBigEmc()), EmcFormat.format(link.getLastTransferred()), EmcFormat.format(link.getTotalTransferred()), balance, online));
    }
}
