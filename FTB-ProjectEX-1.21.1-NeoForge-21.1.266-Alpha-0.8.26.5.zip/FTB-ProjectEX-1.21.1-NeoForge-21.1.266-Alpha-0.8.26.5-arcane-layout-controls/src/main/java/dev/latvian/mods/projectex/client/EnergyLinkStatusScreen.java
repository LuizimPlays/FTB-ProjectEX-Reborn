package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.network.EnergyLinkStatusPayload;
import dev.latvian.mods.projectex.network.EnergyLinkStatusRequestPayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Responsive Energy Link dashboard with periodic live server refresh. */
public final class EnergyLinkStatusScreen extends Screen {
    private static final int BG = 0xF0101720;
    private static final int PANEL = 0xF018222D;
    private static final int BORDER = 0xFF304553;
    private static final int CYAN = 0xFF49D6CC;
    private static final int WHITE = 0xFFF1F5F8;
    private static final int MUTED = 0xFF9EADB8;
    private static final int GOLD = 0xFFFFD166;
    private static final int PURPLE = 0xFFC3A6FF;
    private static final int GREEN = 0xFF68E89A;

    private static final int DESIGN_WIDTH = 330;
    private static final int DESIGN_HEIGHT = 190;

    private EnergyLinkStatusPayload data;
    private int refreshTicks;
    private int animationTicks;
    private int transferPulseTicks;
    private String previousTransfer;

    public EnergyLinkStatusScreen(EnergyLinkStatusPayload data) {
        super(Component.literal("Energy Link"));
        this.data = data;
        this.previousTransfer = data.lastTransfer();
    }

    public net.minecraft.core.BlockPos getLinkPos() {
        return data.pos();
    }

    public void updateData(EnergyLinkStatusPayload latest) {
        if (latest.lastTransfer() != null && !latest.lastTransfer().equals(previousTransfer)
                && !latest.lastTransfer().equals("0")) {
            transferPulseTicks = 12;
        }
        previousTransfer = latest.lastTransfer();
        this.data = latest;
    }

    @Override
    public void tick() {
        super.tick();
        animationTicks++;
        if (transferPulseTicks > 0) transferPulseTicks--;
        // Four status updates per second keep the buffer and delivered balance responsive.
        if (++refreshTicks >= 5) {
            refreshTicks = 0;
            PacketDistributor.sendToServer(new EnergyLinkStatusRequestPayload(data.pos()));
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x76060A10);

        // Scale the complete dashboard as one unit so it remains inside even
        // unusually short windows and small GUI scales.
        float scale = Math.min(1.0F, Math.min(
                Math.max(1.0F, width - 16) / (float) DESIGN_WIDTH,
                Math.max(1.0F, height - 16) / (float) DESIGN_HEIGHT));

        g.pose().pushPose();
        g.pose().translate(width / 2.0F, height / 2.0F, 0.0F);
        g.pose().scale(scale, scale, 1.0F);

        int left = -DESIGN_WIDTH / 2;
        int top = -DESIGN_HEIGHT / 2;
        int right = left + DESIGN_WIDTH;
        int bottom = top + DESIGN_HEIGHT;

        // Shadow, layered surface, fine frame and softly pulsing cyan accent.
        g.fill(left + 3, top + 4, right + 3, bottom + 4, 0x55000000);
        g.fill(left, top, right, bottom, BG);
        g.fill(left + 1, top + 1, right - 1, bottom - 1, PANEL);

        int pulse = 190 + (int) (Math.sin(animationTicks * 0.12D) * 45.0D);
        int accent = (pulse << 24) | (CYAN & 0x00FFFFFF);
        if (transferPulseTicks > 0) {
            int pulseAlpha = Math.min(255, 110 + transferPulseTicks * 12);
            accent = (pulseAlpha << 24) | (0x55FF88);
        }
        g.fill(left, top, right, top + 2, accent);
        g.fill(left, top, left + 2, bottom, transferPulseTicks > 0 ? 0xFF55FF88 : CYAN);
        g.fill(left + 12, top + 29, right - 12, top + 30, BORDER);

        g.drawCenteredString(font, Component.literal("ENERGY LINK"), 0, top + 11, CYAN);
        g.drawString(font, Component.literal("PROPRIETÁRIO"), left + 14, top + 39, MUTED, false);
        drawClipped(g, data.owner(), left + 14, top + 51, 190, WHITE, true);

        int statusColor = data.ownerOnline() ? GREEN : 0xFFADB6C0;
        String status = data.ownerOnline() ? "ONLINE" : "OFFLINE";
        int statusW = font.width(status) + 12;
        int statusX = right - statusW - 14;
        g.fill(statusX, top + 48, statusX + statusW, top + 63, 0x55334444);
        g.drawCenteredString(font, Component.literal(status), statusX + statusW / 2, top + 52, statusColor);

        int gap = 7;
        int tileW = (DESIGN_WIDTH - 28 - gap * 2) / 3;
        int tileY = top + 75;
        drawMetric(g, left + 14, tileY, tileW, "BUFFER", data.buffer() + " EMC", GOLD);
        drawMetric(g, left + 14 + tileW + gap, tileY, tileW,
                "ÚLTIMA ENTREGA", data.lastTransfer() + " EMC", WHITE);
        drawMetric(g, left + 14 + (tileW + gap) * 2, tileY, tileW,
                "TOTAL ENTREGUE", data.totalTransferred() + " EMC", PURPLE);

        g.fill(left + 14, top + 119, right - 14, top + 120, BORDER);
        g.drawString(font, Component.literal("SALDO DO PROPRIETÁRIO"), left + 14, top + 130, MUTED, false);
        drawClipped(g, data.ownerBalance() + " EMC", left + 14, top + 145,
                DESIGN_WIDTH - 28, GREEN, true);

        g.drawCenteredString(font, Component.literal("ESC  •  FECHAR"), 0, top + 171, MUTED);
        g.pose().popPose();

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawMetric(GuiGraphics g, int x, int y, int w,
                            String label, String value, int color) {
        g.fill(x, y, x + w, y + 36, 0xAA101820);
        g.fill(x, y, x + w, y + 1, BORDER);
        drawCenteredClipped(g, label, x + w / 2, y + 5, w - 8, MUTED);
        drawCenteredClipped(g, value, x + w / 2, y + 19, w - 8, color);
    }

    private void drawClipped(GuiGraphics g, String value, int x, int y,
                             int maxWidth, int color, boolean shadow) {
        String shown = fit(value, maxWidth);
        g.drawString(font, Component.literal(shown), x, y, color, shadow);
    }

    private void drawCenteredClipped(GuiGraphics g, String value, int centerX, int y,
                                     int maxWidth, int color) {
        String shown = fit(value, maxWidth);
        g.drawCenteredString(font, Component.literal(shown), centerX, y, color);
    }

    private String fit(String value, int maxWidth) {
        if (value == null) return "-";
        if (font.width(value) <= maxWidth) return value;
        String ellipsis = "…";
        int end = value.length();
        while (end > 1 && font.width(value.substring(0, end) + ellipsis) > maxWidth) {
            end--;
        }
        return value.substring(0, Math.max(1, end)) + ellipsis;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // The dimmed world is drawn by render().
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
