package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.block.entity.CollectorBlockEntity;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;

public final class CollectorBlock extends Block implements EntityBlock {
    public final Matter matter;
    public CollectorBlock(Matter matter) {
        super(BlockBehaviour.Properties.of().strength(3.5F).sound(SoundType.STONE));
        this.matter = matter;
    }
    /**
     * Client-side feedback: collectors visibly emit energy while their server-side
     * block entity continues to own all EMC calculations.
     */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) != 0) return;
        double x = pos.getX() + 0.2D + random.nextDouble() * 0.6D;
        double y = pos.getY() + 0.75D + random.nextDouble() * 0.2D;
        double z = pos.getZ() + 0.2D + random.nextDouble() * 0.6D;
        level.addParticle(ParticleTypes.END_ROD, x, y, z,
                (random.nextDouble() - 0.5D) * 0.015D, 0.025D,
                (random.nextDouble() - 0.5D) * 0.015D);
    }

    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CollectorBlockEntity(pos, state);
    }
    @Override @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != ProjectEXBlockEntities.COLLECTOR.get() || level.isClientSide) return null;
        return (lvl, pos, blockState, be) -> {
            if (be instanceof CollectorBlockEntity collector) collector.tickServer();
        };
    }
    @Override
    public net.minecraft.world.InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, net.minecraft.world.entity.player.Player player, net.minecraft.world.phys.BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof CollectorBlockEntity machine) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "§6Energy Collector " + matter.getMK() + "\n§eArmazenado: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getStoredEmc()) + " EMC\n§aProdução: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getGeneratedPerSecond()) + " EMC/s"
                    + "\n§bDistribuído no último ciclo: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getLastDistributed()) + " EMC"
                    + "\n§7Total distribuído: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getTotalDistributed()) + " EMC"), false);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

}
