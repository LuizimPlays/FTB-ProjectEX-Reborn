package dev.latvian.mods.projectex.menu;

import dev.latvian.mods.projectex.block.ProjectEXBlocks;
import dev.latvian.mods.projectex.network.StoneTableActions;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Stone Table menu. The radial catalogue is rendered client-side; all actions are server-authoritative packets. */
public final class StoneTableMenu extends AbstractContainerMenu {
    private final ContainerLevelAccess access;

    public StoneTableMenu(int id, Inventory inventory, Level level, BlockPos pos) {
        super(ProjectEXMenus.STONE_TABLE.get(), id);
        this.access = ContainerLevelAccess.create(level, pos);
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, 8 + col * 18, 135 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 193));
        }
    }

    /** Client construction path; the block position is sent by openMenu. */
    public StoneTableMenu(int id, Inventory inventory, BlockPos pos) {
        this(id, inventory, inventory.player.level(), pos);
    }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        // In the original ContainerTableBase, shift-clicking an inventory stack burns it into EMC.
        if (!(player instanceof ServerPlayer serverPlayer) || index < 0 || index >= slots.size()) return ItemStack.EMPTY;
        Slot source = slots.get(index);
        if (!source.hasItem()) return ItemStack.EMPTY;
        IKnowledgeProvider knowledge = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge == null) return ItemStack.EMPTY;
        ItemStack stack = source.getItem();
        ItemStack original = stack.copy();
        if (!StoneTableActions.burnStack(serverPlayer, knowledge, stack)) return ItemStack.EMPTY;
        source.set(ItemStack.EMPTY);
        source.setChanged();
        source.onTake(player, stack);
        broadcastChanges();
        return original;
    }

    @Override public boolean stillValid(Player player) {
        return stillValid(access, player, ProjectEXBlocks.STONE_TABLE.get());
    }
}
