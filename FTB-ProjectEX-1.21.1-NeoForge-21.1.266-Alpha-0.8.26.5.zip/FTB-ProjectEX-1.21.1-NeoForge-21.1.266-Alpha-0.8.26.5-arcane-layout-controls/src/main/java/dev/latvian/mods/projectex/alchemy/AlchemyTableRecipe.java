package dev.latvian.mods.projectex.alchemy;

import moze_intel.projecte.api.proxy.IEMCProxy;
import net.minecraft.world.item.ItemStack;

import java.math.BigInteger;

/** One-input/one-output Alchemy Table transmutation, matching the 1.12.2 cost model. */
public final class AlchemyTableRecipe {
    public static final int DEFAULT_PROGRESS = 200;
    private static final BigInteger MINIMUM_COST = BigInteger.valueOf(64L);
    private static final BigInteger COST_MULTIPLIER = BigInteger.valueOf(3L);
    private static final BigInteger LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE);

    private final ItemStack input;
    private final ItemStack output;
    private final long costOverride;
    private final int progressOverride;

    public AlchemyTableRecipe(ItemStack input, ItemStack output) {
        this(input, output, 0L, 0);
    }

    public AlchemyTableRecipe(ItemStack input, ItemStack output, long costOverride, int progressOverride) {
        if (input.isEmpty() || output.isEmpty()) {
            throw new IllegalArgumentException("Alchemy Table recipes require non-empty input and output stacks");
        }
        this.input = input.copyWithCount(1);
        this.output = output.copyWithCount(1);
        this.costOverride = Math.max(0L, costOverride);
        this.progressOverride = Math.max(0, progressOverride);
    }

    public ItemStack input() { return input.copy(); }
    public ItemStack output() { return output.copy(); }

    public boolean matches(ItemStack stack) {
        // 1.12.2 recipes matched the item + metadata. Modern variants are distinct items;
        // persistent components are intentionally ignored for these simple legacy recipes.
        return !stack.isEmpty() && stack.is(input.getItem());
    }

    public long totalCost() {
        if (costOverride > 0L) return costOverride;
        long inputValue = Math.max(0L, IEMCProxy.INSTANCE.getValue(input));
        long outputValue = Math.max(0L, IEMCProxy.INSTANCE.getValue(output));
        BigInteger computed = BigInteger.valueOf(inputValue)
                .add(BigInteger.valueOf(outputValue))
                .multiply(COST_MULTIPLIER)
                .max(MINIMUM_COST);
        return computed.min(LONG_MAX).longValue();
    }

    public int totalProgress() {
        return progressOverride > 0 ? progressOverride : DEFAULT_PROGRESS;
    }
}
