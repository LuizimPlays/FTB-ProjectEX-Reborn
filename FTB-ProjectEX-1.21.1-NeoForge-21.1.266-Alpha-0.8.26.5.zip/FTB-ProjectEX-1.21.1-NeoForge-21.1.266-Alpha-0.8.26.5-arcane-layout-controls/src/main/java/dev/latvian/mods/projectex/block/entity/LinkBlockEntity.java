package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.block.LinkBlock;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.api.proxy.ITransmutationProxy;
import moze_intel.projecte.config.ProjectEConfig;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

import java.math.BigInteger;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Persistent EMC Link shared by Personal, Refined and Compressed Refined tiers.
 * Input slots consume EMC-valued items; output slots are persistent item filters
 * whose products are bought from the owner's ProjectE knowledge/EMC balance.
 */
public final class LinkBlockEntity extends BlockEntity implements IEmcStorage, MenuProvider {
    private static final BigInteger LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE);
    private static final BigInteger ZERO = BigInteger.ZERO;
    private static final int MAX_AUTOMATION_OUTPUT = 2_000_000_000;

    private final int inputSlots;
    private final int outputSlots;
    private final ItemStackHandler inputInventory;
    private final ItemStackHandler outputFilters;
    private final IItemHandler automationHandler = new LinkAutomationHandler();

    private UUID owner = Util.NIL_UUID;
    private String ownerName = "";
    private BigInteger storedEmc = ZERO;
    private BigInteger lastImportedEmc = ZERO;
    private BigInteger totalImportedEmc = ZERO;
    private int tickCounter;

    public LinkBlockEntity(BlockPos pos, BlockState state) {
        super(ProjectEXBlockEntities.LINK.get(), pos, state);
        LinkBlock.Tier tier = state.getBlock() instanceof LinkBlock link ? link.getTier() : LinkBlock.Tier.PERSONAL;
        inputSlots = tier.inputSlots;
        outputSlots = tier.outputSlots;
        inputInventory = new ItemStackHandler(inputSlots) {
            @Override protected void onContentsChanged(int slot) { LinkBlockEntity.this.setChanged(); }
            @Override public boolean isItemValid(int slot, ItemStack stack) {
                return slot >= 0 && slot < inputSlots && !stack.isEmpty()
                        && IEMCProxy.INSTANCE.getValue(stack) > 0L;
            }
        };
        outputFilters = new ItemStackHandler(outputSlots) {
            @Override protected void onContentsChanged(int slot) { LinkBlockEntity.this.setChanged(); }
            @Override public int getSlotLimit(int slot) { return 1; }
            @Override public boolean isItemValid(int slot, ItemStack stack) {
                return !stack.isEmpty() && IEMCProxy.INSTANCE.getValue(ItemInfo.fromStack(stack)) > 0L;
            }
        };
    }

    public LinkBlock.Tier getTier() {
        return getBlockState().getBlock() instanceof LinkBlock link ? link.getTier() : LinkBlock.Tier.PERSONAL;
    }

    @Override public Component getDisplayName() {
        return Component.translatable(switch (getTier()) {
            case PERSONAL -> "block.projectex.personal_link";
            case REFINED -> "block.projectex.refined_link";
            case COMPRESSED_REFINED -> "block.projectex.compressed_refined_link";
        });
    }

    @Override public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        return new dev.latvian.mods.projectex.menu.LinkMenu(id, inventory, this);
    }

    /** Automation-facing handler: input slots accept items; output slots expose EMC-funded products. */
    public IItemHandler getInventory() { return automationHandler; }
    /** Real input storage used by the GUI. */
    public ItemStackHandler getInputInventory() { return inputInventory; }
    /** Persistent ghost/filter slots used by the GUI; automation output is provided separately. */
    public ItemStackHandler getOutputFilters() { return outputFilters; }
    public int getInputSlots() { return inputSlots; }
    public int getOutputSlots() { return outputSlots; }
    public UUID getOwnerId() { return owner; }
    public String getOwnerName() { return ownerName.isBlank() ? "Nenhum" : ownerName; }
    public BigInteger getStoredBigEmc() { return storedEmc; }
    public BigInteger getLastImportedEmc() { return lastImportedEmc; }
    public BigInteger getTotalImportedEmc() { return totalImportedEmc; }

    /**
     * Extract physical contents when the block is actually removed. EMC is first
     * settled to the bound owner's ProjectE knowledge so breaking the Link cannot
     * silently destroy its pending buffer.
     */
    public List<ItemStack> removeContentsForDrop() {
        List<ItemStack> drops = new ArrayList<>();
        for (int i = 0; i < inputInventory.getSlots(); i++) {
            ItemStack stack = inputInventory.extractItem(i, Integer.MAX_VALUE, false);
            if (!stack.isEmpty()) drops.add(stack);
        }
        // Output filters are ghost configuration stacks copied from the
        // player's cursor, not physical inventory. Dropping them would dupe items.

        if (storedEmc.signum() > 0) {
            IKnowledgeProvider knowledge = getOwnerKnowledge();
            if (knowledge != null) {
                knowledge.setEmc(knowledge.getEmc().add(storedEmc));
                ServerPlayer onlineOwner = getOnlineOwner();
                if (onlineOwner != null) knowledge.syncEmc(onlineOwner);
                storedEmc = ZERO;
            }
        }
        setChanged();
        return drops;
    }

    /**
     * Configures a ghost output filter. Mirrors the classic Link behavior:
     * the cursor stack is copied (not consumed) and its EMC item is learned
     * by the Link owner so that the product can be requested later.
     */
    public boolean setOutputFilter(int outputIndex, ItemStack candidate, Player actor) {
        if (outputIndex < 0 || outputIndex >= outputSlots || candidate.isEmpty()
                || level == null || !owner.equals(actor.getUUID())) {
            return false;
        }

        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(candidate));
        if (info == null || IEMCProxy.INSTANCE.getValue(info) <= 0L) return false;

        if (level.isClientSide) {
            ItemStack filter = info.createStack();
            filter.setCount(1);
            outputFilters.setStackInSlot(outputIndex, filter);
            return true;
        }

        IKnowledgeProvider knowledge = getOwnerKnowledge();
        if (knowledge == null) return false;
        boolean learned = knowledge.addKnowledge(info);
        ServerPlayer onlineOwner = getOnlineOwner();
        if (learned && onlineOwner != null) {
            knowledge.syncKnowledgeChange(onlineOwner, info, true);
        }

        ItemStack filter = info.createStack();
        filter.setCount(1);
        outputFilters.setStackInSlot(outputIndex, filter);
        setChanged();
        return true;
    }

    /** Clears a ghost output filter; it never returns an item because the cursor stack was copied. */
    public boolean clearOutputFilter(int outputIndex, Player actor) {
        if (outputIndex < 0 || outputIndex >= outputSlots || level == null
                || !owner.equals(actor.getUUID())) {
            return false;
        }
        if (!level.isClientSide) {
            outputFilters.setStackInSlot(outputIndex, ItemStack.EMPTY);
            setChanged();
        }
        return true;
    }

    public void setOwner(Player player) {
        if (owner.equals(Util.NIL_UUID)) {
            owner = player.getUUID();
            ownerName = player.getGameProfile().getName();
            setChanged();
        }
    }

    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : Util.NIL_UUID;
        ownerName = tag.getString("OwnerName");
        tickCounter = Math.max(0, tag.getInt("Tick"));
        storedEmc = readBig(tag, "StoredEMC");
        lastImportedEmc = readBig(tag, "LastImportedEMC");
        totalImportedEmc = readBig(tag, "TotalImportedEMC");

        // New split inventories, with backward compatibility for Alpha 0.8.21's combined handler.
        if (tag.contains("InputInventory")) {
            inputInventory.deserializeNBT(registries, tag.getCompound("InputInventory"));
        }
        if (tag.contains("OutputFilters")) {
            outputFilters.deserializeNBT(registries, tag.getCompound("OutputFilters"));
        }
        if (tag.contains("Inventory") && !tag.contains("InputInventory")) {
            ItemStackHandler legacy = new ItemStackHandler(inputSlots + outputSlots);
            legacy.deserializeNBT(registries, tag.getCompound("Inventory"));
            for (int i = 0; i < inputSlots; i++) inputInventory.setStackInSlot(i, legacy.getStackInSlot(i));
            for (int i = 0; i < outputSlots; i++) {
                ItemStack filter = legacy.getStackInSlot(inputSlots + i);
                if (!filter.isEmpty()) outputFilters.setStackInSlot(i, filter.copyWithCount(1));
            }
        }
    }

    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putUUID("Owner", owner);
        tag.putString("OwnerName", ownerName);
        tag.putInt("Tick", tickCounter);
        tag.putString("StoredEMC", storedEmc.toString());
        tag.putString("LastImportedEMC", lastImportedEmc.toString());
        tag.putString("TotalImportedEMC", totalImportedEmc.toString());
        tag.put("InputInventory", inputInventory.serializeNBT(registries));
        tag.put("OutputFilters", outputFilters.serializeNBT(registries));
    }

    private static BigInteger readBig(CompoundTag tag, String key) {
        try {
            BigInteger value = new BigInteger(tag.getString(key).isBlank() ? "0" : tag.getString(key));
            return value.signum() < 0 ? ZERO : value;
        } catch (RuntimeException ignored) {
            return ZERO;
        }
    }

    private IKnowledgeProvider getOwnerKnowledge() {
        if (owner.equals(Util.NIL_UUID)) return null;
        try {
            return ITransmutationProxy.INSTANCE.getKnowledgeProviderFor(owner);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private ServerPlayer getOnlineOwner() {
        return level == null || level.getServer() == null || owner.equals(Util.NIL_UUID)
                ? null : level.getServer().getPlayerList().getPlayer(owner);
    }

    /** Server-authoritative import and EMC delivery; works with the UUID-backed provider when the owner is offline. */
    public void tickServer() {
        if (level == null || level.isClientSide || level.getServer() == null) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;
        if (owner.equals(Util.NIL_UUID)) return;

        IKnowledgeProvider knowledge = getOwnerKnowledge();
        if (knowledge == null) return;
        ServerPlayer onlineOwner = getOnlineOwner();

        boolean knowledgeChanged = processInputs(knowledge, onlineOwner);
        if (storedEmc.signum() > 0) {
            BigInteger transfer = storedEmc;
            knowledge.setEmc(knowledge.getEmc().add(transfer));
            storedEmc = ZERO;
            setChanged();
            if (onlineOwner != null) knowledge.syncEmc(onlineOwner);
        } else if (knowledgeChanged && onlineOwner != null) {
            knowledge.syncEmc(onlineOwner);
        }
    }

    /**
     * Mirrors the original ContainerLink quick-move path: a shift-clicked
     * EMC item is learned, added to the first free output filter (if any),
     * and converted into the owner's buffered EMC. The source stack is only
     * consumed after this method succeeds.
     */
    public boolean importPlayerStack(ItemStack stack, Player actor) {
        if (stack.isEmpty() || level == null || level.isClientSide
                || !owner.equals(actor.getUUID())) {
            return false;
        }

        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(stack));
        if (info == null) return false;
        long unitEmc = IEMCProxy.INSTANCE.getValue(info);
        if (unitEmc <= 0L) return false;

        BigInteger imported = calculatePersonalImportEmc(unitEmc, stack.getCount());
        if (imported.signum() <= 0) return false;

        IKnowledgeProvider knowledge = getOwnerKnowledge();
        if (knowledge == null) return false;

        boolean learned = knowledge.addKnowledge(info);
        ServerPlayer onlineOwner = getOnlineOwner();
        if (learned && onlineOwner != null) {
            knowledge.syncKnowledgeChange(onlineOwner, info, true);
        }

        // Original Link quick-move automatically adds a newly learned item to
        // the first available product filter, unless it is already configured.
        boolean alreadyConfigured = false;
        for (int i = 0; i < outputSlots; i++) {
            ItemStack current = outputFilters.getStackInSlot(i);
            if (!current.isEmpty() && ItemInfo.fromStack(current).equals(info)) {
                alreadyConfigured = true;
                break;
            }
        }
        if (!alreadyConfigured) {
            for (int i = 0; i < outputSlots; i++) {
                if (outputFilters.getStackInSlot(i).isEmpty()) {
                    ItemStack filter = info.createStack();
                    filter.setCount(1);
                    outputFilters.setStackInSlot(i, filter);
                    break;
                }
            }
        }

        storedEmc = storedEmc.add(imported);
        lastImportedEmc = imported;
        totalImportedEmc = totalImportedEmc.add(imported);
        setChanged();
        return true;
    }

    private static BigInteger calculatePersonalImportEmc(long unitEmc, int count) {
        BigInteger nominal = BigInteger.valueOf(unitEmc).multiply(BigInteger.valueOf(count));
        double covalenceLoss = ProjectEConfig.server.difficulty.covalenceLoss.get();
        return new BigDecimal(nominal)
                .multiply(BigDecimal.valueOf(covalenceLoss))
                .setScale(0, RoundingMode.DOWN)
                .toBigInteger();
    }

    private boolean processInputs(IKnowledgeProvider knowledge, ServerPlayer onlineOwner) {
        boolean knowledgeChanged = false;
        boolean inventoryChanged = false;
        BigInteger importedThisCycle = ZERO;

        for (int slot = 0; slot < inputSlots; slot++) {
            ItemStack stack = inputInventory.getStackInSlot(slot);
            if (stack.isEmpty()) continue;

            ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(stack));
            if (info == null) continue;
            long unitEmc = IEMCProxy.INSTANCE.getValue(info);
            if (unitEmc <= 0L) continue; // Never consume items without a valid EMC value.

            int count = stack.getCount();
            if (getTier() == LinkBlock.Tier.PERSONAL) {
                BigInteger imported = calculatePersonalImportEmc(unitEmc, count);
                if (imported.signum() <= 0) {
                    // A zero covalence multiplier must not silently void an item.
                    continue;
                }
                storedEmc = storedEmc.add(imported);
                importedThisCycle = importedThisCycle.add(imported);
            } else {
                boolean learned = knowledge.addKnowledge(info);
                if (learned) {
                    knowledgeChanged = true;
                    if (onlineOwner != null) knowledge.syncKnowledgeChange(onlineOwner, info, true);
                }
            }

            inputInventory.setStackInSlot(slot, ItemStack.EMPTY);
            inventoryChanged = true;
        }

        if (importedThisCycle.signum() > 0) {
            lastImportedEmc = importedThisCycle;
            totalImportedEmc = totalImportedEmc.add(importedThisCycle);
            setChanged();
        } else if (inventoryChanged) {
            lastImportedEmc = ZERO;
            setChanged();
        }
        return knowledgeChanged;
    }

    /** Returns the currently affordable amount for an output filter without charging EMC. */
    public ItemStack getAvailableOutput(int outputIndex) {
        if (outputIndex < 0 || outputIndex >= outputSlots) return ItemStack.EMPTY;
        ItemStack filter = outputFilters.getStackInSlot(outputIndex);
        if (filter.isEmpty()) return ItemStack.EMPTY;
        IKnowledgeProvider knowledge = getOwnerKnowledge();
        if (knowledge == null) return ItemStack.EMPTY;
        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(filter));
        if (info == null || !knowledge.hasKnowledge(info)) return ItemStack.EMPTY;
        long unit = IEMCProxy.INSTANCE.getValue(info);
        if (unit <= 0L) return ItemStack.EMPTY;
        BigInteger affordable = knowledge.getEmc().divide(BigInteger.valueOf(unit));
        int count = affordable.min(BigInteger.valueOf(MAX_AUTOMATION_OUTPUT)).intValue();
        if (count <= 0) return ItemStack.EMPTY;
        ItemStack output = info.createStack();
        output.setCount(count);
        return output;
    }

    /** Charges the owner's EMC and extracts a configured output. Used by the GUI and automation handler. */
    public ItemStack extractConfiguredOutput(int outputIndex, int requested, boolean simulate) {
        if (requested <= 0 || outputIndex < 0 || outputIndex >= outputSlots || level == null || level.isClientSide) {
            return ItemStack.EMPTY;
        }
        ItemStack available = getAvailableOutput(outputIndex);
        if (available.isEmpty()) return ItemStack.EMPTY;
        int count = Math.min(requested, Math.min(available.getCount(), available.getMaxStackSize()));
        ItemStack result = available.copyWithCount(count);
        if (simulate) return result;

        IKnowledgeProvider knowledge = getOwnerKnowledge();
        if (knowledge == null) return ItemStack.EMPTY;
        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(result));
        if (info == null) return ItemStack.EMPTY;
        long unit = IEMCProxy.INSTANCE.getValue(info);
        if (unit <= 0L) return ItemStack.EMPTY;
        BigInteger cost = BigInteger.valueOf(unit).multiply(BigInteger.valueOf(count));
        BigInteger balance = knowledge.getEmc();
        if (balance.compareTo(cost) < 0) {
            // Recalculate once in case another machine spent EMC during this tick.
            return ItemStack.EMPTY;
        }
        knowledge.setEmc(balance.subtract(cost));
        ServerPlayer onlineOwner = getOnlineOwner();
        if (onlineOwner != null) knowledge.syncEmc(onlineOwner);
        return result;
    }

    // Match the classic Link's sink-only EMC capability: external ProjectE
    // producers may insert EMC, but another pipe/machine cannot drain the
    // owner's pending delivery before the Link's server tick credits it.
    @Override public long getStoredEmc() { return 0L; }
    @Override public long getMaximumEmc() { return Long.MAX_VALUE; }
    @Override public long extractEmc(long amount, EmcAction action) { return 0L; }
    @Override public long insertEmc(long amount, EmcAction action) {
        if (amount <= 0) return 0;
        if (action.execute()) {
            storedEmc = storedEmc.add(BigInteger.valueOf(amount));
            setChanged();
        }
        return amount;
    }

    private final class LinkAutomationHandler implements IItemHandler {
        @Override public int getSlots() { return inputSlots + outputSlots; }

        @Override public ItemStack getStackInSlot(int slot) {
            if (slot < 0 || slot >= getSlots()) return ItemStack.EMPTY;
            return slot < inputSlots ? inputInventory.getStackInSlot(slot) : getAvailableOutput(slot - inputSlots);
        }

        @Override public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            if (slot < 0 || slot >= getSlots() || stack.isEmpty()) return stack;
            if (slot < inputSlots) return inputInventory.insertItem(slot, stack, simulate);
            // Output positions are virtual products backed by EMC, never physical insertion slots.
            return stack;
        }

        @Override public ItemStack extractItem(int slot, int amount, boolean simulate) {
            if (slot < 0 || slot >= getSlots() || amount <= 0) return ItemStack.EMPTY;
            return slot < inputSlots
                    ? inputInventory.extractItem(slot, amount, simulate)
                    : extractConfiguredOutput(slot - inputSlots, amount, simulate);
        }

        @Override public int getSlotLimit(int slot) {
            if (slot < 0 || slot >= getSlots()) return 0;
            return slot < inputSlots ? inputInventory.getSlotLimit(slot) : MAX_AUTOMATION_OUTPUT;
        }

        @Override public boolean isItemValid(int slot, ItemStack stack) {
            if (slot < 0 || slot >= getSlots() || stack.isEmpty()) return false;
            return slot < inputSlots && inputInventory.isItemValid(slot, stack);
        }
    }
}
