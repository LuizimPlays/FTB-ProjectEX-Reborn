package dev.latvian.mods.projectex.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/** Button action from the Stone Table screen. Item target is revalidated against server knowledge. */
public record StoneTableActionPayload(int menuId, int action, ItemStack target) implements CustomPacketPayload {
    public static final Type<StoneTableActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("projectex", "stone_table_action"));
    public static final StreamCodec<RegistryFriendlyByteBuf, StoneTableActionPayload> STREAM_CODEC = StreamCodec.of(
            (buf, payload) -> {
                buf.writeVarInt(payload.menuId());
                buf.writeVarInt(payload.action());
                ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, payload.target());
            },
            buf -> new StoneTableActionPayload(buf.readVarInt(), buf.readVarInt(), ItemStack.OPTIONAL_STREAM_CODEC.decode(buf))
    );

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
