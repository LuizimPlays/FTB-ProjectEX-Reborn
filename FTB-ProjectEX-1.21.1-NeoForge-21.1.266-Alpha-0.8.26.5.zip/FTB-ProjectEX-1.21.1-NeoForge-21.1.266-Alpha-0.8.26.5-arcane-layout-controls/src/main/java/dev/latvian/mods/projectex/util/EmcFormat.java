package dev.latvian.mods.projectex.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Human-readable EMC values for machine status readouts. */
public final class EmcFormat {
    private static final String[] SUFFIXES = {"", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No"};
    private EmcFormat() {}

    public static String format(long value) {
        if (value < 1_000L) return Long.toString(value);
        double amount = value;
        int tier = 0;
        while (amount >= 1_000D && tier < SUFFIXES.length - 1) {
            amount /= 1_000D;
            tier++;
        }
        DecimalFormat format = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
        return format.format(amount) + SUFFIXES[tier];
    }

    public static String format(java.math.BigInteger value) {
        if (value.signum() < 0) return "-" + format(value.negate());
        if (value.bitLength() < 63) return format(value.longValue());
        java.math.BigDecimal amount = new java.math.BigDecimal(value);
        java.math.BigDecimal thousand = java.math.BigDecimal.valueOf(1_000L);
        int tier = 0;
        while (amount.compareTo(thousand) >= 0 && tier < SUFFIXES.length - 1) {
            amount = amount.divide(thousand, 2, java.math.RoundingMode.DOWN);
            tier++;
        }
        return amount.stripTrailingZeros().toPlainString() + SUFFIXES[tier];
    }
}
