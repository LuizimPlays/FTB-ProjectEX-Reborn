package dev.latvian.mods.projectex.menu;

import dev.latvian.mods.projectex.block.LinkBlock;
import dev.latvian.mods.projectex.block.entity.LinkBlockEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.SlotItemHandler;

/** Shared tier-aware EMC Link menu. Output slots are persistent item filters. */
public final class LinkMenu extends AbstractContainerMenu {
    private final LinkBlockEntity link;
    private final ContainerLevelAccess access;
    private final int inputSlots;
    private final int outputSlots;
    private final int machineSlots;
    private final int inventoryTop;
    private final int screenWidth;
    private final int screenHeight;

    public LinkMenu(int id, Inventory playerInventory, LinkBlockEntity link) {
        super(ProjectEXMenus.LINK.get(), id);
        this.link = link;
        this.access = ContainerLevelAccess.create(link.getLevel(), link.getBlockPos());
        this.inputSlots = link.getInputSlots();
        this.outputSlots = link.getOutputSlots();
        this.machineSlots = inputSlots + outputSlots;

        LinkBlock.Tier tier = link.getTier();
        int hotbarTop;
        if (tier == LinkBlock.Tier.PERSONAL) {
            screenWidth = 176;
            screenHeight = 166;
            inventoryTop = 84;
            hotbarTop = 142;
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 6; col++) {
                    int index = row * 6 + col;
                    addSlot(new SlotItemHandler(link.getInputInventory(), index, 8 + col * 18, 16 + row * 18));
                }
            }
            addOutputFilterSlot(0, 152, 34);
        } else if (tier == LinkBlock.Tier.REFINED) {
            screenWidth = 176;
            screenHeight = 166;
            inventoryTop = 84;
            hotbarTop = 142;
            addSlot(new SlotItemHandler(link.getInputInventory(), 0, 34, 34));
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    addOutputFilterSlot(row * 3 + col, 88 + col * 18, 16 + row * 18);
                }
            }
        } else {
            screenWidth = 176;
            screenHeight = 244;
            inventoryTop = 162;
            hotbarTop = 220;
            addSlot(new SlotItemHandler(link.getInputInventory(), 0, 8, 16));
            for (int row = 0; row < 6; row++) {
                for (int col = 0; col < 9; col++) {
                    addOutputFilterSlot(row * 9 + col, 8 + col * 18, 40 + row * 18);
                }
            }
        }

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, 9 + row * 9 + col,
                        8 + col * 18, inventoryTop + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, hotbarTop));
        }
    }

    private void addOutputFilterSlot(int index, int x, int y) {
        addSlot(new SlotItemHandler(link.getOutputFilters(), index, x, y) {
            @Override public boolean mayPlace(ItemStack stack) {
                return !stack.isEmpty() && moze_intel.projecte.api.proxy.IEMCProxy.INSTANCE.getValue(stack) > 0L;
            }
            @Override public boolean mayPickup(Player player) { return false; }
            @Override public int getMaxStackSize() { return 1; }
        });
    }

    public LinkBlockEntity getLink() { return link; }
    public int getInputSlotCount() { return inputSlots; }
    public int getOutputSlotCount() { return outputSlots; }
    public int getMachineSlotCount() { return machineSlots; }
    public int getInventoryTop() { return inventoryTop; }
    public int getScreenWidth() { return screenWidth; }
    public int getScreenHeight() { return screenHeight; }

    @Override public void clicked(int slotId, int button, ClickType clickType, Player player) {
        if (!player.getUUID().equals(link.getOwnerId())) return;
        if (slotId >= inputSlots && slotId < machineSlots) {
            int outputIndex = slotId - inputSlots;

            // Output slots are ghost filters in the classic ProjectEX design.
            // Clicking with a carried item copies it as the requested product;
            // the cursor is deliberately not consumed.
            if (clickType == ClickType.PICKUP && !getCarried().isEmpty()) {
                link.setOutputFilter(outputIndex, getCarried(), player);
                return;
            }

            // Shift-click clears a filter. The filter is configuration, not a
            // physical item, so clearing it must never return/drop a duplicate.
            if (clickType == ClickType.QUICK_MOVE) {
                link.clearOutputFilter(outputIndex, player);
                return;
            }

            // Normal left click requests a stack; right click requests one.
            // Middle-click (CLONE) also requests one, matching the old filter buttons.
            if ((clickType == ClickType.PICKUP || clickType == ClickType.CLONE)
                    && getCarried().isEmpty()) {
                if (!player.level().isClientSide) {
                    int requested = (button == 1 || clickType == ClickType.CLONE) ? 1 : 64;
                    ItemStack crafted = link.extractConfiguredOutput(outputIndex, requested, false);
                    if (!crafted.isEmpty()) setCarried(crafted);
                }
                return;
            }
            return;
        }
        super.clicked(slotId, button, clickType, player);
    }

    private void clearOutputFilter(int outputIndex, Player player) {
        link.clearOutputFilter(outputIndex, player);
    }

    @Override public ItemStack quickMoveStack(Player player, int index) {
        if (index < 0 || index >= slots.size()) return ItemStack.EMPTY;

        if (index >= inputSlots && index < machineSlots) {
            // Output entries are ghost filters: shift-click clears configuration only.
            if (!player.level().isClientSide) clearOutputFilter(index - inputSlots, player);
            return ItemStack.EMPTY;
        }

        Slot sourceSlot = slots.get(index);
        if (!sourceSlot.hasItem()) return ItemStack.EMPTY;
        ItemStack sourceStack = sourceSlot.getItem();
        ItemStack originalStack = sourceStack.copy();

        // The 1.12.2 ContainerLink converted a shift-clicked EMC-valued stack
        // directly into knowledge + stored EMC, whether it came from a Link
        // input slot or the player's inventory. Non-EMC items remain untouched.
        if (player.level().isClientSide) {
            return ItemStack.EMPTY; // Server response performs the authoritative mutation.
        }
        if (!link.importPlayerStack(sourceStack, player)) {
            return ItemStack.EMPTY;
        }

        sourceSlot.set(ItemStack.EMPTY);
        sourceSlot.setChanged();
        sourceSlot.onTake(player, sourceStack);
        return originalStack;
    }

    @Override public boolean stillValid(Player player) {
        return player.getUUID().equals(link.getOwnerId())
                && stillValid(access, player, link.getBlockState().getBlock());
    }
}
