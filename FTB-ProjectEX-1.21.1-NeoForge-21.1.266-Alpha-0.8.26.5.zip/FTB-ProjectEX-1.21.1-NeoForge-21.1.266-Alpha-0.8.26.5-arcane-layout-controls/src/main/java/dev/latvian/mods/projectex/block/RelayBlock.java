package dev.latvian.mods.projectex.block;

import dev.latvian.mods.projectex.Matter;
import dev.latvian.mods.projectex.block.entity.ProjectEXBlockEntities;
import dev.latvian.mods.projectex.block.entity.RelayBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;

public final class RelayBlock extends Block implements EntityBlock {
    public final Matter matter;
    public RelayBlock(Matter matter) {
        super(BlockBehaviour.Properties.of().strength(5.0F).sound(SoundType.STONE));
        this.matter = matter;
    }
    /**
     * Subtle client-side transfer effect. EMC remains entirely server-authoritative.
     */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(5) != 0) return;
        double x = pos.getX() + 0.25D + random.nextDouble() * 0.5D;
        double y = pos.getY() + 0.25D + random.nextDouble() * 0.5D;
        double z = pos.getZ() + 0.25D + random.nextDouble() * 0.5D;
        level.addParticle(ParticleTypes.PORTAL, x, y, z,
                (random.nextDouble() - 0.5D) * 0.04D,
                (random.nextDouble() - 0.5D) * 0.04D,
                (random.nextDouble() - 0.5D) * 0.04D);
    }

    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RelayBlockEntity(pos, state);
    }
    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != ProjectEXBlockEntities.RELAY.get() || level.isClientSide) return null;
        return (lvl, pos, blockState, be) -> {
            if (be instanceof RelayBlockEntity relay) relay.tickServer();
        };
    }
    @Override
    public net.minecraft.world.InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, net.minecraft.world.entity.player.Player player, net.minecraft.world.phys.BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof RelayBlockEntity machine) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "§5Anti-Matter Relay " + matter.getMK() + "\n§eArmazenado: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getStoredEmc()) + " EMC\n§bTransferência máxima: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getTransferPerSecond()) + " EMC/s\n§dBônus por pulso: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getBonusPerCollectorPulse()) + " EMC"
                    + "\n§aTransferido no último ciclo: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getLastTransferred()) + " EMC"
                    + "\n§7Total transferido: §f" + dev.latvian.mods.projectex.util.EmcFormat.format(machine.getTotalTransferred()) + " EMC"), false);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

}
