package dev.latvian.mods.projectex.alchemy;

import moze_intel.projecte.gameObjs.registries.PEItems;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Default recipe chains ported from the original ProjectEX 1.12.2 AlchemyTableRecipes. */
public final class AlchemyTableRecipes {
    private static final List<AlchemyTableRecipe> RECIPES = new ArrayList<>();
    private static boolean initialized;

    private AlchemyTableRecipes() {}

    public static synchronized void initializeDefaults() {
        if (initialized) return;
        initialized = true;

        addSteps(stack(Items.CHARCOAL), stack(Items.COAL));
        addSteps(stack(Items.REDSTONE), stack(Items.GUNPOWDER), stack(Items.GLOWSTONE_DUST),
                stack(Items.BLAZE_POWDER), stack(Items.BLAZE_ROD));
        addSteps(stack(Items.LAPIS_LAZULI), stack(Items.PRISMARINE_SHARD), stack(Items.PRISMARINE_CRYSTALS));
        addSteps(stack(PEItems.LOW_COVALENCE_DUST.get()), stack(PEItems.MEDIUM_COVALENCE_DUST.get()),
                stack(PEItems.HIGH_COVALENCE_DUST.get()));
        addSteps(stack(Items.BEEF), stack(Items.ROTTEN_FLESH), stack(Items.LEATHER),
                stack(Items.SPIDER_EYE), stack(Items.BONE));
        addSteps(stack(Items.WHEAT_SEEDS), stack(Items.MELON), stack(Items.APPLE), stack(Items.CARROT),
                stack(Items.BEETROOT), stack(Items.POTATO), stack(Blocks.PUMPKIN.asItem()));
        addSteps(stack(Items.COOKIE), stack(Items.BREAD), stack(Items.CAKE));
        addSteps(stack(PEItems.ALCHEMICAL_COAL.get()), stack(Blocks.REDSTONE_BLOCK.asItem()),
                stack(Items.LAVA_BUCKET), stack(Blocks.OBSIDIAN.asItem()));
        addSteps(stack(Blocks.OAK_LEAVES.asItem()), stack(Blocks.SHORT_GRASS.asItem()),
                stack(Blocks.FERN.asItem()), stack(Blocks.VINE.asItem()), stack(Items.LILY_PAD));
        add(stack(Items.ENDER_EYE), stack(Items.CHORUS_FRUIT));
        add(stack(Items.STRING), stack(Items.FEATHER));
        add(stack(Items.STICK), stack(Blocks.DEAD_BUSH.asItem()));
    }

    public static synchronized void add(ItemStack input, ItemStack output) {
        RECIPES.removeIf(recipe -> recipe.matches(input));
        RECIPES.add(new AlchemyTableRecipe(input, output));
    }

    public static synchronized void add(AlchemyTableRecipe recipe) {
        RECIPES.removeIf(existing -> existing.matches(recipe.input()));
        RECIPES.add(recipe);
    }

    public static synchronized void addSteps(ItemStack... stacks) {
        for (int i = 1; i < stacks.length; i++) add(stacks[i - 1], stacks[i]);
    }

    public static synchronized AlchemyTableRecipe getOutput(ItemStack input) {
        if (input.isEmpty()) return null;
        for (AlchemyTableRecipe recipe : RECIPES) {
            if (recipe.matches(input)) return recipe;
        }
        return null;
    }

    public static synchronized boolean hasOutput(ItemStack input) {
        return getOutput(input) != null;
    }

    public static synchronized List<AlchemyTableRecipe> all() {
        return Collections.unmodifiableList(new ArrayList<>(RECIPES));
    }

    private static ItemStack stack(net.minecraft.world.level.ItemLike item) {
        return new ItemStack(item);
    }
}
