package dev.latvian.mods.projectex.crafting;

import moze_intel.projecte.gameObjs.container.TransmutationContainer;
import moze_intel.projecte.api.ItemInfo;
import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.api.proxy.IEMCProxy;
import moze_intel.projecte.api.event.PlayerAttemptLearnEvent;
import moze_intel.projecte.config.ProjectEConfig;
import moze_intel.projecte.api.capabilities.item.IItemEmcHolder;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage.EmcAction;
import net.neoforged.neoforge.common.NeoForge;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerListener;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;
import java.math.BigInteger;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Server-authoritative 3x3 crafting attachment for the ProjectEX Arcane Tablet.
 * It deliberately reuses ProjectE's TransmutationContainer so ProjectE's EMC,
 * knowledge, search, transmutation and paging remain authoritative and compatible.
 */
public final class ArcaneCraftingSupport {
    private static final Map<TransmutationContainer, CraftingState> STATES =
            Collections.synchronizedMap(new WeakHashMap<>());

    // Original 1.12.2 Arcane Tablet layout: the crafting extension is
    // rendered to the LEFT of the 176x217 transmutation panel.
    private static final int GRID_X = -59;
    private static final int GRID_Y = 17;
    private static final int RESULT_X = -23;
    private static final int RESULT_Y = 75;

    public static final int ACTION_CLEAR = 40;
    public static final int ACTION_ROTATE_CW = 41;
    public static final int ACTION_ROTATE_CCW = 42;
    public static final int ACTION_BALANCE = 43;
    public static final int ACTION_SPREAD = 44;
    public static final int ACTION_BURN = 1;
    public static final int ACTION_BURN_OR_TRANSFER = 4;
    public static final int ACTION_LEARN = 5;
    public static final int ACTION_UNLEARN = 6;
    private static final int[] ROTATION_SLOTS = {0, 1, 2, 5, 8, 7, 6, 3};
    private static final Method ADD_SLOT = resolveAddSlot();

    private ArcaneCraftingSupport() {}

    /*
     * TransmutationContainer overrides AbstractContainerMenu.addSlot with
     * protected visibility. This helper is outside that inheritance chain,
     * so direct calls do not compile. Reflection is confined to this one
     * compatibility boundary; the normal menu slot registration path still
     * runs and keeps slot indices and menu synchronization lists consistent.
     */
    private static Method resolveAddSlot() {
        try {
            Method method = AbstractContainerMenu.class.getDeclaredMethod("addSlot", Slot.class);
            method.setAccessible(true);
            return method;
        } catch (ReflectiveOperationException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private static void registerSlot(TransmutationContainer menu, Slot slot) {
        try {
            ADD_SLOT.invoke(menu, slot);
        } catch (IllegalAccessException | InvocationTargetException exception) {
            throw new IllegalStateException("Unable to register Arcane Tablet crafting slot", exception);
        }
    }

    public static CraftingState attach(TransmutationContainer menu, Player player) {
        synchronized (STATES) {
            CraftingState existing = STATES.get(menu);
            if (existing != null) return existing;

            CraftingState state = new CraftingState(menu, player, menu.slots.size());
            STATES.put(menu, state);
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    int index = row * 3 + col;
                    registerSlot(menu, new Slot(state.grid, index,
                            GRID_X + col * 18, GRID_Y + row * 18));
                }
            }
            registerSlot(menu, new Slot(state.result, 0, RESULT_X, RESULT_Y) {
                @Override public boolean mayPlace(ItemStack stack) { return false; }
                @Override public boolean mayPickup(Player player) {
                    return !state.result.getItem(0).isEmpty();
                }
                // A recipe producing multiple items is removed as one result
                // stack. Right-clicking one item must not consume only one
                // ingredient batch and leave free output behind.
                @Override public ItemStack remove(int amount) {
                    ItemStack current = state.result.getItem(0);
                    if (current.isEmpty() || amount < current.getCount()) return ItemStack.EMPTY;
                    return state.result.removeItem(0, current.getCount());
                }
                @Override public void onTake(Player player, ItemStack stack) {
                    super.onTake(player, stack);
                    if (!player.level().isClientSide && state.result.getItem(0).isEmpty()) {
                        state.consumeOneRecipe(player, stack);
                    }
                }
            });
            state.recomputeResult();
            return state;
        }
    }

    public static boolean isCraftingSlot(TransmutationContainer menu, Slot slot) {
        CraftingState state = STATES.get(menu);
        if (state == null || slot == null) return false;
        int index = menu.slots.indexOf(slot);
        return index >= state.firstSlot && index < state.firstSlot + 10;
    }

    public static boolean isResultSlot(TransmutationContainer menu, Slot slot) {
        CraftingState state = STATES.get(menu);
        return state != null && slot != null && menu.slots.indexOf(slot) == state.firstSlot + 9;
    }

    /** Execute Arcane Tablet controls on the server after validating the open menu. */
    public static boolean performAction(TransmutationContainer menu, ServerPlayer player, int action) {
        CraftingState state = STATES.get(menu);
        if (state == null) return false;
        IKnowledgeProvider knowledge = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge == null) return false;

        boolean changed = switch (action) {
            case ACTION_ROTATE_CW -> { state.rotate(true); yield true; }
            case ACTION_ROTATE_CCW -> { state.rotate(false); yield true; }
            case ACTION_BALANCE -> { state.balance(); yield true; }
            case ACTION_SPREAD -> { state.spread(); yield true; }
            case ACTION_CLEAR -> { state.clear(player, knowledge); yield true; }
            case ACTION_LEARN -> learnCarried(player, knowledge);
            case ACTION_UNLEARN -> unlearnCarried(player, knowledge);
            case ACTION_BURN -> burnCarried(player, knowledge, false);
            case ACTION_BURN_OR_TRANSFER -> burnCarried(player, knowledge, true);
            default -> false;
        };
        if (changed) {
            state.grid.setChanged();
            state.recomputeResult();
            menu.broadcastChanges();
        }
        return changed;
    }

    private static boolean learnCarried(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty() || !IEMCProxy.INSTANCE.hasValue(carried)) return false;
        ItemInfo source = ItemInfo.fromStack(carried.copyWithCount(1));
        ItemInfo persistent = IEMCProxy.INSTANCE.getPersistentInfo(source);
        if (persistent == null) persistent = source;
        if (knowledge.hasKnowledge(persistent)) return true;
        PlayerAttemptLearnEvent event = new PlayerAttemptLearnEvent(player, source, persistent);
        NeoForge.EVENT_BUS.post(event);
        if (event.isCanceled()) return false;
        ItemInfo learned = event.getReducedInfo() == null ? persistent : event.getReducedInfo();
        if (!knowledge.addKnowledge(learned)) return knowledge.hasKnowledge(learned);
        knowledge.syncKnowledgeChange(player, learned, true);
        return true;
    }

    private static boolean unlearnCarried(ServerPlayer player, IKnowledgeProvider knowledge) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty()) return false;
        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(carried.copyWithCount(1)));
        if (info == null || !knowledge.removeKnowledge(info)) return false;
        knowledge.syncKnowledgeChange(player, info, false);
        return true;
    }

    private static boolean burnCarried(ServerPlayer player, IKnowledgeProvider knowledge, boolean transferEmcHolder) {
        ItemStack carried = player.containerMenu.getCarried();
        if (carried.isEmpty()) return false;
        if (transferEmcHolder) {
            IItemEmcHolder holder = PECapabilities.EMC_HOLDER_ITEM_CAPABILITY.getCapability(carried, null);
            if (holder != null) {
                long stored = Math.max(0L, holder.getStoredEmc(carried));
                if (stored > 0L) {
                    long extracted = holder.extractEmc(carried, stored, EmcAction.EXECUTE);
                    if (extracted > 0L) {
                        knowledge.setEmc(knowledge.getEmc().add(BigInteger.valueOf(extracted)));
                        knowledge.syncEmc(player);
                        player.containerMenu.setCarried(carried);
                    }
                    return extracted > 0L;
                }
                long needed = Math.max(0L, holder.getNeededEmc(carried));
                if (needed > 0L && knowledge.getEmc().signum() > 0) {
                    BigInteger amount = knowledge.getEmc().min(BigInteger.valueOf(needed));
                    long inserted = holder.insertEmc(carried, amount.min(BigInteger.valueOf(Long.MAX_VALUE)).longValue(), EmcAction.EXECUTE);
                    if (inserted > 0L) {
                        knowledge.setEmc(knowledge.getEmc().subtract(BigInteger.valueOf(inserted)));
                        knowledge.syncEmc(player);
                        player.containerMenu.setCarried(carried);
                        return true;
                    }
                }
                return false;
            }
        }
        if (!dev.latvian.mods.projectex.network.StoneTableActions.burnStack(player, knowledge, carried)) return false;
        player.containerMenu.setCarried(ItemStack.EMPTY);
        return true;
    }

    /** Return every remaining ingredient to the player when the Arcane screen closes. */
    public static void close(TransmutationContainer menu, Player player) {
        CraftingState state;
        synchronized (STATES) {
            state = STATES.remove(menu);
        }
        if (state == null || player.level().isClientSide) return;
        for (int i = 0; i < state.grid.getContainerSize(); i++) {
            ItemStack stack = state.grid.removeItemNoUpdate(i);
            if (stack.isEmpty()) continue;
            ItemStack remainder = stack.copy();
            if (!player.getInventory().add(remainder) && !remainder.isEmpty()) {
                player.drop(remainder, false);
            }
        }
        state.result.clearContent();
    }

    private static CraftingInput createInput(Container grid) {
        List<ItemStack> inputs = new ArrayList<>(9);
        for (int i = 0; i < 9; i++) inputs.add(grid.getItem(i).copy());
        return CraftingInput.of(3, 3, inputs);
    }

    private static final class CraftingState implements ContainerListener {
        private final Player player;
        private final int firstSlot;
        private final net.minecraft.world.SimpleContainer grid = new net.minecraft.world.SimpleContainer(9);
        private final net.minecraft.world.SimpleContainer result = new net.minecraft.world.SimpleContainer(1);
        private boolean suppressGridEvents;

        private CraftingState(TransmutationContainer menu, Player player, int firstSlot) {
            this.player = player;
            this.firstSlot = firstSlot;
            grid.addListener(this);
        }

        @Override public void containerChanged(Container container) {
            if (!suppressGridEvents) recomputeResult();
        }

        private void recomputeResult() {
            Level level = player.level();
            CraftingInput input = createInput(grid);
            if (input.isEmpty()) {
                result.setItem(0, ItemStack.EMPTY);
                return;
            }
            Optional<RecipeHolder<CraftingRecipe>> match = level.getRecipeManager()
                    .getRecipeFor(RecipeType.CRAFTING, input, level);
            if (match.isEmpty()) {
                result.setItem(0, ItemStack.EMPTY);
                return;
            }
            ItemStack crafted = match.get().value().assemble(input, level.registryAccess());
            result.setItem(0, crafted.isEmpty() ? ItemStack.EMPTY : crafted.copy());
        }

        private void consumeOneRecipe(Player player, ItemStack takenOutput) {
            Level level = player.level();
            CraftingInput input = createInput(grid);
            Optional<RecipeHolder<CraftingRecipe>> match = level.getRecipeManager()
                    .getRecipeFor(RecipeType.CRAFTING, input, level);
            if (match.isEmpty()) {
                recomputeResult();
                return;
            }
            CraftingRecipe recipe = match.get().value();
            ItemStack expected = recipe.assemble(input, level.registryAccess());
            if (expected.isEmpty() || !ItemStack.isSameItemSameComponents(expected, takenOutput)
                    || expected.getCount() != takenOutput.getCount()) {
                recomputeResult();
                return;
            }

            NonNullList<ItemStack> remainders = recipe.getRemainingItems(input);
            IKnowledgeProvider knowledge = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);

            // Match the original Arcane Tablet: crafting an EMC-valued result
            // teaches it to the player's ProjectE knowledge immediately.
            if (knowledge != null) {
                ItemInfo outputInfo = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(takenOutput));
                if (outputInfo != null && IEMCProxy.INSTANCE.getValue(outputInfo) > 0L
                        && knowledge.addKnowledge(outputInfo)
                        && player instanceof ServerPlayer serverPlayer) {
                    knowledge.syncKnowledgeChange(serverPlayer, outputInfo, true);
                }
            }

            BigInteger emcToSpend = BigInteger.ZERO;
            boolean gridChanged = false;
            suppressGridEvents = true;
            try {
                for (int i = 0; i < 9; i++) {
                    ItemStack ingredientBefore = grid.getItem(i).copy();
                    if (ingredientBefore.isEmpty()) continue;

                    grid.removeItem(i, 1);
                    gridChanged = true;
                    ItemStack remainder = remainders.get(i);
                    if (!remainder.isEmpty()) {
                        ItemStack inGrid = grid.getItem(i);
                        if (inGrid.isEmpty()) {
                            grid.setItem(i, remainder.copy());
                        } else if (ItemStack.isSameItemSameComponents(inGrid, remainder)
                                && inGrid.getCount() + remainder.getCount() <= inGrid.getMaxStackSize()) {
                            inGrid.grow(remainder.getCount());
                            grid.setChanged();
                        } else {
                            returnRemainder(player, remainder.copy());
                        }
                        continue;
                    }

                    // The classic Arcane Tablet buys back each ingredient that vanished
                    // from the grid, allowing the same recipe to repeat while EMC lasts.
                    if (grid.getItem(i).isEmpty() && knowledge != null) {
                        ItemInfo info = IEMCProxy.INSTANCE.getPersistentInfo(ItemInfo.fromStack(ingredientBefore));
                        if (info != null && knowledge.hasKnowledge(info)) {
                            long unitValue = IEMCProxy.INSTANCE.getValue(info);
                            if (unitValue > 0L) {
                                BigInteger cost = BigInteger.valueOf(unitValue);
                                BigInteger available = knowledge.getEmc().subtract(emcToSpend);
                                if (available.compareTo(cost) >= 0) {
                                    emcToSpend = emcToSpend.add(cost);
                                    grid.setItem(i, ingredientBefore.copyWithCount(1));
                                }
                            }
                        }
                    }
                }
            } finally {
                suppressGridEvents = false;
            }

            if (emcToSpend.signum() > 0 && knowledge != null) {
                knowledge.setEmc(knowledge.getEmc().subtract(emcToSpend));
                if (player instanceof ServerPlayer serverPlayer) knowledge.syncEmc(serverPlayer);
            }
            if (gridChanged) grid.setChanged();
            recomputeResult();
        }

        private void rotate(boolean clockwise) {
            ItemStack[] rotated = new ItemStack[ROTATION_SLOTS.length];
            for (int i = 0; i < ROTATION_SLOTS.length; i++) {
                int source = clockwise ? (i + ROTATION_SLOTS.length - 1) % ROTATION_SLOTS.length
                        : (i + 1) % ROTATION_SLOTS.length;
                rotated[i] = grid.getItem(ROTATION_SLOTS[source]).copy();
            }
            suppressGridEvents = true;
            try {
                for (int i = 0; i < ROTATION_SLOTS.length; i++) grid.setItem(ROTATION_SLOTS[i], rotated[i]);
            } finally {
                suppressGridEvents = false;
            }
            grid.setChanged();
            recomputeResult();
        }

        private void balance() {
            List<List<Integer>> groups = new ArrayList<>();
            for (int slot = 0; slot < 9; slot++) {
                ItemStack stack = grid.getItem(slot);
                if (stack.isEmpty() || stack.getMaxStackSize() <= 1) continue;
                List<Integer> group = null;
                for (List<Integer> candidate : groups) {
                    if (ItemStack.isSameItemSameComponents(grid.getItem(candidate.get(0)), stack)) {
                        group = candidate;
                        break;
                    }
                }
                if (group == null) { group = new ArrayList<>(); groups.add(group); }
                group.add(slot);
            }
            suppressGridEvents = true;
            try {
                for (List<Integer> group : groups) {
                    int total = 0;
                    for (int slot : group) total += grid.getItem(slot).getCount();
                    int each = total / group.size();
                    int remainder = total % group.size();
                    for (int slot : group) {
                        ItemStack stack = grid.getItem(slot);
                        stack.setCount(each);
                    }
                    for (int slot : group) {
                        if (remainder <= 0) break;
                        ItemStack stack = grid.getItem(slot);
                        if (stack.getCount() < stack.getMaxStackSize()) { stack.grow(1); remainder--; }
                    }
                }
            } finally {
                suppressGridEvents = false;
            }
            grid.setChanged();
            recomputeResult();
        }

        private void spread() {
            suppressGridEvents = true;
            try {
                while (true) {
                    int biggestSlot = -1;
                    int biggestCount = 1;
                    for (int slot = 0; slot < 9; slot++) {
                        ItemStack stack = grid.getItem(slot);
                        if (!stack.isEmpty() && stack.getCount() > biggestCount) {
                            biggestCount = stack.getCount();
                            biggestSlot = slot;
                        }
                    }
                    if (biggestSlot < 0) break;
                    ItemStack biggest = grid.getItem(biggestSlot);
                    boolean movedToEveryEmptySlot = true;
                    for (int slot = 0; slot < 9 && biggest.getCount() > 1; slot++) {
                        if (slot == biggestSlot || !grid.getItem(slot).isEmpty()) continue;
                        grid.setItem(slot, biggest.split(1));
                        movedToEveryEmptySlot = false;
                    }
                    if (movedToEveryEmptySlot) break;
                }
            } finally {
                suppressGridEvents = false;
            }
            grid.setChanged();
            balance();
        }

        private void clear(Player player, IKnowledgeProvider knowledge) {
            double covalenceLoss = ProjectEConfig.server.difficulty.covalenceLoss.get();
            BigInteger gained = BigInteger.ZERO;
            suppressGridEvents = true;
            try {
                for (int slot = 0; slot < 9; slot++) {
                    ItemStack stack = grid.removeItemNoUpdate(slot);
                    if (stack.isEmpty()) continue;
                    long unitValue = IEMCProxy.INSTANCE.getValue(stack);
                    boolean burn = covalenceLoss >= 1.0D && unitValue > 0L
                            && learnStack(player, knowledge, stack);
                    if (burn) {
                        gained = gained.add(BigInteger.valueOf(unitValue).multiply(BigInteger.valueOf(stack.getCount())));
                    } else {
                        returnRemainder(player, stack);
                    }
                }
            } finally {
                suppressGridEvents = false;
            }
            if (gained.signum() > 0) {
                knowledge.setEmc(knowledge.getEmc().add(gained));
                if (player instanceof ServerPlayer serverPlayer) knowledge.syncEmc(serverPlayer);
            }
            grid.setChanged();
            recomputeResult();
        }

        private static boolean learnStack(Player player, IKnowledgeProvider knowledge, ItemStack stack) {
            ItemInfo source = ItemInfo.fromStack(stack.copyWithCount(1));
            ItemInfo persistent = IEMCProxy.INSTANCE.getPersistentInfo(source);
            if (persistent == null) persistent = source;
            if (knowledge.hasKnowledge(persistent)) return true;
            PlayerAttemptLearnEvent event = new PlayerAttemptLearnEvent(player, source, persistent);
            NeoForge.EVENT_BUS.post(event);
            if (event.isCanceled()) return false;
            ItemInfo learned = event.getReducedInfo() == null ? persistent : event.getReducedInfo();
            if (!knowledge.addKnowledge(learned)) return knowledge.hasKnowledge(learned);
            if (player instanceof ServerPlayer serverPlayer) knowledge.syncKnowledgeChange(serverPlayer, learned, true);
            return true;
        }

        private static void returnRemainder(Player player, ItemStack remainder) {
            if (remainder.isEmpty()) return;
            ItemStack toReturn = remainder.copy();
            if (!player.getInventory().add(toReturn) && !toReturn.isEmpty()) {
                player.drop(toReturn, false);
            }
        }
    }
}
