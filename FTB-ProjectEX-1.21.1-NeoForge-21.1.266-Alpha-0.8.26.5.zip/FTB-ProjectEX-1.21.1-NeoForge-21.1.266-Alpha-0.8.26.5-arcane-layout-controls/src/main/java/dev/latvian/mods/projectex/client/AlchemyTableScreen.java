package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.menu.AlchemyTableMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** Classic ProjectEX Alchemy Table screen and progress/EMC bars. */
public final class AlchemyTableScreen extends AbstractContainerScreen<AlchemyTableMenu> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("projectex", "textures/gui/alchemy_table.png");

    public AlchemyTableScreen(AlchemyTableMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 166;
        titleLabelX = 8;
        titleLabelY = 6;
        inventoryLabelX = 8;
        inventoryLabelY = 72;
    }

    @Override protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);

        int emcWidth = Math.max(0, Math.min(24, menu.getEmcScaled() * 24 / 255));
        if (emcWidth > 0) {
            graphics.blit(TEXTURE, leftPos + 77, topPos + 34, 177, 17, emcWidth, 18, 256, 256);
        }

        int progressWidth = Math.max(0, Math.min(22, menu.getProgressScaled() * 22 / 255));
        if (progressWidth > 0) {
            graphics.blit(TEXTURE, leftPos + 78, topPos + 35, 177, 0, progressWidth, 16, 256, 256);
        }
    }

    @Override protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        // The original Alchemy Table GUI uses labels baked into its texture.
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
