package dev.latvian.mods.projectex.client;

import moze_intel.projecte.api.capabilities.IKnowledgeProvider;
import moze_intel.projecte.api.capabilities.PECapabilities;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import java.util.UUID;

/**
 * Classic ProjectE-style EMC HUD.
 * Shows the compact EMC balance in yellow and the live EMC rate in green.
 * While crouching, the exact balance replaces the compact balance on the same top line.
 */
@EventBusSubscriber(modid = "projectex", value = Dist.CLIENT)
public final class EmcHudOverlay {
    private static final DecimalFormat NUMBER = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));
    private static final DecimalFormat EXACT_NUMBER = new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pt-BR")));
    private static final int X = 6;
    private static final int Y = 6;
    private static final int PAD_X = 6;
    private static final int PAD_Y = 4;

    private static final int BACKGROUND = 0xA91B355B;
    private static final int SHADOW = 0x55000000;
    private static final int EDGE = 0xFF397A54;
    private static final int BALANCE_COLOR = 0xFFFFFF55;
    private static final int LABEL_COLOR = 0xFFFFFFFF;
    private static final int RATE_COLOR = 0xFF55FF55;

    private static BigInteger lastEmc;
    private static long lastSampleMs;
    private static BigInteger gainPerSecond = BigInteger.ZERO;
    private static UUID sampledPlayer;

    private EmcHudOverlay() {}

    @SubscribeEvent
    public static void onHudRender(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.options.hideGui) return;

        IKnowledgeProvider knowledge = player.getCapability(PECapabilities.KNOWLEDGE_CAPABILITY);
        if (knowledge == null) return;

        BigInteger current = knowledge.getEmc();
        updateRate(current, player.getUUID());

        GuiGraphics g = event.getGuiGraphics();
        Font font = mc.font;
        boolean expanded = player.isCrouching();

        String balanceValue = expanded ? EXACT_NUMBER.format(current) : compact(current);
        String balance = "EMC: " + balanceValue;
        String rate = (gainPerSecond.signum() > 0 ? "+" : "")
                + compact(gainPerSecond) + " EMC/s";

        int contentWidth = Math.max(font.width(balance), font.width(rate));

        int maxPanelWidth = Math.max(1, g.guiWidth() - X - 2);
        int panelWidth = Math.max(1, Math.min(maxPanelWidth, contentWidth + PAD_X * 2 + 2));
        int panelHeight = 30;

        // Familiar compact, blue translucent ProjectE-style panel.
        g.fill(X + 2, Y + 2, X + panelWidth + 2, Y + panelHeight + 2, SHADOW);
        g.fill(X, Y, X + panelWidth, Y + panelHeight, BACKGROUND);
        g.fill(X, Y, X + 3, Y + panelHeight, EDGE);

        int textX = X + PAD_X + 2;
        g.drawString(font, Component.literal("EMC:"), textX, Y + PAD_Y - 1, LABEL_COLOR, true);
        g.drawString(font, Component.literal(balanceValue), textX + font.width("EMC: "),
                Y + PAD_Y - 1, BALANCE_COLOR, true);
        g.drawString(font, Component.literal(rate), textX, Y + PAD_Y + 10,
                RATE_COLOR, true);
    }

    private static void updateRate(BigInteger current, UUID playerId) {
        long now = System.currentTimeMillis();
        if (lastEmc == null || !playerId.equals(sampledPlayer)) {
            lastEmc = current;
            lastSampleMs = now;
            gainPerSecond = BigInteger.ZERO;
            sampledPlayer = playerId;
            return;
        }

        long elapsed = now - lastSampleMs;
        if (elapsed >= 1000L) {
            BigInteger change = current.subtract(lastEmc);
            gainPerSecond = change.multiply(BigInteger.valueOf(1000L))
                    .divide(BigInteger.valueOf(elapsed));
            lastEmc = current;
            lastSampleMs = now;
        }
    }

    private static String compact(BigInteger value) {
        if (value == null) return "0";
        BigInteger abs = value.abs();
        String[] suffix = {"", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No"};
        BigInteger thousand = BigInteger.valueOf(1000);
        int tier = 0;
        BigInteger scaled = abs;
        while (scaled.compareTo(thousand) >= 0 && tier < suffix.length - 1) {
            scaled = scaled.divide(thousand);
            tier++;
        }
        double amount = abs.doubleValue();
        for (int i = 0; i < tier; i++) amount /= 1000.0;
        return (value.signum() < 0 ? "-" : "") + NUMBER.format(amount) + suffix[tier];
    }
}
