package dev.latvian.mods.projectex.block.entity;

import dev.latvian.mods.projectex.block.CollectorBlock;
import moze_intel.projecte.api.capabilities.PECapabilities;
import moze_intel.projecte.gameObjs.block_entities.RelayMK1BlockEntity;
import moze_intel.projecte.api.capabilities.block_entity.IEmcStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

public final class CollectorBlockEntity extends BlockEntity implements IEmcStorage {
    private int tickCounter;
    private long storedEmc;
    private long lastDistributed;
    private long totalDistributed;
    public CollectorBlockEntity(BlockPos pos, BlockState state) { super(ProjectEXBlockEntities.COLLECTOR.get(), pos, state); }

    @Override protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        tickCounter = tag.getInt("Tick");
        storedEmc = Math.max(0L, tag.getLong("StoredEMC"));
        lastDistributed = Math.max(0L, tag.getLong("LastDistributed"));
        totalDistributed = Math.max(0L, tag.getLong("TotalDistributed"));
    }
    @Override protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Tick", tickCounter);
        tag.putLong("StoredEMC", storedEmc);
        tag.putLong("LastDistributed", lastDistributed);
        tag.putLong("TotalDistributed", totalDistributed);
    }

    public void tickServer() {
        if (level == null || level.isClientSide || !(getBlockState().getBlock() instanceof CollectorBlock block)) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;
        storedEmc = saturatingAdd(storedEmc, block.matter.collectorOutput);
        lastDistributed = 0L;
        List<IEmcStorage> targets = new ArrayList<>(6);
        for (Direction direction : Direction.values()) {
            BlockPos targetPos = worldPosition.relative(direction);
            var targetState = level.getBlockState(targetPos);
            var targetEntity = level.getBlockEntity(targetPos);
            IEmcStorage storage = PECapabilities.EMC_STORAGE_CAPABILITY.getCapability(level, targetPos, targetState, targetEntity, direction.getOpposite());
            if (storage != null && storage.insertEmc(1L, EmcAction.SIMULATE) > 0L) {
                targets.add(storage);
                if (targetEntity instanceof RelayBlockEntity relay) {
                    // ProjectEX relays receive one tier-defined bonus per collector pulse.
                    relay.addBonus();
                } else if (targetEntity instanceof RelayMK1BlockEntity relay) {
                    // Preserve the classic ProjectEX interaction with ProjectE's MK1 relay:
                    // the original implementation applied twenty bonus pulses per collector cycle.
                    for (int i = 0; i < 20; i++) {
                        relay.addBonus(level, targetPos);
                    }
                }
            }
        }
        if (!targets.isEmpty()) {
            long share = storedEmc / targets.size();
            if (share > 0L) for (IEmcStorage target : targets) {
                long inserted = target.insertEmc(share, EmcAction.EXECUTE);
                storedEmc -= inserted;
                lastDistributed = saturatingAdd(lastDistributed, inserted);
                totalDistributed = saturatingAdd(totalDistributed, inserted);
                if (storedEmc < share) break;
            }
        }
        setChanged();
    }

    public long getLastDistributed() { return lastDistributed; }
    public long getTotalDistributed() { return totalDistributed; }

    public long getGeneratedPerSecond() {
        return getBlockState().getBlock() instanceof CollectorBlock block ? block.matter.collectorOutput : 0L;
    }

    private static long saturatingAdd(long a, long b) { return Long.MAX_VALUE - a < b ? Long.MAX_VALUE : a + b; }
    @Override public long getStoredEmc() { return storedEmc; }
    @Override public long getMaximumEmc() { return Long.MAX_VALUE; }
    @Override public long extractEmc(long emc, EmcAction action) {
        if (emc <= 0) return 0;
        long extracted = Math.min(storedEmc, emc);
        if (action.execute() && extracted > 0) { storedEmc -= extracted; setChanged(); }
        return extracted;
    }
    @Override public long insertEmc(long emc, EmcAction action) { return 0L; }
}
