package dev.latvian.mods.projectex.client;

import dev.latvian.mods.projectex.ProjectEX;
import dev.latvian.mods.projectex.menu.ProjectEXMenus;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid = ProjectEX.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class LinkScreenClient {
    private LinkScreenClient() {}
    @SubscribeEvent public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ProjectEXMenus.LINK.get(), LinkScreen::new);
    }
}
