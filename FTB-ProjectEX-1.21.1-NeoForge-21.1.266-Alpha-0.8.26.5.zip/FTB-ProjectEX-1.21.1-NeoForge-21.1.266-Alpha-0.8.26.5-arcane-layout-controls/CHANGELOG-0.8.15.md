# 0.8.15-alpha

- Replaced placeholder Personal Link, Refined Link and Compressed Refined Link blocks with tier-aware block entities.
- Added the original tier inventory dimensions (18+1, 1+9 and 1+54 slots).
- Added registry-aware inventory persistence, owner identity, BigInteger EMC buffering and once-per-second owner delivery.
- Registered EMC storage and item-handler capabilities for Links.
- GUI/container parity, learning behavior and automation validation remain pending.
