# ProjectEX Alpha 0.8.11 — EMC feedback polish

## Changes
- Added a brief green accent flash to the classic EMC HUD when the player's EMC balance increases.
- Kept the original compact blue/yellow/green HUD appearance and exact balance display while crouching.
- Made HUD width calculation safe for unusually small GUI widths.
- Made HUD number formatting deterministic with US decimal/grouping symbols.
- Added a short green activity pulse to the Energy Link panel when a newly reported transfer arrives.
- Reduced Energy Link status polling from four requests per second to two, retaining responsive live updates while reducing network traffic.
- Updated mod version metadata to `0.8.11-alpha`.

## Preserved
- No changes to EMC values, recipes, collector output, relay transfer logic, Power Flower production, or Arcane Tablet.
- Existing Energy Link ownership and transfer behavior are unchanged.

## Build and test
Run `gradlew.bat build` using JDK 21 and NeoForge 21.1.266.
Then test: gain EMC and confirm the HUD briefly flashes green; open an Energy Link and confirm its screen continues updating and pulses on a new delivery.
